"""Core anomaly-detection tools for the SIH26170 prototype."""

from .anomaly import BatchAwareAnomalyDetector, apply_robust_baseline
from .contracts import AnomalyResult, PredictionResult
from .decision import build_screening_record, recommend_action
from .evaluation import (
    BatchSplit,
    EvaluationReport,
    evaluate_repeated_splits,
    evaluate_synthetic_dataset,
    evaluate_time_sweep,
    make_batch_split,
    summarize_repeated_splits,
    write_evaluation_report,
)
from .features import MODEL_FEATURE_COLUMNS, build_component_features
from .synthetic import (
    DEFAULT_FAMILIES,
    DEFAULT_HOURS,
    FamilySpec,
    SyntheticDataset,
    generate_burn_in_dataset,
)
from .validation import DataValidationError, validate_readings

__all__ = [
    "AnomalyResult",
    "BatchAwareAnomalyDetector",
    "BatchSplit",
    "DataValidationError",
    "DEFAULT_FAMILIES",
    "DEFAULT_HOURS",
    "EvaluationReport",
    "FamilySpec",
    "MODEL_FEATURE_COLUMNS",
    "PredictionResult",
    "SyntheticDataset",
    "apply_robust_baseline",
    "build_screening_record",
    "build_component_features",
    "evaluate_synthetic_dataset",
    "evaluate_repeated_splits",
    "evaluate_time_sweep",
    "generate_burn_in_dataset",
    "make_batch_split",
    "recommend_action",
    "summarize_repeated_splits",
    "validate_readings",
    "write_evaluation_report",
]
