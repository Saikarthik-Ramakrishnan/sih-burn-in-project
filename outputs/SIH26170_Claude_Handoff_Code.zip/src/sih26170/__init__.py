"""Core anomaly-detection tools for the SIH26170 prototype."""

from .anomaly import BatchAwareAnomalyDetector, apply_robust_baseline
from .contracts import AnomalyResult, PredictionResult
from .decision import recommend_action
from .features import MODEL_FEATURE_COLUMNS, build_component_features
from .validation import DataValidationError, validate_readings

__all__ = [
    "AnomalyResult",
    "BatchAwareAnomalyDetector",
    "DataValidationError",
    "MODEL_FEATURE_COLUMNS",
    "PredictionResult",
    "apply_robust_baseline",
    "build_component_features",
    "recommend_action",
    "validate_readings",
]

