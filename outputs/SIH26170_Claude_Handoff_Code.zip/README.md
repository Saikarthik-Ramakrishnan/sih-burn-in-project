# SIH26170 anomaly-detection core

This is the technical-lead portion of the SIH26170 prototype. It turns early
burn-in measurements into component-level features, compares each component
with genuinely comparable peers, and returns an explainable anomaly result.

## Current scope

- strict input validation;
- leakage-safe feature engineering up to a chosen `as_of_hour`;
- a transparent median/MAD baseline;
- an Isolation Forest model;
- plain-language reason codes;
- a decision layer that can later consume Ashvitha's prediction output.

The prediction model, dashboard, production API, and real-world validation are
separate modules. This package does not claim that an anomaly proves a physical
failure mechanism.

## Input contract

Every row is one measurement for one component at one time.

| Column | Meaning |
|---|---|
| `component_id` | Unique component identifier |
| `batch_id` | Manufacturing/test batch |
| `component_family` | Comparable component type |
| `hours` | Hours since burn-in began |
| `measurement_name` | For example, `leakage_ua` |
| `measurement_value` | Observed value |
| `upper_limit` | Approved maximum for this measurement |

Optional columns include `lower_limit`, `temperature_c`, `humidity_pct`,
`test_condition`, and `data_source`.

## Run locally

```bash
python -m venv .venv
.venv/bin/pip install -e '.[dev]'
.venv/bin/pytest
.venv/bin/python examples/run_anomaly_demo.py
```

## Stable interface for teammates

```python
features = build_component_features(readings, as_of_hour=24)
detector = BatchAwareAnomalyDetector(contamination=0.1)
results = detector.fit_score(features)
```

The dashboard should consume the fields defined by `AnomalyResult.to_dict()`.
The future-value model can be connected through `PredictionResult` and
`recommend_action()`.

