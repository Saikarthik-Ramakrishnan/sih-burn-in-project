# Claude handoff — SIH26170 parallel technical-lead task

Paste the prompt below into Claude Code with a copy of this project. If using
Git, ask Claude to work on a separate branch named `claude/anomaly-evaluation`.

---

You are collaborating on SIH26170: AI-driven anomaly detection in electronic
component burn-in and screening.

The current repository already contains the first anomaly-detection core. Read
these files before acting:

- `README.md`
- `docs/technical_lead_plan.md`
- `src/sih26170/contracts.py`
- `src/sih26170/validation.py`
- `src/sih26170/features.py`
- `src/sih26170/anomaly.py`
- `src/sih26170/decision.py`
- all files under `tests/`

Current verified state: the local test command is `.venv/bin/pytest`, and nine
tests pass. The code uses Python, pandas, NumPy, and scikit-learn.

Your assignment is to independently build the evaluation and stress-testing
side of the anomaly module. Do not create a replacement implementation of the
existing detector and do not change the public input/output contracts unless a
test demonstrates a genuine defect.

Deliver the following:

1. A reproducible, physics-guided synthetic generator covering multiple batches
   and these labelled scenarios: healthy stable, ordinary noise, gradual drift,
   accelerating drift, sudden step change, intermittent behaviour, and
   measurement/tester fault. Clearly mark every generated row as synthetic.
2. A batch-level split so complete batches remain together and future readings
   never enter early-warning features.
3. An evaluation module comparing:
   - fixed upper-limit screening;
   - median/MAD robust screening;
   - Isolation Forest;
   - the existing combined robust + Isolation Forest result.
4. Metrics for defect recall, false-negative rate, false-positive rate,
   precision, and early-warning lead time. Do not present ordinary accuracy as
   the primary metric.
5. Tests proving that the split is leakage-safe and that known synthetic defect
   patterns are evaluated correctly.
6. A short `docs/evaluation_notes.md` explaining assumptions, results, failure
   cases, and which claims cannot be made from synthetic data.

Use simple deterministic parameter sweeps if sensitivity analysis is useful.
Bayesian optimisation is not required. Preserve the engineer-review model: the
software recommends actions but does not automatically certify or reject a
real component.

Keep changes mainly in new modules such as `src/sih26170/synthetic.py`,
`src/sih26170/evaluation.py`, corresponding tests, and documentation. Run all
tests before handing the work back. At the end, report changed files, test
results, and any interface issue that the main implementation must resolve.

---

## Merge rule

Bring back Claude's new generator, evaluation module, tests, and notes. Review
any proposed edits to `features.py`, `anomaly.py`, or `contracts.py` manually so
the dashboard and prediction interfaces do not drift.

