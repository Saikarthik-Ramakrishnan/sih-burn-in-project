"""Check 2: predict() never fits (xgboost / sklearn / module-level fit helpers all patched to raise)."""
from pathlib import Path

import pandas as pd
import sklearn.base
import xgboost
import xgboost.sklearn

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"

early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batch = sorted(early_all["batch_id"].unique())[3]
early = early_all.loc[early_all["batch_id"] == batch].reset_index(drop=True)


def boom(*a, **k):
    raise AssertionError("FIT CALLED DURING PREDICT")


# baseline results before patching
cands = {n: fv2.load_forecast_candidate(CAND / n) for n in ("xgb_abs_resid_leak", "xgb_abs_resid_aux")}
before = {n: c.predict(early) for n, c in cands.items()}

patched = []
for owner, attr in [
    (xgboost.XGBRegressor, "fit"), (xgboost.sklearn.XGBModel, "fit"), (xgboost.Booster, "update"), (xgboost.Booster, "boost"),
    (xgboost, "train"), (sklearn.base.BaseEstimator, "fit"), (fv2, "fit_model"), (fv2, "fit_medians"), (fv2, "make_xgboost"), (fv2, "fit_final_candidate"),
]:
    if hasattr(owner, attr):
        setattr(owner, attr, boom)
        patched.append(f"{getattr(owner, '__name__', owner)}.{attr}")
# also block file writes / network by patching a few obvious paths
import urllib.request
urllib.request.urlopen = boom
print("patched:", patched)

for n, c in cands.items():
    after = c.predict(early)
    pd.testing.assert_frame_equal(before[n], after)
    print(f"[{n}] predict with all fit paths patched: OK, identical to unpatched; rows={len(after)}")
    # Also confirm the booster object is unchanged (same number of trees) after predict
    print(f"[{n}] n trees after predict: {c.booster.get_booster().num_boosted_rounds()}")
