import pandas as pd, numpy as np, hashlib, json
from sih26170.mlcc_prototype import prepare_early_features, FORECAST_COLUMNS
G = ["batch_id","component_id","component_family","measurement_name"]
dt = {c: str for c in G}
early = pd.read_csv("data/train_early.csv", dtype=dt)
labels = pd.read_csv("data/train_labels.csv", dtype=dt)
readings = pd.read_csv("data/train_readings.csv", dtype=dt)
print("early rows", len(early), "components", early.component_id.nunique(), "batches", early.batch_id.nunique())
print("labels rows", len(labels), "readings rows", len(readings), "hours", sorted(readings.hours.unique()))
print("early hours", sorted(early.hours.unique()), "per-component early rows", early.groupby("component_id").size().value_counts().to_dict())
print("missing per column (early):", early.isna().sum()[early.isna().sum()>0].to_dict())
print("missing per column (labels):", labels.isna().sum()[labels.isna().sum()>0].to_dict())
# joins
f, e, unscored = prepare_early_features(early)
print("prepared features", f.shape, "unscored", len(unscored))
j = f[G].merge(labels, on=G, how="left", validate="one_to_one")
print("label join nulls in final_value:", j.final_value.isna().sum())
# profile per batch homogeneity
print("profiles per batch:", early.groupby("batch_id").profile_id.nunique().value_counts().to_dict())
print("batches per profile:", early.drop_duplicates("batch_id").groupby("profile_id").size().to_dict())
print("components per batch:", early.drop_duplicates("component_id").groupby("batch_id").size().describe()[["min","max"]].to_dict())
print("upper_limit per profile:", early.groupby("profile_id").upper_limit.unique().to_dict())
print("tester_id per batch:", early.groupby("batch_id").tester_id.nunique().value_counts().to_dict(), "channels:", sorted(early.tester_channel.unique()))
# target
lab = labels.copy()
lab["y"] = lab.final_value/lab.upper_limit
print("\nnormalized target describe:\n", lab.y.describe(percentiles=[.5,.9,.95,.99,.999]))
print("observed final crossing:", lab.is_observed_final_exceedance.astype(str).str.lower().eq("true").sum(), "latent (is_future_failure):", lab.is_future_failure.astype(str).str.lower().eq("true").sum(), "ever_latent:", lab.ever_latent_exceedance.astype(str).str.lower().eq("true").sum())
print("scenario counts:\n", lab.scenario.value_counts())
print("component_scenario counts:\n", lab.component_scenario.value_counts())
print("is_tester_fault:", lab.is_tester_fault.astype(str).str.lower().eq("true").sum(), "is_defect:", lab.is_defect.astype(str).str.lower().eq("true").sum(), "is_healthy:", lab.is_healthy.astype(str).str.lower().eq("true").sum())
print("onset hour dist (defects):", lab.anomaly_onset_hour.dropna().value_counts().sort_index().to_dict())
print("tester fault onset:", lab.tester_fault_onset_hour.dropna().value_counts().sort_index().to_dict())
print("by profile: crossings", lab.groupby("profile_id").apply(lambda d: pd.Series({"n": len(d), "obs_cross": d.is_observed_final_exceedance.astype(str).str.lower().eq("true").sum(), "y_med": d.y.median(), "y_p99": d.y.quantile(.99)})))
# persistence residual
ff = f.merge(lab[G+["y","scenario","profile_id","is_tester_fault","final_value"]], on=G)
ff["res_pers"] = ff.y - ff.limit_fraction
print("\npersistence residual (y - x24/limit) overall: MAE", ff.res_pers.abs().mean(), "median", ff.res_pers.median(), "mean", ff.res_pers.mean())
print(ff.groupby("scenario").res_pers.agg(["count","mean","median",lambda s: s.abs().mean()]).rename(columns={"<lambda_0>":"mae"}))
print("\nshare of total abs error by scenario:\n", (ff.groupby("scenario").res_pers.apply(lambda s: s.abs().sum())/ff.res_pers.abs().sum()).sort_values(ascending=False))
print("\nlimit_fraction at 24h describe:", ff.limit_fraction.describe(percentiles=[.5,.9,.99]).to_dict())
print("24h already >= limit:", (ff.limit_fraction>=1).sum())
# xgboost objectives
import xgboost as xgb
X = np.random.default_rng(0).normal(size=(50,3)); y = np.abs(X[:,0])
for obj in ["reg:squarederror","reg:absoluteerror","reg:pseudohubererror","reg:quantileerror","reg:gamma","reg:tweedie"]:
    try:
        kw = {"quantile_alpha": 0.5} if obj=="reg:quantileerror" else {}
        xgb.XGBRegressor(n_estimators=5, objective=obj, **kw).fit(X, y+0.01); print(obj, "OK")
    except Exception as ex: print(obj, "FAIL", str(ex)[:100])
