"""Check 1: predict() on one full training batch equals a manual recomputation; base_margin omission differs."""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2
from sih26170.mlcc_prototype import prepare_early_features

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"

early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batch = sorted(early_all["batch_id"].unique())[0]
early = early_all.loc[early_all["batch_id"] == batch].reset_index(drop=True)
print("batch", batch, "rows", len(early), "components", early["component_id"].nunique())

for name in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    cand = fv2.load_forecast_candidate(CAND / name)
    manifest = cand.manifest
    out = cand.predict(early)
    assert (out["status"] == "forecast").all(), out["status"].value_counts()
    assert len(out) == early["component_id"].nunique()
    # manual
    feats, validated, unscored = prepare_early_features(early)
    assert not unscored
    feats = fv2.augment_features(feats, validated)
    cols = manifest["feature_columns"]
    matrix = feats[cols].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    for c in cols:
        matrix[c] = matrix[c].fillna(manifest["imputation_medians"][c])
    X = matrix.to_numpy(dtype=float)
    margin = feats["limit_fraction"].to_numpy(dtype=float)
    raw = cand.booster.predict(X, base_margin=margin)
    manual_norm = np.maximum(raw, 0.0)
    manual_ua = manual_norm * feats["upper_limit"].to_numpy(dtype=float)
    manual = feats[fv2.IDENTITY].copy()
    manual["manual_norm"] = manual_norm
    manual["manual_ua"] = manual_ua
    merged = out.merge(manual, on=fv2.IDENTITY, how="left", validate="one_to_one")
    assert merged["manual_ua"].notna().all()
    np.testing.assert_array_equal(merged["predicted_normalized"].to_numpy(), merged["manual_norm"].to_numpy())
    np.testing.assert_array_equal(merged["predicted_final_value"].to_numpy(), merged["manual_ua"].to_numpy())
    print(f"[{name}] predict() == manual recomputation (exact equality): OK; n={len(out)}")
    # without base_margin
    raw_nomargin = np.maximum(cand.booster.predict(X), 0.0)
    diff = manual_norm - raw_nomargin
    print(f"[{name}] omit base_margin: mean|diff| normalized={np.abs(diff).mean():.4f}, max={np.abs(diff).max():.4f}; "
          f"mean pred with margin={manual_norm.mean():.4f}, without={raw_nomargin.mean():.4f}; "
          f"share zero without margin={(raw_nomargin==0).mean():.3f}")
    # what does the booster report as base_score / intercept
    try:
        cfg = json.loads(cand.booster.get_booster().save_config())
        print(f"[{name}] base_score={cfg['learner']['learner_model_param'].get('base_score')} objective={cfg['learner']['objective']['name']}")
    except Exception as e:  # pragma: no cover
        print("config read failed", e)
    # compare against the shipped preview csv
    prev = pd.read_csv(CAND / name / "predict_preview_first_training_batch.csv", dtype={c: str for c in fv2.IDENTITY})
    m2 = prev.merge(out, on=fv2.IDENTITY, suffixes=("_prev", ""))
    print(f"[{name}] preview csv rows={len(prev)} matched={len(m2)} maxdiff={np.abs(m2['predicted_final_value_prev']-m2['predicted_final_value']).max():.3e}")
    # compare with OOF? (OOF are out-of-fold, so differ; just show persistence sanity)
    print(f"[{name}] persistence_final_value == value_at_24h: {(out['persistence_final_value']==out['value_at_24h']).all()}; "
          f"mean pred uA={out['predicted_final_value'].mean():.4f} mean persistence uA={out['persistence_final_value'].mean():.4f}")
    print(out.dtypes.to_string())
