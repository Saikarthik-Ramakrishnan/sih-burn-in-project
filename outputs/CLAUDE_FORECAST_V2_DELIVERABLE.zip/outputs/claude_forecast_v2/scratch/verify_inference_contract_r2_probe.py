"""Second-pass probes for the inference contract: float32 sensitivity, output dtype instability,
input mutation, independent Booster/DMatrix recomputation, stray NaN-hour rows, manifest-only tampering."""
import json
import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import xgboost

from sih26170 import forecast_v2 as fv2
from sih26170.mlcc_prototype import prepare_early_features

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batches = sorted(early_all["batch_id"].unique())
c = fv2.load_forecast_candidate(CAND / "xgb_abs_resid_leak")

# ---- 1) independent recomputation through the raw Booster + DMatrix (not the sklearn wrapper)
early = early_all.loc[early_all["batch_id"] == batches[0]].reset_index(drop=True)
ref = c.predict(early)
feats, val, _ = prepare_early_features(early)
feats = fv2.augment_features(feats, val)
cols = c.manifest["feature_columns"]
X = feats[cols].astype(float).fillna(pd.Series(c.manifest["imputation_medians"])).to_numpy()
dm = xgboost.DMatrix(X, base_margin=feats["limit_fraction"].to_numpy(float))
raw = c.booster.get_booster().predict(dm)
manual = feats[fv2.IDENTITY].assign(m=np.maximum(raw, 0) * feats["upper_limit"].to_numpy(float))
m = ref.merge(manual, on=fv2.IDENTITY)
print("1) raw Booster+DMatrix recomputation max|d| uA:", np.abs(m["predicted_final_value"] - m["m"]).max())
raw_nomargin = c.booster.get_booster().predict(xgboost.DMatrix(X))
print("1) without base_margin: mean pred", np.maximum(raw_nomargin, 0).mean(), "vs with", np.maximum(raw, 0).mean(),
      "| corr with persistence(with margin)", np.corrcoef(np.maximum(raw, 0), feats["limit_fraction"])[0, 1])

# ---- 2) input mutation?
inp = early.copy()
snapshot = inp.copy()
c.predict(inp)
print("2) input frame unchanged after predict:", inp.equals(snapshot), "| columns same:", list(inp.columns) == list(snapshot.columns))

# ---- 3) float32 dtype sensitivity: which parts, and which features move
e4 = early_all.loc[early_all["batch_id"].isin(batches[:4])].reset_index(drop=True)
a = c.predict(e4).set_index("component_id")
e32 = e4.copy(); e32["measurement_value"] = e32["measurement_value"].astype(np.float32)
b = c.predict(e32).set_index("component_id")
d = (a["predicted_normalized"] - b["predicted_normalized"]).abs()
print("3) float32 measurement_value dtype: parts changed", int((d > 0).sum()), "/", len(d), "max|d| norm", d.max(), "p99", np.quantile(d, 0.99))
top = d.sort_values(ascending=False).head(5)
print("3) top movers:", top.round(4).to_dict())
f64, v64, _ = prepare_early_features(e4); f64 = fv2.augment_features(f64, v64).set_index("component_id")
f32, v32, _ = prepare_early_features(e32); f32 = fv2.augment_features(f32, v32).set_index("component_id")
for cid in top.index[:3]:
    diffs = {k: (float(f64.loc[cid, k]), float(f32.loc[cid, k])) for k in cols if not np.isclose(f64.loc[cid, k], f32.loc[cid, k], rtol=1e-6, atol=0)}
    print(f"   {cid}: pred64={a.loc[cid,'predicted_normalized']:.4f} pred32={b.loc[cid,'predicted_normalized']:.4f} y24={a.loc[cid,'value_at_24h']:.5f} feature diffs (64 vs 32):", {k: (round(x, 6), round(y, 6)) for k, (x, y) in diffs.items()})
# rounding the CSV to 6 significant digits (a realistic export) -- how much do predictions move?
e6 = e4.copy(); e6["measurement_value"] = e6["measurement_value"].map(lambda v: float(f"{v:.6g}"))
b6 = c.predict(e6).set_index("component_id")
d6 = (a["predicted_normalized"] - b6["predicted_normalized"]).abs()
print("3) 6-significant-digit rounding of measurement_value: parts changed", int((d6 > 1e-9).sum()), "max|d| norm", d6.max(), "p99", np.quantile(d6, 0.99))
e4dp = e4.copy(); e4dp["measurement_value"] = e4dp["measurement_value"].round(4)
b4 = c.predict(e4dp).set_index("component_id")
d4 = (a["predicted_normalized"] - b4["predicted_normalized"]).abs()
print("3) 4-decimal rounding of measurement_value (uA): parts changed", int((d4 > 1e-9).sum()), "max|d| norm", d4.max(), "p99", np.quantile(d4, 0.99), "| max |d| uA", (d4 * a["upper_limit"]).max())

# ---- 4) output dtype instability between all-forecast and mixed frames
ids = sorted(early["component_id"].unique())
mixed_in = early.loc[~((early["component_id"] == ids[0]) & (early["hours"].astype(float) == 24))]
allf = c.predict(early); mixedf = c.predict(mixed_in)
print("4) dtypes all-forecast vs with-one-unavailable:", {k: (str(allf[k].dtype), str(mixedf[k].dtype)) for k in fv2.OUTPUT_COLUMNS if str(allf[k].dtype) != str(mixedf[k].dtype)})
print("4) forecast rows: unavailable_reason values:", allf["unavailable_reason"].map(repr).unique()[:3], "| in mixed frame:", mixedf.loc[mixedf["status"] == "forecast", "unavailable_reason"].map(repr).unique()[:3])
print("4) unavailable row profile_id/peer_count repr:", mixedf.loc[mixedf["status"] == "unavailable", ["profile_id", "peer_count", "upper_limit"]].iloc[0].map(repr).to_dict())
# second measurement per component -> are leakage rows numerically identical?
extra = early.copy(); extra["measurement_name"] = "insulation_resistance_gohm"; extra["measurement_value"] = extra["insulation_resistance_gohm"]
o = c.predict(pd.concat([early, extra]))
lk = o.loc[o["measurement_name"] == "leakage_ua"].reset_index(drop=True)
print("4) with a second measurement_name in the upload: leakage forecasts numerically identical:", np.array_equal(lk["predicted_final_value"].to_numpy(), allf["predicted_final_value"].to_numpy()), "| peer_count identical:", np.array_equal(lk["peer_count"].to_numpy(float), allf["peer_count"].to_numpy(float)))

# ---- 5) stray rows: NaN hours / NaN value at a non-checkpoint hour for an otherwise valid part
f = early.copy(); s = f.loc[(f["component_id"] == ids[0]) & (f["hours"].astype(float) == 0)].copy(); s["hours"] = np.nan
o = c.predict(pd.concat([f, s])); print("5) extra row with NaN hours:", o.loc[o["component_id"] == ids[0], ["status", "unavailable_reason"]].iloc[0].to_dict())
f = early.copy(); s = f.loc[(f["component_id"] == ids[0]) & (f["hours"].astype(float) == 0)].copy(); s["hours"] = 96.0; s["measurement_value"] = np.nan
o = c.predict(pd.concat([f, s])); print("5) extra 96h row with NaN value:", o.loc[o["component_id"] == ids[0], "status"].iloc[0])
f = early.copy(); s = f.loc[(f["component_id"] == ids[0]) & (f["hours"].astype(float) == 0)].copy(); s["hours"] = 96.0; s["upper_limit"] = 5.0
o = c.predict(pd.concat([f, s])); print("5) extra 96h row with a different upper_limit:", o.loc[o["component_id"] == ids[0], "status"].iloc[0])
f = early.copy(); f["hours"] = f["hours"].astype(float) + 1e-9
o = c.predict(f); print("5) hours 24.000000001:", o["status"].value_counts().to_dict())
f = early.copy(); f["hours"] = f["hours"].astype(str).str.replace("24", "24.0")
o = c.predict(f); print("5) hours '24.0' strings:", o["status"].value_counts().to_dict())
f = early.copy(); f["component_id"] = f["component_id"].str.upper(); f.loc[f.index[:2], "component_id"] = f.loc[f.index[:2], "component_id"].str.lower()
o = c.predict(f); print("5) case-variant component_id rows:", o["status"].value_counts().to_dict(), "rows", len(o))

# ---- 6) manifest-only tampering (integrity check covers only files listed in artifact_sha256)
SCR = PACK / "outputs/claude_forecast_v2/scratch/verify_inference_contract_r2_tmp"
shutil.rmtree(SCR, ignore_errors=True); d = SCR / "x"; shutil.copytree(CAND / "xgb_abs_resid_leak", d)
mf = json.loads((d / "manifest.json").read_text()); mf["artifact_sha256"] = {}; mf["config"]["target"] = "normalized"
(d / "manifest.json").write_text(json.dumps(mf))
c2 = fv2.load_forecast_candidate(d); o2 = c2.predict(early)
print("6) manifest with artifact_sha256={} and target->normalized loads:", True, "| mean predicted_normalized", o2["predicted_normalized"].mean(), "vs", allf["predicted_normalized"].mean())
mf["artifact_sha256"] = {}; mf["config"]["target"] = "residual_over_persistence"; (d / "manifest.json").write_text(json.dumps(mf))
bb = (d / "model.ubj").read_bytes(); (d / "model.ubj").write_bytes(bb[:1000] + b"\x00" * 50 + bb[1050:])
try:
    fv2.load_forecast_candidate(d); print("6) corrupt ubj with empty artifact_sha256: loaded (!)")
except Exception as e:  # noqa: BLE001
    print("6) corrupt ubj with empty artifact_sha256 ->", type(e).__name__, str(e)[:90])
shutil.rmtree(SCR, ignore_errors=True)

# ---- 7) partial upload: same part, full batch vs 5-part upload, all 200 parts, one systematic pass
b5 = early_all.loc[early_all["batch_id"] == batches[5]].reset_index(drop=True)
full = c.predict(b5).set_index("component_id")
ids5 = sorted(b5["component_id"].unique()); rng = np.random.default_rng(7)
rows = []
for i in range(0, 200, 5):
    sub = ids5[i:i + 5]
    o = c.predict(b5.loc[b5["component_id"].isin(sub)]).set_index("component_id")
    for cid in sub:
        rows.append((cid, full.loc[cid, "predicted_normalized"], o.loc[cid, "predicted_normalized"], full.loc[cid, "upper_limit"]))
t = pd.DataFrame(rows, columns=["cid", "full", "five", "lim"]); t["d"] = (t["five"] - t["full"]).abs()
print("7) systematic 5-part partition of batch", batches[5], ": mean|d|", round(t["d"].mean(), 4), "median", round(t["d"].median(), 4), "p90", round(t["d"].quantile(0.9), 4), "max", round(t["d"].max(), 4), "normalized; max uA", round((t["d"] * t["lim"]).max(), 4),
      "| crossing flips", int(((t["five"] >= 1) != (t["full"] >= 1)).sum()))
print("7) single-part upload peer_count:", c.predict(b5.loc[b5["component_id"] == ids5[0]])["peer_count"].tolist())
