"""Diagnostic: reproduce v1 baselines + v1 XGBoost on fixed whole-batch folds.

Angle: explain where XGBoost (v1 config, squared error) loses to / gains on
persistence. Retrospective labels are used ONLY to explain out-of-fold errors.
Everything under src/ is read-only; nothing here trains a deployable bundle.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits

from sih26170.features import GROUP_COLUMNS
from sih26170.mlcc_prototype import (
    AS_OF_HOUR, FORECAST_COLUMNS, TARGET_HOUR, _new_models, prepare_early_features,
)

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
OUT = PACK / "outputs" / "claude_forecast_v2" / "scratch"
SEED = 26170
MODELS = ["persistence", "linear_extrapolation", "ridge", "hist_gradient_boosting", "xgboost"]
SHORT = {"persistence": "pers", "linear_extrapolation": "linx", "ridge": "ridge",
         "hist_gradient_boosting": "hgb", "xgboost": "xgb"}
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)
pd.set_option("display.float_format", lambda v: f"{v:.4f}")

G = GROUP_COLUMNS
dtypes = {c: str for c in G}
early_raw = pd.read_csv(PACK / "data" / "train_early.csv", dtype=dtypes)
labels = pd.read_csv(PACK / "data" / "train_labels.csv", dtype=dtypes)
assert len(early_raw) == 14400 and len(labels) == 7200

features, _early, unscored = prepare_early_features(early_raw)
assert not unscored and len(features) == 7200
features = features.sort_values(["batch_id", "component_id"]).reset_index(drop=True)

label_cols = ["profile_id", "scenario", "component_scenario", "is_defect", "is_healthy",
              "is_tester_fault", "anomaly_onset_hour", "tester_fault_onset_hour",
              "final_value", "true_final_value", "is_future_failure",
              "is_observed_final_exceedance", "ever_latent_exceedance", "upper_limit"]
df = features.merge(labels[G + label_cols].rename(columns={"upper_limit": "upper_limit_label"}),
                    on=G, how="left", validate="one_to_one")
assert df["final_value"].notna().all()
assert np.allclose(df["upper_limit"], df["upper_limit_label"])
df["y"] = df["final_value"] / df["upper_limit"]
df["y_true"] = df["true_final_value"] / df["upper_limit"]

# ---------------------------------------------------------------- folds
gkf = GroupKFold(n_splits=5)
df["fold"] = -1
for k, (_tr, va) in enumerate(gkf.split(df, groups=df["batch_id"])):
    df.loc[va, "fold"] = k
assert (df["fold"] >= 0).all()
fold_table = (df.groupby("batch_id").agg(fold=("fold", "first"), profile_id=("profile_id", "first"),
                                          n=("component_id", "size")).reset_index())
assert fold_table.groupby("batch_id")["fold"].nunique().eq(1).all()
print("\n=== batch -> fold assignment (GroupKFold(5), frame sorted by batch_id, component_id) ===")
print(fold_table.to_string(index=False))
print("\nfold x profile batch counts:")
print(pd.crosstab(fold_table["fold"], fold_table["profile_id"]))

# ---------------------------------------------------------------- fit per fold
X_all = df[FORECAST_COLUMNS].to_numpy(dtype=float)
y_all = df["y"].to_numpy(dtype=float)
for m in MODELS:
    df[f"pred_{SHORT[m]}"] = np.nan
df["pred_pers"] = np.maximum(df["limit_fraction"].to_numpy(float), 0.0)
df["pred_linx"] = np.maximum(
    (df["limit_fraction"] + df["slope_fraction_per_hour"] * (TARGET_HOUR - AS_OF_HOUR)).to_numpy(float), 0.0)

for k in range(5):
    tr = (df["fold"] != k).to_numpy()
    va = ~tr
    imputer = SimpleImputer(strategy="median", keep_empty_features=True).fit(X_all[tr])
    Xtr, Xva = imputer.transform(X_all[tr]), imputer.transform(X_all[va])
    models = _new_models(seed=SEED)
    with threadpool_limits(1):
        for name, model in models.items():
            model.fit(Xtr, y_all[tr])
            pred = np.asarray(model.predict(Xva), dtype=float)
            assert np.isfinite(pred).all()
            df.loc[va, f"pred_{SHORT[name]}"] = np.maximum(pred, 0.0)
    print(f"fold {k}: train {tr.sum()} val {va.sum()} batches_val={sorted(df.loc[va,'batch_id'].unique())}")

for m in MODELS:
    s = SHORT[m]
    assert df[f"pred_{s}"].notna().all()
    df[f"err_{s}"] = df[f"pred_{s}"] - df["y"]           # signed = predicted - actual
    df[f"abs_{s}"] = df[f"err_{s}"].abs()
    df[f"abs_ua_{s}"] = df[f"abs_{s}"] * df["upper_limit"]


def metrics(frame: pd.DataFrame, s: str) -> dict[str, float]:
    e = frame[f"err_{s}"]
    return {"n": len(frame), "mae_norm": e.abs().mean(), "mae_ua": frame[f"abs_ua_{s}"].mean(),
            "rmse_norm": float(np.sqrt((e ** 2).mean())), "mean_signed": e.mean(),
            "median_abs": e.abs().median()}


# ---------------------------------------------------------------- per fold and pooled
rows = []
for k in range(5):
    sub = df[df["fold"] == k]
    for m in MODELS:
        rows.append({"fold": k, "model": SHORT[m], **metrics(sub, SHORT[m])})
for m in MODELS:
    rows.append({"fold": "pooled", "model": SHORT[m], **metrics(df, SHORT[m])})
per_fold = pd.DataFrame(rows)
print("\n=== normalized MAE by fold (rows) and model (cols) ===")
print(per_fold.pivot(index="fold", columns="model", values="mae_norm")[list(SHORT.values())])
print("\n=== RMSE normalized by fold ===")
print(per_fold.pivot(index="fold", columns="model", values="rmse_norm")[list(SHORT.values())])
print("\n=== mean signed error (pred - y) by fold ===")
print(per_fold.pivot(index="fold", columns="model", values="mean_signed")[list(SHORT.values())])
print("\n=== MAE in uA by fold ===")
print(per_fold.pivot(index="fold", columns="model", values="mae_ua")[list(SHORT.values())])
pooled = per_fold[per_fold["fold"] == "pooled"].set_index("model")
print("\n=== pooled out-of-fold summary ===")
print(pooled[["n", "mae_norm", "median_abs", "mae_ua", "rmse_norm", "mean_signed"]])

# paired fold-level and batch-level comparison vs persistence
print("\n=== per-fold MAE(model) - MAE(persistence), normalized ===")
pf = per_fold[per_fold["fold"] != "pooled"].pivot(index="fold", columns="model", values="mae_norm")
print((pf.sub(pf["pers"], axis=0))[["linx", "ridge", "hgb", "xgb"]])
batch_mae = df.groupby("batch_id")[[f"abs_{s}" for s in SHORT.values()]].mean()
print("\n=== batches (of 36) where model MAE < persistence MAE ===")
for s in ["linx", "ridge", "hgb", "xgb"]:
    wins = int((batch_mae[f"abs_{s}"] < batch_mae["abs_pers"]).sum())
    print(f"  {s}: {wins}/36 batches better than persistence; median batch-level delta "
          f"{(batch_mae[f'abs_{s}'] - batch_mae['abs_pers']).median():+.4f}")

# per profile MAE uA pooled
print("\n=== MAE in uA per profile (pooled OOF) ===")
prof = df.groupby("profile_id").apply(
    lambda d: pd.Series({"n": len(d), "upper_limit": d["upper_limit"].iloc[0],
                         **{f"{s}": d[f"abs_ua_{s}"].mean() for s in SHORT.values()}}), include_groups=False)
print(prof)
print("\n=== normalized MAE per profile (pooled OOF) ===")
prof_n = df.groupby("profile_id").apply(
    lambda d: pd.Series({"n": len(d), **{f"{s}": d[f"abs_{s}"].mean() for s in SHORT.values()}}), include_groups=False)
print(prof_n)


# ---------------------------------------------------------------- crossing detection
def classification(truth: np.ndarray, flag: np.ndarray) -> dict[str, float]:
    truth, flag = np.asarray(truth, bool), np.asarray(flag, bool)
    tp = int((truth & flag).sum()); fn = int((truth & ~flag).sum())
    fp = int((~truth & flag).sum()); tn = int((~truth & ~flag).sum())
    return {"tp": tp, "fn": fn, "fp": fp, "tn": tn,
            "recall": tp / (tp + fn) if tp + fn else np.nan,
            "fpr": fp / (fp + tn) if fp + tn else np.nan,
            "precision": tp / (tp + fp) if tp + fp else np.nan}


obs_cross = (df["y"] >= 1.0).to_numpy()
print(f"\n=== observed crossing detection (forecast>=1 vs y>=1), pooled OOF; positives={obs_cross.sum()} ===")
cross_rows = []
for s in SHORT.values():
    cross_rows.append({"model": s, **classification(obs_cross, df[f"pred_{s}"] >= 1.0)})
cross = pd.DataFrame(cross_rows).set_index("model")
print(cross)

no_tf = ~df["is_tester_fault"].to_numpy(bool)
lat = df["is_future_failure"].to_numpy(bool)
print(f"\n=== latent crossing (is_future_failure) recall, excluding is_tester_fault parts; "
      f"n={no_tf.sum()} positives={(lat & no_tf).sum()} ===")
lat_rows = []
for s in SHORT.values():
    lat_rows.append({"model": s, **classification(lat[no_tf], (df[f"pred_{s}"] >= 1.0).to_numpy()[no_tf])})
latent = pd.DataFrame(lat_rows).set_index("model")
print(latent)

# already-crossed at 24h
already = df["limit_fraction"] >= 1.0
print(f"\nparts already >= limit at 24h: {already.sum()}; of these y>=1 at 168h: {(already & (df['y']>=1)).sum()}")
print("  MAE norm on already-crossed parts:", {s: round(df.loc[already, f"abs_{s}"].mean(), 4) for s in SHORT.values()})
print("  observed-crossing recall among NOT-already-crossed parts (y>=1 at 168h, lf<1 at 24h):")
mask_new = (~already) & (df["y"] >= 1.0)
for s in SHORT.values():
    print(f"    {s}: {(df.loc[mask_new, f'pred_{s}'] >= 1).sum()}/{mask_new.sum()}")

# ---------------------------------------------------------------- explain the XGBoost loss
df["group"] = np.select(
    [df["is_healthy"], df["is_defect"] & ~df["is_tester_fault"], df["is_defect"] & df["is_tester_fault"],
     ~df["is_defect"] & df["is_tester_fault"]],
    ["healthy", "defect_only", "defect+tester", "tester_only"], default="other")
assert (df["group"] != "other").all()
group_order = ["healthy", "defect_only", "defect+tester", "tester_only"]

print("\n=== error decomposition by part group (pooled OOF). signed = pred - y ===")
decomp_rows = []
for s in ["pers", "linx", "ridge", "hgb", "xgb"]:
    total_abs = df[f"abs_{s}"].sum()
    for g in group_order:
        d = df[df["group"] == g]
        decomp_rows.append({
            "model": s, "group": g, "n": len(d),
            "mae": d[f"abs_{s}"].mean(), "mean_signed": d[f"err_{s}"].mean(),
            "median_signed": d[f"err_{s}"].median(),
            "sum_abs": d[f"abs_{s}"].sum(), "share_of_total_abs": d[f"abs_{s}"].sum() / total_abs,
            "frac_worse_than_pers": (d[f"abs_{s}"] > d["abs_pers"]).mean(),
            "frac_pred_gt_y": (d[f"err_{s}"] > 0).mean(),
        })
decomp = pd.DataFrame(decomp_rows)
for s in ["xgb", "hgb", "ridge", "linx", "pers"]:
    print(f"\n-- {s} --")
    print(decomp[decomp["model"] == s].drop(columns="model").to_string(index=False))

print("\n=== healthy parts (n=%d): is the model inflating forecasts? ===" % (df["group"] == "healthy").sum())
h = df[df["group"] == "healthy"]
for s in SHORT.values():
    e = h[f"err_{s}"]
    print(f"  {s}: mean(pred-y)={e.mean():+.4f} median={e.median():+.4f} p90={e.quantile(.9):+.4f} "
          f"MAE={e.abs().mean():.4f} MAE_uA={h[f'abs_ua_{s}'].mean():.4f} "
          f"frac |err|>|pers err|={(h[f'abs_{s}'] > h['abs_pers']).mean():.3f} "
          f"frac pred>y={(e > 0).mean():.3f}")
print("  healthy-part MAE by profile (norm):")
print(h.groupby("profile_id").apply(lambda d: pd.Series({s: d[f"abs_{s}"].mean() for s in SHORT.values()}), include_groups=False))
print("  healthy-part mean signed error (pred - y) by profile:")
print(h.groupby("profile_id").apply(lambda d: pd.Series({s: d[f"err_{s}"].mean() for s in SHORT.values()}), include_groups=False))

# how much of the total absolute error comes from y >= 1 parts
print("\n=== share of total absolute error from parts with y>=1 (n=%d) ===" % obs_cross.sum())
share_rows = []
for s in SHORT.values():
    tot = df[f"abs_{s}"].sum()
    share_rows.append({"model": s, "total_abs": tot,
                       "abs_from_y_ge_1": df.loc[obs_cross, f"abs_{s}"].sum(),
                       "share_y_ge_1": df.loc[obs_cross, f"abs_{s}"].sum() / tot,
                       "mae_y_ge_1": df.loc[obs_cross, f"abs_{s}"].mean(),
                       "mae_y_lt_1": df.loc[~obs_cross, f"abs_{s}"].mean(),
                       "mean_signed_y_ge_1": df.loc[obs_cross, f"err_{s}"].mean(),
                       "mean_signed_y_lt_1": df.loc[~obs_cross, f"err_{s}"].mean()})
share = pd.DataFrame(share_rows).set_index("model")
print(share)

# where does XGB gain / lose vs persistence, by scenario (sum abs error delta)
print("\n=== per-scenario MAE (norm) and total-abs-error delta vs persistence ===")
scen_rows = []
for scen, d in df.groupby("scenario"):
    r = {"scenario": scen, "n": len(d), "y_mean": d["y"].mean()}
    for s in SHORT.values():
        r[f"mae_{s}"] = d[f"abs_{s}"].mean()
    for s in ["ridge", "hgb", "xgb"]:
        r[f"dsum_{s}"] = d[f"abs_{s}"].sum() - d["abs_pers"].sum()
        r[f"msgn_{s}"] = d[f"err_{s}"].mean()
    r["msgn_pers"] = d["err_pers"].mean()
    scen_rows.append(r)
scen = pd.DataFrame(scen_rows).sort_values("n", ascending=False).set_index("scenario")
print(scen[["n", "y_mean"] + [f"mae_{s}" for s in SHORT.values()]])
print(scen[["n", "msgn_pers", "msgn_ridge", "msgn_hgb", "msgn_xgb", "dsum_ridge", "dsum_hgb", "dsum_xgb"]])
print("  total abs error: ", {s: round(df[f"abs_{s}"].sum(), 2) for s in SHORT.values()})

# defect parts by onset hour: does XGB see late-onset defects?
print("\n=== defect-only parts by anomaly_onset_hour: MAE and mean signed error ===")
d_only = df[df["group"] == "defect_only"]
on = d_only.groupby("anomaly_onset_hour").apply(lambda d: pd.Series({
    "n": len(d), "y_mean": d["y"].mean(),
    "mae_pers": d["abs_pers"].mean(), "mae_xgb": d["abs_xgb"].mean(), "mae_hgb": d["abs_hgb"].mean(),
    "msgn_pers": d["err_pers"].mean(), "msgn_xgb": d["err_xgb"].mean(),
    "cross_recall_pers": ((d["pred_pers"] >= 1) & (d["y"] >= 1)).sum() / max((d["y"] >= 1).sum(), 1),
    "cross_recall_xgb": ((d["pred_xgb"] >= 1) & (d["y"] >= 1)).sum() / max((d["y"] >= 1).sum(), 1),
    "n_y_ge_1": (d["y"] >= 1).sum()}), include_groups=False)
print(on)

# tester fault parts
print("\n=== tester-fault parts by tester_fault_onset_hour ===")
tf = df[df["is_tester_fault"]]
print(tf.groupby("tester_fault_onset_hour").apply(lambda d: pd.Series({
    "n": len(d), "y_mean": d["y"].mean(), "y_true_mean": d["y_true"].mean(),
    "mae_pers": d["abs_pers"].mean(), "mae_xgb": d["abs_xgb"].mean(),
    "msgn_pers": d["err_pers"].mean(), "msgn_xgb": d["err_xgb"].mean()}), include_groups=False))

# XGB error magnitude distribution among healthy: how big are the inflations in uA
print("\n=== healthy parts: quantiles of xgb (pred - y) and of persistence (pred - y), normalized ===")
q = [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99]
print(pd.DataFrame({"xgb": h["err_xgb"].quantile(q), "hgb": h["err_hgb"].quantile(q),
                    "ridge": h["err_ridge"].quantile(q), "pers": h["err_pers"].quantile(q)}))
print("healthy parts flagged (pred>=1) per model:", {s: int((h[f"pred_{s}"] >= 1).sum()) for s in SHORT.values()})
print("healthy parts with xgb pred > 2x y:", int((h["pred_xgb"] > 2 * h["y"]).sum()),
      "; with xgb pred - y > 0.05:", int((h["err_xgb"] > 0.05).sum()),
      "; with xgb pred - y > 0.10:", int((h["err_xgb"] > 0.10).sum()))

# attribution of net loss vs persistence to part groups
print("\n=== attribution of (sum|err_model| - sum|err_pers|) to part groups ===")
attr_rows = []
for s in ["ridge", "hgb", "xgb"]:
    net = df[f"abs_{s}"].sum() - df["abs_pers"].sum()
    r = {"model": s, "net_delta_total_abs": net}
    for g in group_order:
        d = df[df["group"] == g]
        r[f"delta_{g}"] = d[f"abs_{s}"].sum() - d["abs_pers"].sum()
    attr_rows.append(r)
print(pd.DataFrame(attr_rows).set_index("model").to_string())

print("\n=== already >= limit at 24h (n=%d) by part group ===" % already.sum())
print(pd.crosstab(df.loc[already, "group"], df.loc[already, "y"] >= 1.0, margins=True))
print("  of already-crossed, latent is_future_failure:", int(df.loc[already, "is_future_failure"].sum()))
print("  already-crossed by tester_fault_onset_hour:", df.loc[already, "tester_fault_onset_hour"].value_counts(dropna=False).to_dict())

print("\n=== healthy parts: mean y vs mean forecast ===")
print({"mean_y": round(h["y"].mean(), 4), **{f"mean_pred_{s}": round(h[f"pred_{s}"].mean(), 4) for s in SHORT.values()}})
print("healthy parts: mean 24h limit_fraction", round(h["limit_fraction"].mean(), 4),
      "mean 0h initial_fraction", round(h["initial_fraction_of_limit"].mean(), 4))

print("\n=== RMSE normalized by part group ===")
print(df.groupby("group").apply(lambda d: pd.Series({s: float(np.sqrt((d[f"err_{s}"] ** 2).mean())) for s in SHORT.values()}), include_groups=False))

# ---------------------------------------------------------------- save artefacts
oof = df[G + ["fold", "upper_limit", "y"] + [f"pred_{s}" for s in SHORT.values()]].rename(
    columns={f"pred_{s}": f"forecast_{m}" for m, s in SHORT.items()})
oof_path = OUT / "diag_baseline_reproduction_oof.csv"
oof.to_csv(oof_path, index=False)
print(f"\nsaved OOF predictions: {oof_path} shape={oof.shape}")

summary = {
    "folds": fold_table.to_dict(orient="records"),
    "pooled": pooled.reset_index().to_dict(orient="records"),
    "per_fold_mae_norm": pf.reset_index().to_dict(orient="records"),
    "observed_crossing": cross.reset_index().to_dict(orient="records"),
    "latent_crossing_excl_tester_fault": latent.reset_index().to_dict(orient="records"),
    "group_decomposition": decomp.to_dict(orient="records"),
    "share_from_y_ge_1": share.reset_index().to_dict(orient="records"),
    "per_scenario": scen.reset_index().to_dict(orient="records"),
}
(OUT / "diag_baseline_reproduction_summary.json").write_text(json.dumps(summary, indent=1, default=float))
print("saved summary json")
