"""Check 8: output columns vs handoff requirements; building PredictionResult; dtypes; JSON-safety."""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2
from sih26170.contracts import PredictionResult

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_leak"
c = fv2.load_forecast_candidate(CAND)
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
early = early_all.loc[early_all["batch_id"] == sorted(early_all["batch_id"].unique())[0]].reset_index(drop=True)
ids = sorted(early["component_id"].unique())
# make one invalid
early = early.loc[~((early["component_id"] == ids[0]) & (early["hours"].astype(float) == 24))]
out = c.predict(early)
print("columns:", list(out.columns))
print(out.dtypes.to_string())
print("statuses:", out["status"].value_counts().to_dict())
print("target_hour unique:", out["target_hour"].unique(), "unit:", out["unit"].unique())
print("identity uniqueness:", not out.duplicated(fv2.IDENTITY).any())
print("identity dtypes object/str:", {k: out[k].map(type).unique().tolist() for k in fv2.IDENTITY})
unav = out.loc[out["status"] == "unavailable"].iloc[0]
print("unavailable row:", unav.to_dict())
print("types in unavailable row:", {k: type(v).__name__ for k, v in unav.to_dict().items()})
# predicted_final_value dtype with mixed None -> float64 with NaN? or object?
print("predicted_final_value dtype:", out["predicted_final_value"].dtype, "| peer_count dtype:", out["peer_count"].dtype, "| upper_limit dtype:", out["upper_limit"].dtype)
# build PredictionResult
row = out.loc[out["status"] == "forecast"].iloc[0]
try:
    pr = PredictionResult(predicted_final_value=float(row["predicted_final_value"]), prediction_lower=None, prediction_upper=None, target_hour=float(row["target_hour"]))
    print("PredictionResult with None bounds:", pr.to_dict())
except Exception as e:  # noqa: BLE001
    print("PredictionResult build failed:", e)
# JSON serialisation of the output as an integrator would do
try:
    js = json.dumps(out.to_dict("records"), allow_nan=False)
    print("json.dumps(records, allow_nan=False): OK", len(js))
except Exception as e:  # noqa: BLE001
    print("json.dumps(records, allow_nan=False) FAILS:", type(e).__name__, str(e)[:100])
try:
    js = json.dumps(fv2._json_safe(out.to_dict("records")), allow_nan=False)
    print("json.dumps(_json_safe(records)): OK")
except Exception as e:  # noqa: BLE001
    print("json.dumps(_json_safe(records)) FAILS:", type(e).__name__, str(e)[:100])
# is value_at_24h/upper_limit types numpy or python
print("row value types:", {k: type(v).__name__ for k, v in row.to_dict().items()})
# clipping / no upper clip: how many predictions exceed e.g. 10x limit across all training?
allout = c.predict(early_all)
print("all-training predictions: n", len(allout), "statuses", allout["status"].value_counts().to_dict(), "max normalized", allout["predicted_normalized"].max(), "min", allout["predicted_normalized"].min(), "share ==0", (allout["predicted_normalized"] == 0).mean())
# does predict() preserve the order-independent identity when identity columns have different dtypes (component_id numeric-like strings)?
print("manifest keys present for integrator:", sorted(c.manifest.keys()))
print("feature_columns == config.feature_columns:", c.manifest["feature_columns"] == c.manifest["config"]["feature_columns"])
# Does OUTPUT provide feature values / explanation? no.
# Sorting: SORT_KEYS order batch_id, component_id -> check
print("sorted by batch then component:", out[["batch_id", "component_id"]].equals(out[["batch_id", "component_id"]].sort_values(["batch_id", "component_id"]).reset_index(drop=True)))
