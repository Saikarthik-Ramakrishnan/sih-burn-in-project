"""Diagnostic: tester/channel faults, observed-vs-latent target noise, batch structure.

Read-only analysis of the training pack. No predictive model is fitted.
Labels are used ONLY to explain persistence residuals retrospectively.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(PACK / "src"))
from sih26170.mlcc_prototype import prepare_early_features  # noqa: E402
from sih26170.features import GROUP_COLUMNS  # noqa: E402

OUT = PACK / "outputs/claude_forecast_v2/scratch"
PREFIX = "diag_tester_faults_and_batch_effects"
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)
pd.set_option("display.float_format", lambda v: f"{v:.4f}")

ID_DTYPES = {c: str for c in GROUP_COLUMNS}
early = pd.read_csv(PACK / "data/train_early.csv", dtype=ID_DTYPES)
readings = pd.read_csv(PACK / "data/train_readings.csv", dtype=ID_DTYPES)
labels = pd.read_csv(PACK / "data/train_labels.csv", dtype=ID_DTYPES)
for df in (early, readings):
    df["tester_channel"] = df["tester_channel"].astype(str)
    df["tester_id"] = df["tester_id"].astype(str)
labels["is_tester_fault"] = labels["is_tester_fault"].astype(str).str.lower().eq("true")
labels["is_defect"] = labels["is_defect"].astype(str).str.lower().eq("true")
labels["is_healthy"] = labels["is_healthy"].astype(str).str.lower().eq("true")
for c in ("is_future_failure", "is_observed_final_exceedance", "ever_latent_exceedance"):
    labels[c] = labels[c].astype(str).str.lower().eq("true")

features, early_valid, unscored = prepare_early_features(early)
assert not unscored, unscored[:2]
meta24 = early.loc[early["hours"].astype(float) == 24.0, GROUP_COLUMNS + [
    "profile_id", "tester_id", "tester_channel", "board_position"]]
df = features.merge(meta24, on=GROUP_COLUMNS, validate="one_to_one")
df = df.merge(labels.drop(columns=["profile_id", "upper_limit", "data_source", "is_synthetic"]),
              on=GROUP_COLUMNS, validate="one_to_one")
assert len(df) == 7200, len(df)

df["y"] = df["final_value"] / df["upper_limit"]
df["y_true"] = df["true_final_value"] / df["upper_limit"]
df["pers"] = df["limit_fraction"]
df["lin"] = np.maximum(df["limit_fraction"] + df["slope_fraction_per_hour"] * 144.0, 0.0)
df["resid"] = df["y"] - df["pers"]
df["abs_resid"] = df["resid"].abs()
df["lin_abs_resid"] = (df["y"] - df["lin"]).abs()
df["noise_norm"] = df["y"] - df["y_true"]  # observed minus latent at 168 h, in limit units
results: dict[str, object] = {}

print("=" * 100)
print("PART 1: TESTER CHANNEL FAULTS")
print("=" * 100)
print("scenario x is_tester_fault")
print(pd.crosstab(df["scenario"], df["is_tester_fault"]))
print("\ncomponent_scenario for is_tester_fault parts")
print(df.loc[df["is_tester_fault"], "component_scenario"].value_counts())
print("\ntester_fault_onset_hour counts")
print(df.loc[df["is_tester_fault"], "tester_fault_onset_hour"].value_counts().sort_index())

# --- which batches / channels
tf = df[df["is_tester_fault"]]
by_batch = tf.groupby("batch_id").agg(n_fault=("component_id", "size"),
                                       n_channels=("tester_channel", "nunique"),
                                       onsets=("tester_fault_onset_hour", lambda s: sorted(set(s.astype(int)))),
                                       profile=("profile_id", "first"))
print("\nFaulted parts by batch (only batches with any fault)")
print(by_batch)
print(f"\nbatches with any tester fault: {len(by_batch)} of 36; channels per batch: 16; parts per channel per batch:")
ch_size = df.groupby(["batch_id", "tester_channel"]).size()
print(ch_size.describe()[["min", "50%", "max"]].to_dict())

# per (batch, channel) : parts faulted vs channel size
bc = df.groupby(["batch_id", "tester_channel"]).agg(
    n_parts=("component_id", "size"), n_fault=("is_tester_fault", "sum"),
    onset=("tester_fault_onset_hour", lambda s: s.dropna().astype(int).min() if s.notna().any() else np.nan))
bc["frac_fault"] = bc["n_fault"] / bc["n_parts"]
affected = bc[bc["n_fault"] > 0]
print("\nAffected (batch, channel) cells: count =", len(affected))
print(affected.sort_values(["batch_id", "tester_channel"]))
print("\nWithin affected channels: fraction of the channel's parts that are faulted")
print(affected["frac_fault"].describe())
n_fully = int((affected["frac_fault"] == 1.0).sum())
print(f"channels where ALL parts on the channel are faulted: {n_fully} / {len(affected)}")
# Non-faulted parts on affected channels: what are they?
non_fault_on_affected = df.merge(affected.reset_index()[["batch_id", "tester_channel"]], on=["batch_id", "tester_channel"])
non_fault_on_affected = non_fault_on_affected[~non_fault_on_affected["is_tester_fault"]]
print(f"parts on affected channels that are NOT flagged is_tester_fault: {len(non_fault_on_affected)}")
if len(non_fault_on_affected):
    print(non_fault_on_affected["scenario"].value_counts())
results["p1_affected_cells"] = int(len(affected))
results["p1_batches_with_fault"] = int(len(by_batch))
results["p1_fully_faulted_channels"] = n_fully
results["p1_frac_fault_within_affected_channel"] = affected["frac_fault"].describe().to_dict()

# --- does the fault show at 24 h? Compare against batch healthy peers by onset group
df["onset_group"] = np.where(~df["is_tester_fault"], "no_fault",
                             "tf_onset_" + df["tester_fault_onset_hour"].fillna(-1).astype(int).astype(str))
healthy_ref = df[df["is_healthy"]]
cols24 = ["limit_fraction", "delta_fraction_of_limit", "current_batch_robust_z", "slope_batch_robust_z",
          "percent_change", "initial_fraction_of_limit"]
print("\n24h feature medians by onset group (healthy parts as reference)")
g = df.groupby("onset_group")[cols24].median()
g["n"] = df.groupby("onset_group").size()
g.loc["healthy_only"] = list(healthy_ref[cols24].median()) + [len(healthy_ref)]
print(g)
print("\n24h feature 10/90 pct for tester_channel_fault scenario parts by onset")
tcf = df[df["scenario"] == "tester_channel_fault"]
for onset, sub in tcf.groupby("tester_fault_onset_hour"):
    q = sub[["limit_fraction", "delta_fraction_of_limit", "current_batch_robust_z"]].quantile([0.1, 0.5, 0.9])
    print(f"onset={int(onset)} n={len(sub)}")
    print(q)
# Detectability at 24h : AUC of |current_batch_robust_z| and delta_fraction_of_limit for tester fault by onset
print("\nAUC of existing 24h features for is_tester_fault (positives restricted to onset group; negatives = all non-fault parts)")
neg = df[~df["is_tester_fault"]]
auc_rows = []
for onset in (0, 12, 72):
    pos = df[(df["is_tester_fault"]) & (df["tester_fault_onset_hour"] == onset)]
    sub = pd.concat([pos, neg])
    lab = sub["is_tester_fault"].to_numpy()
    row = {"onset": onset, "n_pos": len(pos)}
    for c in ("current_batch_robust_z", "delta_fraction_of_limit", "slope_batch_robust_z", "limit_fraction"):
        row[f"auc_{c}"] = roc_auc_score(lab, sub[c].to_numpy())
        row[f"auc_abs_{c}"] = roc_auc_score(lab, sub[c].abs().to_numpy())
    auc_rows.append(row)
auc_tf = pd.DataFrame(auc_rows)
print(auc_tf.to_string(index=False))
results["p1_auc_existing_features_by_onset"] = auc_tf.to_dict(orient="records")

# --- trajectory view from readings: faulted parts vs healthy batch median at each checkpoint
rd = readings[GROUP_COLUMNS + ["hours", "measurement_value", "upper_limit", "tester_channel"]].copy()
rd["frac"] = rd["measurement_value"] / rd["upper_limit"]
rd = rd.merge(df[GROUP_COLUMNS + ["is_healthy", "is_tester_fault", "tester_fault_onset_hour", "scenario", "onset_group"]],
              on=GROUP_COLUMNS, validate="many_to_one")
healthy_med = (rd[rd["is_healthy"]].groupby(["batch_id", "hours"])["frac"].median()
               .rename("healthy_batch_median_frac").reset_index())
rd = rd.merge(healthy_med, on=["batch_id", "hours"], how="left")
rd["excess_vs_healthy"] = rd["frac"] - rd["healthy_batch_median_frac"]
traj = (rd[rd["scenario"] == "tester_channel_fault"]
        .groupby(["tester_fault_onset_hour", "hours"])["excess_vs_healthy"].median().unstack("hours"))
print("\nMedian excess (frac of limit) of tester_channel_fault parts over healthy batch median, by onset x hour")
print(traj)
traj_h = (rd[rd["is_healthy"]].groupby("hours")["excess_vs_healthy"].quantile([0.05, 0.95]).unstack())
print("healthy parts 5/95 pct of excess (noise band):")
print(traj_h.T)
results["p1_trajectory_excess_by_onset"] = {str(int(k)): {str(int(h)): float(v) for h, v in row.items()}
                                            for k, row in traj.iterrows()}

# --- observed vs latent final: irreducible target noise
def mae(a):
    return float(np.mean(np.abs(a)))

noise_tbl = df.groupby("is_tester_fault").agg(
    n=("component_id", "size"),
    mae_norm=("noise_norm", lambda s: mae(s)),
    mean_norm=("noise_norm", "mean"),
    p50_abs_norm=("noise_norm", lambda s: float(np.median(np.abs(s)))),
    p90_abs_norm=("noise_norm", lambda s: float(np.quantile(np.abs(s), 0.9))),
    max_abs_norm=("noise_norm", lambda s: float(np.max(np.abs(s)))),
)
noise_tbl["mae_uA"] = df.groupby("is_tester_fault").apply(lambda g: mae(g["final_value"] - g["true_final_value"]), include_groups=False)
print("\nObserved final vs latent true final (limit units) by is_tester_fault")
print(noise_tbl)
print("\nby scenario")
noise_sc = df.groupby("scenario").agg(n=("component_id", "size"), mae_norm=("noise_norm", lambda s: mae(s)),
                                      mean_norm=("noise_norm", "mean"),
                                      p90_abs=("noise_norm", lambda s: float(np.quantile(np.abs(s), 0.9))))
print(noise_sc.sort_values("mae_norm", ascending=False))
print("\nby tester fault onset")
print(df[df["is_tester_fault"]].groupby("tester_fault_onset_hour")["noise_norm"].agg(["size", lambda s: mae(s), "mean", "median"]))
# noise as fraction of persistence abs error
tot_abs_resid = df["abs_resid"].sum()
print(f"\nsum |resid| persistence = {tot_abs_resid:.2f}; sum |noise| = {df['noise_norm'].abs().sum():.2f}; "
      f"share of |noise| from faulted parts = {df.loc[df['is_tester_fault'], 'noise_norm'].abs().sum() / df['noise_norm'].abs().sum():.3f}")
print(f"Persistence MAE vs observed y: {df['abs_resid'].mean():.4f}; vs latent y_true: {(df['y_true']-df['pers']).abs().mean():.4f}")
print(f"Persistence MAE on faulted parts: {df.loc[df['is_tester_fault'],'abs_resid'].mean():.4f} (obs) vs "
      f"{(df.loc[df['is_tester_fault'],'y_true']-df.loc[df['is_tester_fault'],'pers']).abs().mean():.4f} (latent)")
# exceedance disagreement
dis = pd.crosstab([df["is_tester_fault"]], [df["is_observed_final_exceedance"], df["is_future_failure"]])
print("\nis_tester_fault x (observed exceedance, latent exceedance)")
print(dis)
disagree = df[df["is_observed_final_exceedance"] != df["is_future_failure"]]
print(f"parts where observed and latent 168h exceedance disagree: {len(disagree)}; of these tester-faulted: {int(disagree['is_tester_fault'].sum())}")
print(disagree.groupby(["is_tester_fault", "is_observed_final_exceedance"]).size())
results["p1_noise_by_fault"] = noise_tbl.reset_index().to_dict(orient="records")
results["p1_noise_by_scenario"] = noise_sc.reset_index().to_dict(orient="records")
results["p1_exceedance_disagree"] = {"n": int(len(disagree)), "n_tester_fault": int(disagree["is_tester_fault"].sum())}

print("\n" + "=" * 100)
print("PART 2: WITHIN-BATCH WITHIN-CHANNEL PEER STATISTICS AS 24h FEATURES")
print("=" * 100)
grp = df.groupby(["batch_id", "tester_channel"])
n_ch = grp["delta_fraction_of_limit"].transform("size")
# leave-one-out channel median of delta_fraction_of_limit (approximate LOO by excluding self via rank-neutral trick: use median of others)
def loo_median(s: pd.Series) -> pd.Series:
    vals = s.to_numpy()
    out = np.empty(len(vals))
    for i in range(len(vals)):
        out[i] = np.median(np.delete(vals, i)) if len(vals) > 1 else np.nan
    return pd.Series(out, index=s.index)

df["ch_med_delta_loo"] = grp["delta_fraction_of_limit"].transform(loo_median)
df["ch_med_delta_incl"] = grp["delta_fraction_of_limit"].transform("median")
df["ch_med_lf_loo"] = grp["limit_fraction"].transform(loo_median)
df["ch_med_z_loo"] = grp["current_batch_robust_z"].transform(loo_median)
df["ch_med_pct_loo"] = grp["percent_change"].transform(loo_median)
# batch-median reference to make it "channel relative to batch"
df["ch_minus_batch_delta"] = df["ch_med_delta_loo"] - df.groupby("batch_id")["delta_fraction_of_limit"].transform("median")
# count of elevated peers on channel (excluding self)
for name, cond in (("elev_z3", df["current_batch_robust_z"] > 3),
                   ("elev_delta", df["delta_fraction_of_limit"] > 0.05),
                   ("elev_slopez3", df["slope_batch_robust_z"] > 3)):
    tot = cond.groupby([df["batch_id"], df["tester_channel"]]).transform("sum")
    df[f"ch_n_{name}_loo"] = tot - cond.astype(int)
    df[f"ch_frac_{name}_loo"] = df[f"ch_n_{name}_loo"] / (n_ch - 1)
peer_cols = ["ch_med_delta_loo", "ch_med_delta_incl", "ch_minus_batch_delta", "ch_med_lf_loo", "ch_med_z_loo",
             "ch_med_pct_loo", "ch_frac_elev_z3_loo", "ch_frac_elev_delta_loo", "ch_frac_elev_slopez3_loo"]
base_cols = ["delta_fraction_of_limit", "current_batch_robust_z", "slope_batch_robust_z", "limit_fraction", "percent_change"]
rows = []
for c in peer_cols + base_cols:
    x = df[c].to_numpy()
    rho, p = stats.spearmanr(x, df["resid"].to_numpy(), nan_policy="omit")
    rho_abs, _ = stats.spearmanr(x, df["abs_resid"].to_numpy(), nan_policy="omit")
    auc_tf_all = roc_auc_score(df["is_tester_fault"], x)
    m_early = (~df["is_tester_fault"]) | (df["tester_fault_onset_hour"] <= 12)
    auc_tf_early = roc_auc_score(df.loc[m_early, "is_tester_fault"], df.loc[m_early, c])
    m_tcf = (~df["is_tester_fault"]) | (df["scenario"] == "tester_channel_fault")
    auc_tcf = roc_auc_score(df.loc[m_tcf, "scenario"].eq("tester_channel_fault"), df.loc[m_tcf, c])
    auc_def = roc_auc_score(df["is_defect"], x)
    rows.append({"feature": c, "spearman_resid": rho, "spearman_abs_resid": rho_abs,
                 "auc_tester_fault_all190": auc_tf_all, "auc_tester_fault_onset0_12": auc_tf_early,
                 "auc_tcf_scenario145": auc_tcf, "auc_is_defect": auc_def})
peer_tbl = pd.DataFrame(rows)
print(peer_tbl.to_string(index=False))
results["p2_peer_stats"] = peer_tbl.to_dict(orient="records")
# Are tester channels balanced? Is tester_channel itself predictive of anything (should not be)?
print("\nparts per (batch, channel): value counts of channel sizes")
print(ch_size.value_counts().sort_index().to_dict())
print("distinct tester_id per batch:", df.groupby("batch_id")["tester_id"].nunique().max(), "; distinct tester_ids overall:", df["tester_id"].nunique())
print("mean residual by tester_id (is channel/tester identity informative across batches?)")
print(df.groupby("tester_id")["resid"].agg(["size", "mean"]).T)
print("Kruskal test residual ~ tester_channel (pooled across batches): H, p =",
      stats.kruskal(*[g["resid"].to_numpy() for _, g in df.groupby("tester_channel")]))
# how many faulted channel cells have >=1 partner elevated?
aff_cells = df[df["is_tester_fault"] & (df["tester_fault_onset_hour"] <= 12)]
print("\nFor faulted parts with onset<=12: median ch_med_delta_loo, ch_frac_elev_z3_loo vs non-fault parts")
print(pd.DataFrame({"fault_onset<=12": aff_cells[["ch_med_delta_loo", "ch_minus_batch_delta", "ch_frac_elev_z3_loo", "delta_fraction_of_limit"]].median(),
                    "non_fault": df.loc[~df["is_tester_fault"], ["ch_med_delta_loo", "ch_minus_batch_delta", "ch_frac_elev_z3_loo", "delta_fraction_of_limit"]].median()}))
# Do defects also cluster on channels? (would confound)
def_by_cell = df.groupby(["batch_id", "tester_channel"])["is_defect"].sum()
print("\nDefects per (batch,channel): mean, var, var/mean (Poisson-ish => 1)", def_by_cell.mean(), def_by_cell.var(), def_by_cell.var() / def_by_cell.mean())
tf_by_cell = df.groupby(["batch_id", "tester_channel"])["is_tester_fault"].sum()
print("Tester faults per (batch,channel): mean, var, var/mean", tf_by_cell.mean(), tf_by_cell.var(), tf_by_cell.var() / tf_by_cell.mean())
results["p2_dispersion"] = {"defect_var_over_mean": float(def_by_cell.var() / def_by_cell.mean()),
                            "tf_var_over_mean": float(tf_by_cell.var() / tf_by_cell.mean())}

print("\n" + "=" * 100)
print("PART 3: BATCH-LEVEL STRUCTURE OF PERSISTENCE ERROR")
print("=" * 100)
pb = df.groupby("batch_id").agg(profile=("profile_id", "first"), n=("component_id", "size"),
                                pers_mae=("abs_resid", "mean"), lin_mae=("lin_abs_resid", "mean"),
                                mean_resid=("resid", "mean"), crossings=("is_observed_final_exceedance", "sum"),
                                latent_cross=("is_future_failure", "sum"),
                                n_defect=("is_defect", "sum"), n_tf=("is_tester_fault", "sum"))
pb = pb.sort_index()
print(pb)
print(f"\nper-batch persistence MAE: mean={pb['pers_mae'].mean():.4f} sd={pb['pers_mae'].std(ddof=1):.4f} "
      f"min={pb['pers_mae'].min():.4f} max={pb['pers_mae'].max():.4f} CV={pb['pers_mae'].std(ddof=1)/pb['pers_mae'].mean():.3f}")
print(f"per-batch crossings: mean={pb['crossings'].mean():.1f} sd={pb['crossings'].std(ddof=1):.1f} min={pb['crossings'].min()} max={pb['crossings'].max()}")
print(f"per-batch defect count: mean={pb['n_defect'].mean():.1f} sd={pb['n_defect'].std(ddof=1):.1f} min={pb['n_defect'].min()} max={pb['n_defect'].max()}")
print("Spearman(batch MAE, n_defect) =", stats.spearmanr(pb["pers_mae"], pb["n_defect"]))
print("Spearman(batch MAE, crossings) =", stats.spearmanr(pb["pers_mae"], pb["crossings"]))
print("\nper-profile MAE of the batch-level MAE values")
print(pb.groupby("profile")["pers_mae"].agg(["mean", "std", "min", "max"]))
results["p3_batch_mae"] = pb.reset_index()[["batch_id", "profile", "pers_mae", "lin_mae", "crossings", "n_defect", "n_tf"]].to_dict(orient="records")
results["p3_batch_mae_summary"] = {"mean": float(pb["pers_mae"].mean()), "sd": float(pb["pers_mae"].std(ddof=1)),
                                   "min": float(pb["pers_mae"].min()), "max": float(pb["pers_mae"].max())}

# 5-fold GroupKFold over sorted batches
batches_sorted = sorted(df["batch_id"].unique())
df_sorted = df.sort_values(["batch_id", "component_id"]).reset_index(drop=True)
gkf = GroupKFold(n_splits=5)
fold_rows = []
for k, (tr, va) in enumerate(gkf.split(df_sorted, groups=df_sorted["batch_id"])):
    v = df_sorted.iloc[va]
    fold_rows.append({"fold": k, "n_batches": v["batch_id"].nunique(), "batches": ",".join(sorted(v["batch_id"].unique())),
                      "profiles": ",".join(sorted(v["profile_id"].unique())),
                      "n": len(v), "pers_mae": v["abs_resid"].mean(), "lin_mae": v["lin_abs_resid"].mean(),
                      "pers_rmse": float(np.sqrt(np.mean(v["resid"] ** 2))),
                      "crossings": int(v["is_observed_final_exceedance"].sum()), "n_defect": int(v["is_defect"].sum()),
                      "n_tf": int(v["is_tester_fault"].sum()), "y_p99": float(v["y"].quantile(0.99))})
folds = pd.DataFrame(fold_rows)
print("\n5-fold GroupKFold (batches sorted by id) persistence MAE per fold")
print(folds.to_string(index=False))
print(f"fold MAE: mean={folds['pers_mae'].mean():.4f} sd={folds['pers_mae'].std(ddof=1):.4f} range={folds['pers_mae'].min():.4f}-{folds['pers_mae'].max():.4f}")
results["p3_folds"] = folds.to_dict(orient="records")
# note on GroupKFold ordering: sklearn GroupKFold assigns groups by size to balance; with equal sizes it uses group order
print("\nGroupKFold fold membership check (are folds contiguous in sorted batch order?):")
for r in fold_rows:
    print(f"  fold {r['fold']}: {r['batches']}")

# ICC one-way ANOVA form
def icc1(values: np.ndarray, groups: np.ndarray) -> tuple[float, float, float]:
    d = pd.DataFrame({"v": values, "g": groups})
    k = d.groupby("g").size()
    n_groups = len(k)
    grand = d["v"].mean()
    group_means = d.groupby("g")["v"].mean()
    ssb = float((k * (group_means - grand) ** 2).sum())
    ssw = float(((d["v"] - d["g"].map(group_means)) ** 2).sum())
    msb = ssb / (n_groups - 1)
    msw = ssw / (len(d) - n_groups)
    k0 = (len(d) - (k ** 2).sum() / len(d)) / (n_groups - 1)
    icc = (msb - msw) / (msb + (k0 - 1) * msw)
    f = msb / msw
    return float(icc), float(f), float(k0)

icc_rows = []
for name, col in (("resid", "resid"), ("abs_resid", "abs_resid"), ("y", "y"), ("noise_norm", "noise_norm"),
                  ("lin_resid", None)):
    vals = (df["y"] - df["lin"]).to_numpy() if col is None else df[col].to_numpy()
    icc_b, f_b, _ = icc1(vals, df["batch_id"].to_numpy())
    icc_c, f_c, _ = icc1(vals, (df["batch_id"] + "/" + df["tester_channel"]).to_numpy())
    icc_p, f_p, _ = icc1(vals, df["profile_id"].to_numpy())
    icc_rows.append({"quantity": name, "icc_batch": icc_b, "F_batch": f_b, "icc_batch_channel": icc_c, "F_batch_channel": f_c,
                     "icc_profile": icc_p})
icc_tbl = pd.DataFrame(icc_rows)
print("\nICC(1) one-way ANOVA")
print(icc_tbl.to_string(index=False))
# design effect for a batch of 200: 1 + (m-1)*ICC
icc_resid = icc_tbl.loc[icc_tbl["quantity"] == "resid", "icc_batch"].iloc[0]
icc_abs = icc_tbl.loc[icc_tbl["quantity"] == "abs_resid", "icc_batch"].iloc[0]
print(f"design effect for 200-part batch on resid: {1 + 199 * icc_resid:.2f}; on |resid|: {1 + 199 * icc_abs:.2f}; "
      f"effective n for 7200 rows: resid {7200 / (1 + 199 * icc_resid):.0f}, |resid| {7200 / (1 + 199 * icc_abs):.0f}")
# healthy-only ICC (batch offsets in healthy settling)
h = df[df["is_healthy"]]
icc_h, f_h, _ = icc1(h["resid"].to_numpy(), h["batch_id"].to_numpy())
print(f"ICC of residual within batch, healthy parts only: {icc_h:.4f} (F={f_h:.2f}); healthy per-batch mean residual sd = {h.groupby('batch_id')['resid'].mean().std(ddof=1):.5f}, "
      f"healthy within-batch residual sd = {h['resid'].std(ddof=1):.5f}")
results["p3_icc"] = icc_tbl.to_dict(orient="records")
results["p3_icc_healthy"] = float(icc_h)
# batch-level conformal coverage check: 90% quantile of |resid| computed on pooled data, coverage per batch
q90 = float(np.quantile(df["abs_resid"], 0.9))
cov = (df["abs_resid"] <= q90).groupby(df["batch_id"]).mean()
print(f"\nPooled 90% |resid| quantile = {q90:.4f}; per-batch coverage of that radius: mean={cov.mean():.3f} sd={cov.std(ddof=1):.3f} min={cov.min():.3f} max={cov.max():.3f}")
results["p3_batch_coverage_q90"] = {"q90": q90, "mean": float(cov.mean()), "sd": float(cov.std(ddof=1)), "min": float(cov.min()), "max": float(cov.max())}

print("\n" + "=" * 100)
print("PART 4: BATCH-LEVEL AGGREGATES AT 24h")
print("=" * 100)
bagg = df.groupby("batch_id").agg(
    b_med_delta=("delta_fraction_of_limit", "median"),
    b_med_lf=("limit_fraction", "median"),
    b_frac_slopez3=("slope_batch_robust_z", lambda s: float((s > 3).mean())),
    b_frac_curz3=("current_batch_robust_z", lambda s: float((s > 3).mean())),
    b_p90_delta=("delta_fraction_of_limit", lambda s: float(s.quantile(0.9))),
    b_frac_delta_gt005=("delta_fraction_of_limit", lambda s: float((s > 0.05).mean())),
    b_mad_delta=("delta_fraction_of_limit", lambda s: float((s - s.median()).abs().median())),
    b_frac_ge_limit=("limit_fraction", lambda s: float((s >= 1).mean())),
)
bagg = bagg.join(pb[["profile", "pers_mae", "mean_resid", "crossings", "n_defect", "n_tf"]])
print(bagg)
print("\ndistinct values per aggregate:", bagg[[c for c in bagg.columns if c.startswith("b_")]].nunique().to_dict())
rows = []
for c in [c for c in bagg.columns if c.startswith("b_")]:
    part_vals = df["batch_id"].map(bagg[c])
    r_part, _ = stats.spearmanr(part_vals, df["resid"])
    r_part_abs, _ = stats.spearmanr(part_vals, df["abs_resid"])
    r_cross, p_cross = stats.spearmanr(bagg[c], bagg["crossings"])
    r_mae, p_mae = stats.spearmanr(bagg[c], bagg["pers_mae"])
    r_def, _ = stats.spearmanr(bagg[c], bagg["n_defect"])
    # within-profile partial: rank within profile
    rows.append({"aggregate": c, "sp_part_resid": r_part, "sp_part_abs_resid": r_part_abs,
                 "sp_batch_crossings": r_cross, "p_cross": p_cross, "sp_batch_mae": r_mae, "p_mae": p_mae, "sp_batch_ndefect": r_def})
agg_tbl = pd.DataFrame(rows)
print("\nCorrelations of batch aggregates (36 values) with part residual (n=7200) and batch outcomes (n=36)")
print(agg_tbl.to_string(index=False))
# null spread of Spearman with n=36 via permutation
rng = np.random.default_rng(0)
null = np.array([stats.spearmanr(bagg["b_med_delta"], rng.permutation(bagg["crossings"].to_numpy()))[0] for _ in range(4000)])
print(f"permutation null for |Spearman| with n=36: 95th pct = {np.quantile(np.abs(null), 0.95):.3f}, 99th = {np.quantile(np.abs(null), 0.99):.3f}")
# Within-profile: does the aggregate still correlate with crossings after removing profile?
print("\nWithin-profile Spearman(b_frac_slopez3, crossings) per profile (n=9 each):")
for prof, sub in bagg.groupby("profile"):
    r1 = stats.spearmanr(sub["b_frac_slopez3"], sub["crossings"])[0]
    r2 = stats.spearmanr(sub["b_med_delta"], sub["crossings"])[0]
    r3 = stats.spearmanr(sub["b_frac_curz3"], sub["crossings"])[0]
    print(f"  {prof}: frac_slopez3 {r1:.3f}; med_delta {r2:.3f}; frac_curz3 {r3:.3f}")
# does the part-level feature already carry what the batch aggregate carries? partial Spearman of aggregate with resid controlling for own slope_z
def partial_spearman(x, y, z):
    rx = stats.rankdata(x); ry = stats.rankdata(y); rz = stats.rankdata(z)
    def resid_on(a, b):
        b1 = np.column_stack([np.ones_like(b), b]); coef, *_ = np.linalg.lstsq(b1, a, rcond=None); return a - b1 @ coef
    return float(np.corrcoef(resid_on(rx, rz), resid_on(ry, rz))[0, 1])
for c in ("b_frac_slopez3", "b_med_delta", "b_frac_curz3", "b_p90_delta"):
    pv = df["batch_id"].map(bagg[c]).to_numpy()
    print(f"partial Spearman({c}, resid | own delta_fraction_of_limit) = {partial_spearman(pv, df['resid'], df['delta_fraction_of_limit']):.4f}; "
          f"| own slope_batch_robust_z = {partial_spearman(pv, df['resid'], df['slope_batch_robust_z']):.4f}")
results["p4_batch_aggregates"] = agg_tbl.to_dict(orient="records")
results["p4_perm_null_95"] = float(np.quantile(np.abs(null), 0.95))
# How predictable is batch crossing count from batch defect count (upper bound of what aggregates could learn)?
print("Spearman(n_defect, crossings) across batches =", stats.spearmanr(bagg["n_defect"], bagg["crossings"])[0])
print("crossings per batch by profile:")
print(bagg.groupby("profile")["crossings"].agg(["mean", "std", "min", "max"]))

print("\n" + "=" * 100)
print("PART 5: PROFILE NORMALIZATION CHECK")
print("=" * 100)
prof_info = df.groupby("profile_id").agg(n=("component_id", "size"), upper_limit=("upper_limit", "first"),
                                          n_batches=("batch_id", "nunique"))
print(prof_info)
qs = [0.05, 0.25, 0.5, 0.75, 0.95, 0.99]
for col in ("limit_fraction", "delta_fraction_of_limit", "slope_batch_robust_z", "current_batch_robust_z", "y", "resid", "noise_norm"):
    print(f"\n{col} quantiles by profile")
    print(df.groupby("profile_id")[col].quantile(qs).unstack())
print("\nHealthy-only quantiles by profile (isolates normalization from scenario mix)")
for col in ("limit_fraction", "delta_fraction_of_limit", "resid", "noise_norm"):
    print(f"-- {col}")
    print(df[df["is_healthy"]].groupby("profile_id")[col].quantile([0.05, 0.5, 0.95]).unstack())
print("\nnoise (final - true) in raw uA by profile, healthy only: MAE and as fraction of limit")
nz = df[df["is_healthy"]].groupby("profile_id").apply(
    lambda g: pd.Series({"mae_uA": mae(g["final_value"] - g["true_final_value"]),
                         "mae_norm": mae(g["noise_norm"]), "limit": g["upper_limit"].iloc[0],
                         "rel_to_true_median": float(np.median(np.abs(g["final_value"] - g["true_final_value"]) / g["true_final_value"]))}),
    include_groups=False)
print(nz)
print("\nPer-profile persistence MAE, mean resid, crossings, scenario mix")
pp = df.groupby("profile_id").agg(pers_mae=("abs_resid", "mean"), lin_mae=("lin_abs_resid", "mean"), mean_resid=("resid", "mean"),
                                   crossings=("is_observed_final_exceedance", "sum"), latent=("is_future_failure", "sum"),
                                   n_defect=("is_defect", "sum"), n_tf=("is_tester_fault", "sum"),
                                   ge_limit_at_24=("limit_fraction", lambda s: int((s >= 1).sum())))
print(pp)
print("\nscenario mix by profile (counts)")
print(pd.crosstab(df["profile_id"], df["scenario"]))
print("\nKruskal-Wallis across profiles, healthy parts: limit_fraction, delta_fraction_of_limit, resid")
for col in ("limit_fraction", "delta_fraction_of_limit", "resid"):
    hstat, p = stats.kruskal(*[g[col].to_numpy() for _, g in df[df["is_healthy"]].groupby("profile_id")])
    print(f"  {col}: H={hstat:.1f} p={p:.2e}")
# Residual-vs-feature relationship shape by profile: Spearman(resid, delta_fraction_of_limit) per profile; slope of y on delta per profile among defects
print("\nSpearman(resid, delta_fraction_of_limit) and Spearman(y, limit_fraction) per profile")
for prof, sub in df.groupby("profile_id"):
    print(f"  {prof}: rho(resid,delta)={stats.spearmanr(sub['resid'], sub['delta_fraction_of_limit'])[0]:.3f}; "
          f"rho(y,limit_fraction)={stats.spearmanr(sub['y'], sub['limit_fraction'])[0]:.3f}; "
          f"defects: median y = {sub.loc[sub['is_defect'], 'y'].median():.3f}, median resid = {sub.loc[sub['is_defect'], 'resid'].median():.3f}")
# conditional: among defect parts with onset<=12, ratio y/limit_fraction by profile (growth multiplier)
d12 = df[df["is_defect"] & (df["anomaly_onset_hour"] <= 12) & (df["limit_fraction"] > 0)]
print("\nDefects with onset<=12: median y / limit_fraction (growth multiple 24h->168h) by profile")
print(d12.groupby("profile_id").apply(lambda g: pd.Series({"n": len(g), "med_growth": float((g["y"] / g["limit_fraction"]).median()),
                                                            "med_delta": float(g["delta_fraction_of_limit"].median()),
                                                            "med_y": float(g["y"].median())}), include_groups=False))
results["p5_profile_summary"] = pp.reset_index().to_dict(orient="records")
results["p5_noise_healthy_by_profile"] = nz.reset_index().to_dict(orient="records")
results["p5_quantiles"] = {col: df.groupby("profile_id")[col].quantile(qs).unstack().to_dict(orient="index")
                           for col in ("limit_fraction", "delta_fraction_of_limit", "y", "resid")}

print("\n" + "=" * 100)
print("PART 6: FOLLOW-UPS (composition of over-limit-at-24h parts, irreducible share, peer stat among high-z parts)")
print("=" * 100)
over = df[df["limit_fraction"] >= 1.0]
print(f"parts with limit_fraction >= 1 at 24h: {len(over)}")
print(pd.crosstab(over["scenario"], over["is_tester_fault"]))
print("onset of tester-faulted over-limit parts:", over.loc[over["is_tester_fault"], "tester_fault_onset_hour"].value_counts().to_dict())
print("residual (y - pers) of over-limit parts by is_tester_fault: mean / median / MAE")
print(over.groupby("is_tester_fault")["resid"].agg(["size", "mean", "median", lambda s: mae(s)]))
print("observed final exceedance rate among over-limit-at-24h parts by is_tester_fault:")
print(over.groupby("is_tester_fault")["is_observed_final_exceedance"].mean())
results["p6_over_limit_24h"] = {"n": int(len(over)), "n_tester_fault": int(over["is_tester_fault"].sum()),
                                "scenario_counts": over["scenario"].value_counts().to_dict()}

print("\nPersistence abs residual by onset group (share of total |resid| = irreducible-from-24h for onset 72)")
og = df.groupby("onset_group").agg(n=("component_id", "size"), pers_mae=("abs_resid", "mean"), mean_resid=("resid", "mean"),
                                   sum_abs=("abs_resid", "sum"), lin_mae=("lin_abs_resid", "mean"),
                                   pers_mae_vs_latent=("component_id", lambda s: np.nan))
for k, sub in df.groupby("onset_group"):
    og.loc[k, "pers_mae_vs_latent"] = float((sub["y_true"] - sub["pers"]).abs().mean())
og["share_total_abs"] = og["sum_abs"] / df["abs_resid"].sum()
print(og)
results["p6_by_onset_group"] = og.reset_index().to_dict(orient="records")
lin12 = df[(df["is_tester_fault"]) & (df["tester_fault_onset_hour"] == 12)]
print(f"onset-12 faulted parts: linear extrapolation median forecast = {lin12['lin'].median():.2f} vs observed y median {lin12['y'].median():.2f}; "
      f"lin MAE = {lin12['lin_abs_resid'].mean():.3f}; sum lin |resid| = {lin12['lin_abs_resid'].sum():.1f} of total lin {df['lin_abs_resid'].sum():.1f} "
      f"({lin12['lin_abs_resid'].sum() / df['lin_abs_resid'].sum():.3f})")
results["p6_onset12_lin"] = {"lin_mae": float(lin12["lin_abs_resid"].mean()), "share_lin_total": float(lin12["lin_abs_resid"].sum() / df["lin_abs_resid"].sum())}

print("\nAmong parts with current_batch_robust_z > 3 (the ambiguous group: defect vs shared-channel fault)")
hz = df[df["current_batch_robust_z"] > 3]
print(f"n = {len(hz)}; tester-faulted = {int(hz['is_tester_fault'].sum())}; defects = {int(hz['is_defect'].sum())}; healthy/ordinary = {int(hz['is_healthy'].sum())}")
for c in ("ch_frac_elev_z3_loo", "ch_med_z_loo", "ch_med_lf_loo", "current_batch_robust_z", "limit_fraction", "delta_fraction_of_limit"):
    auc = roc_auc_score(hz["is_tester_fault"], hz[c])
    rho = stats.spearmanr(hz[c], hz["resid"])[0]
    print(f"  {c:28s} AUC(is_tester_fault | z>3) = {auc:.3f}; Spearman(resid | z>3) = {rho:+.3f}")
print("mean/median residual within z>3 group, tester fault vs not:")
print(hz.groupby("is_tester_fault")["resid"].agg(["size", "mean", "median"]))
print("mean residual within z>3 group split by ch_frac_elev_z3_loo >= 0.5:")
hz_flag = hz["ch_frac_elev_z3_loo"] >= 0.5
print(hz.groupby(hz_flag)["resid"].agg(["size", "mean", "median"]))
print("cross-tab: peer flag (>=0.5 of channel peers z>3) vs is_tester_fault, within z>3 group")
print(pd.crosstab(hz_flag, hz["is_tester_fault"]))
# Full-population confusion of the peer flag
flag_all = df["ch_frac_elev_z3_loo"] >= 0.5
print("\nFull population: peer flag (>=50% of channel peers z>3) vs is_tester_fault")
print(pd.crosstab(flag_all, df["is_tester_fault"]))
print("peer flag vs tester_fault_onset (positives only):", pd.crosstab(flag_all[df["is_tester_fault"]], df.loc[df["is_tester_fault"], "tester_fault_onset_hour"]).to_dict())
results["p6_peer_flag_confusion"] = pd.crosstab(flag_all, df["is_tester_fault"]).to_dict()
results["p6_hz"] = {"n": int(len(hz)), "n_tf": int(hz["is_tester_fault"].sum()),
                    "auc_ch_frac_elev_z3_loo": float(roc_auc_score(hz["is_tester_fault"], hz["ch_frac_elev_z3_loo"])),
                    "auc_ch_med_z_loo": float(roc_auc_score(hz["is_tester_fault"], hz["ch_med_z_loo"]))}

print("\nBatch aggregates vs crossings EXCLUDING the 15 tester-fault batches (n=21)")
bagg_nf = bagg[bagg["n_tf"] == 0]
for c in ("b_frac_curz3", "b_frac_slopez3", "b_p90_delta", "b_frac_ge_limit", "b_med_lf", "b_med_delta"):
    r_all = stats.spearmanr(bagg[c], bagg["crossings"])[0]
    r_nf = stats.spearmanr(bagg_nf[c], bagg_nf["crossings"])[0]
    r_lat = stats.spearmanr(bagg[c], bagg["latent_cross"] if "latent_cross" in bagg else pb["latent_cross"])[0]
    print(f"  {c:20s} all36 rho={r_all:+.3f}; no-fault21 rho={r_nf:+.3f}; vs latent crossings all36 rho={r_lat:+.3f}")
null21 = np.array([stats.spearmanr(bagg_nf["b_frac_curz3"], rng.permutation(bagg_nf["crossings"].to_numpy()))[0] for _ in range(4000)])
print(f"permutation null |Spearman| n=21: 95th pct = {np.quantile(np.abs(null21), 0.95):.3f}")
results["p6_agg_no_fault_batches"] = {c: float(stats.spearmanr(bagg_nf[c], bagg_nf["crossings"])[0]) for c in ("b_frac_curz3", "b_frac_slopez3", "b_p90_delta", "b_med_lf")}

print("\nPer-profile persistence MAE excluding tester-faulted parts, and healthy-only MAE")
nf = df[~df["is_tester_fault"]]
pp2 = pd.DataFrame({
    "pers_mae_all": df.groupby("profile_id")["abs_resid"].mean(),
    "pers_mae_no_tf": nf.groupby("profile_id")["abs_resid"].mean(),
    "pers_mae_defects_only": df[df["is_defect"] & ~df["is_tester_fault"]].groupby("profile_id")["abs_resid"].mean(),
    "pers_mae_healthy": df[df["is_healthy"]].groupby("profile_id")["abs_resid"].mean(),
    "crossings_no_tf": nf.groupby("profile_id")["is_observed_final_exceedance"].sum(),
    "n_defect": df.groupby("profile_id")["is_defect"].sum(),
})
print(pp2)
results["p6_profile_mae_no_tf"] = pp2.reset_index().to_dict(orient="records")
print(f"\nBinomial reference sd for per-batch coverage at p=0.9, n=200: {np.sqrt(0.9 * 0.1 / 200):.4f} (observed sd {cov.std(ddof=1):.4f})")
# per-batch coverage excluding tester-fault onset-72 parts (which are pure surprises)
m72 = ~((df["is_tester_fault"]) & (df["tester_fault_onset_hour"] == 72))
cov2 = (df.loc[m72, "abs_resid"] <= q90).groupby(df.loc[m72, "batch_id"]).mean()
print(f"per-batch coverage excluding onset-72 faulted parts: sd={cov2.std(ddof=1):.4f} min={cov2.min():.3f}")
worst = cov.sort_values().head(3)
print("lowest-coverage batches:", worst.round(3).to_dict(), "their n_tf:", pb.loc[worst.index, "n_tf"].to_dict(), "onsets:",
      {b: sorted(set(df.loc[(df['batch_id'] == b) & df['is_tester_fault'], 'tester_fault_onset_hour'].astype(int))) for b in worst.index})

# --- save small outputs
def _js(o):
    if isinstance(o, dict):
        return {str(k): _js(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_js(v) for v in o]
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating, float)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, (np.bool_,)):
        return bool(o)
    return o

(OUT / f"{PREFIX}_results.json").write_text(json.dumps(_js(results), indent=1))
pb.reset_index().to_csv(OUT / f"{PREFIX}_batch_table.csv", index=False)
print("\nsaved", OUT / f"{PREFIX}_results.json")
