"""Check 3: partial uploads (1, 3, 5, 20 parts, two batches mixed) - peer_count, prediction drift, no crash."""
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"
labels = fv2.read_identity_csv(PACK / "data/train_labels.csv")

early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batches = sorted(early_all["batch_id"].unique())
batch = batches[5]
early = early_all.loc[early_all["batch_id"] == batch].reset_index(drop=True)
ids = sorted(early["component_id"].unique())
rng = np.random.default_rng(0)

for name in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    cand = fv2.load_forecast_candidate(CAND / name)
    full = cand.predict(early).set_index("component_id")
    print(f"\n=== {name} === batch {batch}, full peer_count={full['peer_count'].unique()}")
    for k in (1, 2, 3, 5, 20, 50):
        # repeat a few random subsets to get the distribution of prediction change
        deltas_norm, deltas_ua, rel = [], [], []
        for rep in range(20 if k < 50 else 5):
            sub_ids = list(rng.choice(ids, size=k, replace=False))
            sub = early.loc[early["component_id"].isin(sub_ids)]
            out = cand.predict(sub)
            assert len(out) == k and (out["status"] == "forecast").all(), out[["component_id", "status", "unavailable_reason"]]
            assert (out["peer_count"] == k).all(), out["peer_count"].unique()
            o = out.set_index("component_id")
            d = (o["predicted_normalized"] - full.loc[o.index, "predicted_normalized"])
            deltas_norm.append(d.abs().to_numpy()); deltas_ua.append((d * o["upper_limit"]).abs().to_numpy())
            rel.append((d.abs() / full.loc[o.index, "predicted_normalized"].clip(lower=1e-9)).to_numpy())
        dn, du, rr = np.concatenate(deltas_norm), np.concatenate(deltas_ua), np.concatenate(rel)
        print(f"  k={k:3d}: |dpred| normalized mean={dn.mean():.4f} median={np.median(dn):.4f} p90={np.quantile(dn,0.9):.4f} max={dn.max():.4f} | uA max={du.max():.4f} | rel median={np.median(rr):.3f} max={rr.max():.2f} | share changed>1e-6: {(dn>1e-6).mean():.2f}")
    # single part: inspect robust-z features directly
    one = early.loc[early["component_id"] == ids[0]]
    feats, val, _ = fv2.prepare_early_features(one)
    feats = fv2.augment_features(feats, val)
    print("  single-part features:", feats[["current_batch_robust_z", "slope_batch_robust_z", "prior_storage_humidity_batch_rank_v2", "channel_peer_median_current_z_v2"]].to_dict("records"))
    # crossing decision flips between full-batch and 5-part uploads?
    flips = 0; total = 0
    for rep in range(40):
        sub_ids = list(rng.choice(ids, size=5, replace=False))
        out = cand.predict(early.loc[early["component_id"].isin(sub_ids)]).set_index("component_id")
        f = (out["predicted_normalized"] >= 1.0) != (full.loc[out.index, "predicted_normalized"] >= 1.0)
        flips += int(f.sum()); total += len(f)
    print(f"  crossing-flag flips between full batch and 5-part upload: {flips}/{total}")
    # one defective/high part alone with 4 healthy vs full batch
    lab = labels.loc[labels["batch_id"] == batch].set_index("component_id")
    hi = full["predicted_normalized"].sort_values(ascending=False).index[:3].tolist()
    for h in hi:
        sub_ids = [h] + list(rng.choice([i for i in ids if i != h], size=4, replace=False))
        out = cand.predict(early.loc[early["component_id"].isin(sub_ids)]).set_index("component_id")
        print(f"  high part {h}: full-batch pred={full.loc[h,'predicted_normalized']:.3f}, 5-part pred={out.loc[h,'predicted_normalized']:.3f}, observed y={float(lab.loc[h,'final_value'])/full.loc[h,'upper_limit']:.3f}")

# two batches mixed (different profiles?)
cand = fv2.load_forecast_candidate(CAND / "xgb_abs_resid_leak")
b2 = batches[6]
prof = early_all.drop_duplicates("batch_id").set_index("batch_id")["profile_id"]
print(f"\nmixed batches {batch} ({prof[batch]}) + {b2} ({prof[b2]})")
mixed = early_all.loc[early_all["batch_id"].isin([batch, b2])]
out_mixed = cand.predict(mixed)
sep = pd.concat([cand.predict(early_all.loc[early_all["batch_id"] == b]) for b in (batch, b2)]).sort_values(fv2.SORT_KEYS).reset_index(drop=True)
pd.testing.assert_frame_equal(out_mixed, sep)
print("mixed-batch upload == concatenation of separate batch uploads:", True, "; peer counts:", out_mixed.groupby("batch_id")["peer_count"].unique().to_dict())
# mixed: 3 parts of batch A + full batch B
sub = pd.concat([early.loc[early["component_id"].isin(ids[:3])], early_all.loc[early_all["batch_id"] == b2]])
o = cand.predict(sub)
print("3 parts of A + full B: peer counts", o.groupby("batch_id")["peer_count"].unique().to_dict(), "statuses", o["status"].value_counts().to_dict())
# same component_id in two batches -> ?
dup = early.loc[early["component_id"] == ids[0]].copy(); dup["batch_id"] = b2
try:
    o = cand.predict(pd.concat([early, dup]))
    print("component in two batches ->", o["status"].value_counts().to_dict())
except Exception as e:
    print("component in two batches -> raises", type(e).__name__, str(e)[:120])
