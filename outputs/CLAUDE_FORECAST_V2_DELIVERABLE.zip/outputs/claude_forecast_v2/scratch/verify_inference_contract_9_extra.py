"""Check 9: extra probes - multi-measurement rows per component, perturbation sensitivity, manifest schema holes, timing, threadpool."""
import json
import shutil
import time
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_leak"
SCR = PACK / "outputs/claude_forecast_v2/scratch/verify_inference_contract_tmp9"
c = fv2.load_forecast_candidate(CAND)
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batches = sorted(early_all["batch_id"].unique())
early = early_all.loc[early_all["batch_id"] == batches[0]].reset_index(drop=True)
ref = c.predict(early)

# A) same component with a second measurement_name in the same upload (long format with several measurements)
extra = early.copy(); extra["measurement_name"] = "insulation_resistance_gohm"; extra["measurement_value"] = extra["insulation_resistance_gohm"]
out = c.predict(pd.concat([early, extra]))
print("A) two measurement_names per component -> rows", len(out), "statuses", out["status"].value_counts().to_dict(), "| component_id unique:", out["component_id"].is_unique, "| leakage rows identical to ref:", out.loc[out["measurement_name"] == "leakage_ua"].reset_index(drop=True).equals(ref))

# B) perturbation sensitivity: relative 1e-7 and float32 casting on training batch vs a scaled (non-training) batch
def sens(frame, label):
    base = c.predict(frame).set_index("component_id")["predicted_normalized"]
    for tag, f in (("float32 cast", frame.assign(measurement_value=frame["measurement_value"].astype(np.float32).astype(float))),
                   ("rel 1e-7 noise", frame.assign(measurement_value=frame["measurement_value"] * (1 + 1e-7 * np.random.default_rng(1).standard_normal(len(frame))))),
                   ("rel 1e-4 noise", frame.assign(measurement_value=frame["measurement_value"] * (1 + 1e-4 * np.random.default_rng(1).standard_normal(len(frame)))))):
        p = c.predict(f).set_index("component_id")["predicted_normalized"]
        d = (p - base).abs()
        print(f"B) {label:22s} {tag:15s}: changed {int((d>0).sum())}/{len(d)} parts, max|d|={d.max():.4f} normalized, p99={np.quantile(d,0.99):.4f}")
sens(early, "training batch")
scaled = early.copy(); scaled["measurement_value"] = scaled["measurement_value"] * 1.0137  # off the training grid
sens(scaled, "scaled batch (x1.0137)")

# C) manifest schema holes at load time
shutil.rmtree(SCR, ignore_errors=True)
def variant(tag, mutate):
    d = SCR / tag; shutil.copytree(CAND, d)
    m = json.loads((d / "manifest.json").read_text()); mutate(m); (d / "manifest.json").write_text(json.dumps(m))
    try:
        cc = fv2.load_forecast_candidate(d)
    except Exception as e:  # noqa: BLE001
        print(f"C) {tag:45s} -> load RAISES {type(e).__name__}: {str(e)[:80]}"); return
    try:
        o = cc.predict(early); print(f"C) {tag:45s} -> load OK, predict OK, identical={o.equals(ref)} statuses={o['status'].value_counts().to_dict()}")
    except Exception as e:  # noqa: BLE001
        print(f"C) {tag:45s} -> load OK, predict RAISES {type(e).__name__}: {str(e)[:80]}")
variant("no imputation_medians", lambda m: m.pop("imputation_medians"))
variant("one median missing", lambda m: m["imputation_medians"].pop("initial_fraction_of_limit"))
variant("feature_columns reordered in config", lambda m: m["config"].__setitem__("feature_columns", list(reversed(m["config"]["feature_columns"]))))
variant("config.feature_set -> leakage_plus_aux", lambda m: m["config"].__setitem__("feature_set", "leakage_plus_aux"))
variant("supported_profiles emptied", lambda m: m.__setitem__("supported_profiles", []))
variant("supported_profiles key removed", lambda m: m.pop("supported_profiles"))
variant("config.model -> persistence (booster ignored)", lambda m: m["config"].update(model="persistence", objective=None))
shutil.rmtree(SCR, ignore_errors=True)

# D) timing
t = time.perf_counter(); c.predict(early); t1 = time.perf_counter() - t
t = time.perf_counter(); c.predict(early_all); t2 = time.perf_counter() - t
print(f"D) predict timing: 200 parts {t1:.2f}s; 7200 parts {t2:.2f}s")

# E) threadpool_limits is process-global: check what it touches
from threadpoolctl import threadpool_info
print("E) threadpool libs visible:", [(i["internal_api"], i.get("num_threads")) for i in threadpool_info()])

# F) profile_id given as numeric dtype in upload
f = early.copy(); f["profile_id"] = 1
print("F) numeric profile_id ->", c.predict(f)["status"].value_counts().to_dict())
# G) supported profile but wrong upper_limit for that profile (no per-profile limit check?)
f = early.copy(); f["upper_limit"] = 1000.0
o = c.predict(f); print("G) upper_limit 1000 uA for a 0.7 uA profile -> statuses", o["status"].value_counts().to_dict(), "mean predicted_normalized", o["predicted_normalized"].mean(), "mean uA", o["predicted_final_value"].mean())
# H) all rows have hours 0 and 24 but 24h == 0h exactly (no change) for all -> robust z scale floor
f = early.copy(); v0 = f.loc[f["hours"].astype(float) == 0].set_index("component_id")["measurement_value"]
f.loc[f["hours"].astype(float) == 24, "measurement_value"] = f.loc[f["hours"].astype(float) == 24, "component_id"].map(v0).to_numpy()
o = c.predict(f); print("H) 24h == 0h for every part -> statuses", o["status"].value_counts().to_dict(), "finite preds:", np.isfinite(o["predicted_normalized"]).all())
# I) identical value for every part in the batch (degenerate batch: MAD = 0)
f = early.copy(); f["measurement_value"] = 0.05
o = c.predict(f); print("I) constant batch -> statuses", o["status"].value_counts().to_dict(), "unique preds", o["predicted_normalized"].nunique(), "finite:", np.isfinite(o["predicted_normalized"]).all())
