"""Follow-up: why does leakage_only identify batches above chance? Test whether the
(limit_fraction, current_batch_robust_z) pair exactly encodes the batch median/scale."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score

ROOT = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(ROOT / "src"))
from sih26170 import forecast_v2 as fv2  # noqa: E402

t = fv2.load_training_data(ROOT / "data")
f = t.features
batch = f["batch_id"].to_numpy()
skf = StratifiedKFold(5, shuffle=True, random_state=0)

def acc(cols):
    X = f[cols].to_numpy(dtype=float)
    return cross_val_score(RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=4), X, batch, cv=skf).mean()

print("RF batch-id accuracy (chance 0.028):")
for cols in (["limit_fraction"], ["current_batch_robust_z"], ["limit_fraction", "current_batch_robust_z"],
             ["slope_fraction_per_hour"], ["slope_fraction_per_hour", "slope_batch_robust_z"],
             ["limit_fraction", "current_batch_robust_z", "slope_fraction_per_hour", "slope_batch_robust_z"]):
    print(f"  {str(cols):85s} {acc(cols):.3f}")

# Exact recovery of batch median and scale from the pair: z = 0.6745*(x - med)/scale -> x = med + z*scale/0.6745
# so within a batch x is an affine function of z; the intercept is the batch median (a batch constant).
rows = []
for b, g in f.groupby("batch_id"):
    x = g["current_value"].to_numpy(float); z = g["current_batch_robust_z"].to_numpy(float)
    slope, intercept = np.polyfit(z, x, 1)
    resid = np.abs(x - (intercept + slope * z)).max()
    rows.append((b, intercept, np.median(x), slope * 0.6745, resid))
r = pd.DataFrame(rows, columns=["batch", "recovered_median", "true_median", "recovered_scale", "max_abs_resid"])
print("\nAffine fit x = a + b*z per batch: max |residual| over all batches =", f"{r['max_abs_resid'].max():.2e}")
print("recovered intercept == batch median (max abs diff):", f"{(r['recovered_median'] - r['true_median']).abs().max():.2e}")
print("distinct recovered (median, scale) pairs across 36 batches:", len(r[["recovered_median", "recovered_scale"]].round(12).drop_duplicates()))
print("range of batch medians of 24 h leakage (uA):", r["true_median"].min(), r["true_median"].max())
print("\nBatch-mean of limit_fraction per batch (eta2 0.04): min/max", f.groupby("batch_id")["limit_fraction"].mean().agg(["min", "max"]).round(4).tolist())
