"""Adversarial verification of fold disjointness / contamination claims for forecast_v2."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(ROOT / "src"))
from sih26170 import forecast_v2 as fv2  # noqa: E402
from sih26170.mlcc_prototype import prepare_early_features  # noqa: E402

OUT = ROOT / "outputs" / "claude_forecast_v2"
report: dict = {}

def sec(name):
    print(f"\n=== {name} ===")

# ---------------------------------------------------------------- (2) OOF vs fold_assignment
sec("OOF vs fold_assignment")
folds_csv = pd.read_csv(OUT / "fold_assignment.csv", dtype={"batch_id": str, "profile_id": str})
oof = pd.read_csv(OUT / "oof_predictions.csv", dtype={c: str for c in fv2.IDENTITY})
fold_of_batch = folds_csv.set_index("batch_id")["fold"]
print("fold_assignment rows", len(folds_csv), "unique batches", folds_csv["batch_id"].nunique(),
      "batches per fold", folds_csv["fold"].value_counts().sort_index().to_dict())
assert folds_csv["batch_id"].is_unique, "batch appears twice in fold_assignment"
mapped = oof["batch_id"].map(fold_of_batch)
print("oof rows", len(oof), "rows with fold != batch fold:", int((mapped != oof["fold"]).sum()),
      "unmapped batches:", int(mapped.isna().sum()))
dup = oof.duplicated(["config"] + fv2.IDENTITY).sum()
print("duplicate (config, identity) rows:", int(dup))
per_config = oof.groupby("config").size()
print("rows per config:", per_config.to_dict())
print("all configs 7200 rows:", bool((per_config == 7200).all()), "n configs", len(per_config))
ids_per_config = oof.groupby("config").apply(lambda d: frozenset(map(tuple, d[fv2.IDENTITY].to_numpy())), include_groups=False)
print("identical identity set across configs:", len(set(ids_per_config)) == 1)
# recompute headline MAE from oof
mae = (oof["predicted_normalized"] - oof["y_normalized"]).abs().groupby(oof["config"]).mean()
print("pooled MAE from oof: persistence %.5f xgb_abs_resid_leak %.5f xgb_v1_replica %.5f" % (mae["persistence"], mae["xgb_abs_resid_leak"], mae["xgb_v1_replica"]))
# fold-level: within a config, is each identity in exactly one fold?
folds_per_identity = oof.groupby(["config"] + fv2.IDENTITY)["fold"].nunique()
print("identity appearing in >1 fold within a config:", int((folds_per_identity > 1).sum()))
report["oof"] = {"rows": int(len(oof)), "fold_mismatch": int((mapped != oof["fold"]).sum()), "dup": int(dup), "per_config_7200": bool((per_config == 7200).all())}

# cross-check cv_results per-fold validation_batches against fold_assignment
cv = json.loads((OUT / "cv_results.json").read_text())
mismatch = 0
for name, entry in cv["configs"].items():
    for pf in entry["per_fold"]:
        expected = sorted(folds_csv.loc[folds_csv["fold"] == pf["fold"], "batch_id"])
        if sorted(pf["validation_batches"]) != expected:
            mismatch += 1
print("cv_results per_fold validation_batches mismatching fold_assignment:", mismatch)
print("cv_results predeclaration digest:", cv["predeclaration"]["config_digest"][:16])
print("cv_results fold_assignment == fold_assignment.csv:", pd.DataFrame(cv["fold_assignment"]).astype({"batch_id": str}).sort_values("batch_id").reset_index(drop=True).equals(folds_csv.sort_values("batch_id").reset_index(drop=True)))

# ---------------------------------------------------------------- load training data, recompute folds
sec("Load training data & recompute folds")
training = fv2.load_training_data(ROOT / "data")
feats, labels = training.features, training.labels
print("components", len(feats), "batches", feats["batch_id"].nunique())
print("component_id unique in features:", feats["component_id"].is_unique)
print("component_id -> multiple batches in features:", int(feats.groupby("component_id")["batch_id"].nunique().gt(1).sum()))
print("labels/features identity alignment:", (feats[fv2.IDENTITY].to_numpy() == labels[fv2.IDENTITY].to_numpy()).all())
recomputed = fv2.assign_batch_folds(feats, n_splits=5)
print("recomputed folds == fold_assignment.csv:", recomputed.reset_index(drop=True).equals(folds_csv.sort_values("batch_id").reset_index(drop=True)))
# determinism under row shuffle of the feature frame
rng = np.random.default_rng(7)
shuffled = feats.sample(frac=1.0, random_state=123).reset_index(drop=True)
print("folds invariant to row shuffle:", fv2.assign_batch_folds(shuffled, n_splits=5).equals(recomputed))
# GroupKFold semantics: each batch exactly one fold, every fold has every profile
print("each batch exactly one fold:", recomputed["batch_id"].is_unique and len(recomputed) == feats["batch_id"].nunique())
prof_by_fold = recomputed.groupby("fold")["profile_id"].nunique()
print("profiles per fold:", prof_by_fold.to_dict(), "(total profiles", recomputed["profile_id"].nunique(), ")")
print("batches per (fold, profile):\n", recomputed.groupby(["fold", "profile_id"]).size().unstack(fill_value=0))
fv2.assert_folds_disjoint(feats, recomputed)
for k, tr, va in fv2.fold_masks(feats, recomputed):
    assert not (set(feats.loc[tr, "batch_id"]) & set(feats.loc[va, "batch_id"]))
    assert not (set(feats.loc[tr, "component_id"]) & set(feats.loc[va, "component_id"]))
    assert tr.sum() + va.sum() == len(feats) and not (tr & va).any()
print("fold masks: complementary, batch- and component-disjoint: OK")
# does assert_folds_disjoint actually catch a leak? (sanity of the guard)
bad = recomputed.copy()
try:
    # make the guard face a fold table that omits a batch -> should raise
    fv2.fold_masks(feats, bad.iloc[:-1])
    print("GUARD MISS: fold_masks accepted an incomplete fold table")
except ValueError as e:
    print("fold_masks rejects incomplete table:", e)
# simulate identical component_id in two batches -> the guard should trip
feats_leak = feats.copy()
first_valid_batch = recomputed.loc[recomputed["fold"] == 0, "batch_id"].iloc[0]
donor_idx = feats_leak.index[feats_leak["batch_id"] != first_valid_batch][0]
victim_idx = feats_leak.index[feats_leak["batch_id"] == first_valid_batch][0]
feats_leak.loc[victim_idx, "component_id"] = feats_leak.loc[donor_idx, "component_id"]
try:
    fv2.assert_folds_disjoint(feats_leak, recomputed)
    print("GUARD MISS: assert_folds_disjoint did not catch a shared component_id")
except ValueError as e:
    print("assert_folds_disjoint catches shared component:", e)

# ---------------------------------------------------------------- (3) interval experiment
sec("Interval experiment calibration disjointness")
for name in ("xgb_abs_resid_leak", "xgb_abs_resid_aux", "persistence"):
    p = OUT / f"interval_experiment__{name}.json"
    if not p.exists():
        continue
    rep = json.loads(p.read_text())
    n_batches = feats["batch_id"].nunique()
    cal_sets = []
    for entry in rep["calibration_log"]:
        k = entry["fold"]
        valid_b = set(folds_csv.loc[folds_csv["fold"] == k, "batch_id"])
        cal_b = set(entry["calibration_batches"])
        cal_sets.append(cal_b)
        overlap = cal_b & valid_b
        ok_count = entry["fit_batches"] + len(cal_b) == n_batches - len(valid_b)
        # recompute expected calibration choice
        train_features = feats.loc[~feats["batch_id"].isin(valid_b)].reset_index(drop=True)
        expected_cal = fv2.choose_calibration_batches(train_features, per_profile=2)
        print(f"{name} fold {k}: valid={len(valid_b)} cal={sorted(cal_b)} fit_batches={entry['fit_batches']} "
              f"overlap_with_valid={sorted(overlap)} count_identity_ok={ok_count} cal_matches_rule={sorted(expected_cal)==sorted(cal_b)} cal_components={entry['calibration_components']}")
    # overlap of calibration sets across folds (not leakage, but diversity)
    union = set().union(*cal_sets)
    print(f"{name}: distinct calibration batches used across all folds: {len(union)} -> {sorted(union)}")
    print(f"{name}: calibration_rule: {rep['calibration_rule']}")

# ---------------------------------------------------------------- (4) batch-relative feature locality
sec("Batch-relative features: locality test (recompute on validation-only subset)")
early = fv2.read_identity_csv(ROOT / "data" / "train_early.csv")
cols = sorted(set(fv2.FORECAST_COLUMNS) | set(fv2.AUX_FEATURES) | set(fv2.CHANNEL_PEER_FEATURES))
worst = {}
for k, tr, va in fv2.fold_masks(feats, recomputed):
    valid_batches = set(feats.loc[va, "batch_id"])
    sub_early = early.loc[early["batch_id"].isin(valid_batches)]
    sub_feat, sub_valid_early, unavail = prepare_early_features(sub_early)
    assert not unavail
    sub_feat = fv2.augment_features(sub_feat, sub_valid_early).sort_values(fv2.SORT_KEYS).reset_index(drop=True)
    full_sub = feats.loc[va].sort_values(fv2.SORT_KEYS).reset_index(drop=True)
    assert (sub_feat[fv2.IDENTITY].to_numpy() == full_sub[fv2.IDENTITY].to_numpy()).all()
    for c in cols:
        a = pd.to_numeric(sub_feat[c], errors="coerce").to_numpy(float)
        b = pd.to_numeric(full_sub[c], errors="coerce").to_numpy(float)
        both_nan = np.isnan(a) & np.isnan(b)
        diff = np.where(both_nan, 0.0, np.abs(a - b))
        nan_mismatch = int((np.isnan(a) != np.isnan(b)).sum())
        worst[c] = max(worst.get(c, 0.0), float(np.nanmax(diff)) if len(diff) else 0.0)
        if nan_mismatch:
            print(f"  fold {k} {c}: NaN pattern mismatch {nan_mismatch}")
print("max |full-frame feature - validation-only recompute| per column (0 => purely within-batch):")
for c, v in worst.items():
    print(f"  {c:40s} {v:.3e}")
print("ALL EXACTLY EQUAL:", all(v == 0.0 for v in worst.values()))
# also: single-batch recompute (production-style upload of one batch) equals training frame
one_batch = sorted(feats["batch_id"].unique())[0]
sb_feat, sb_early, _ = prepare_early_features(early.loc[early["batch_id"] == one_batch])
sb_feat = fv2.augment_features(sb_feat, sb_early).sort_values(fv2.SORT_KEYS).reset_index(drop=True)
fb = feats.loc[feats["batch_id"] == one_batch].sort_values(fv2.SORT_KEYS).reset_index(drop=True)
mx = max(float(np.nanmax(np.abs(pd.to_numeric(sb_feat[c]).to_numpy(float) - pd.to_numeric(fb[c]).to_numpy(float)))) for c in cols if not pd.to_numeric(fb[c]).isna().all())
print(f"single-batch recompute of {one_batch}: max abs diff {mx:.3e}")

# ---------------------------------------------------------------- medians: training-portion only?
sec("Imputation medians fitted on training portion only")
cfg = next(c for c in fv2.PREDECLARED_CONFIGS if c.name == "xgb_abs_resid_aux")  # aux has NaNs to impute
for k, tr, va in fv2.fold_masks(feats, recomputed):
    train_features = feats.loc[tr].reset_index(drop=True)
    fitted = fv2.fit_model(cfg, train_features, training.y[tr], seed=fv2.DEFAULT_SEED, n_jobs=2)
    expected = fv2.fit_medians(fv2.feature_matrix(train_features, cfg.feature_columns))
    full_med = fv2.fit_medians(fv2.feature_matrix(feats, cfg.feature_columns))
    same_as_train = fitted.medians == expected
    same_as_full = fitted.medians == full_med
    print(f"fold {k}: medians == train-portion medians: {same_as_train}; == full-data medians: {same_as_full}")
    if k == 1:
        break
nan_counts = fv2.feature_matrix(feats, cfg.feature_columns).isna().sum()
print("NaN counts per aux/leak feature (full data):", {c: int(v) for c, v in nan_counts.items() if v})
# final candidate manifest medians should equal full-data medians for its own feature set
for cand in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    man = json.loads((OUT / "candidate" / cand / "manifest.json").read_text())
    c2 = next(c for c in fv2.PREDECLARED_CONFIGS if c.name == cand)
    fm = fv2.fit_medians(fv2.feature_matrix(feats, c2.feature_columns))
    print(f"candidate {cand}: manifest medians == full-training medians: {man['imputation_medians'] == fm}; training batches {man['training']['batches']}")

# ---------------------------------------------------------------- (6) predeclaration digest
sec("Predeclaration digest")
pre = json.loads((OUT / "PREDECLARED_COMPARISON.json").read_text())
cur = fv2.config_digest(fv2.PREDECLARED_CONFIGS)
print("recorded digest == current code digest:", pre["config_digest"] == cur, pre["config_digest"][:16], cur[:16])
print("cv_results digest == recorded:", cv["predeclaration"]["config_digest"] == pre["config_digest"])
print("keys in PREDECLARED_COMPARISON.json:", sorted(pre.keys()))
print("V1_XGB_PARAMS recorded in JSON?", "xgb_params" in pre or "V1_XGB_PARAMS" in json.dumps(pre))
from dataclasses import replace
edited = list(fv2.PREDECLARED_CONFIGS)
edited[6] = replace(edited[6], params={"learning_rate": 0.05})
print("edit params of one config changes digest:", fv2.config_digest(edited) != cur)
edited2 = list(fv2.PREDECLARED_CONFIGS); edited2[6] = replace(edited2[6], description="x")
print("edit description only changes digest:", fv2.config_digest(edited2) != cur)
edited3 = list(fv2.PREDECLARED_CONFIGS)[:-1]
print("drop last config changes digest:", fv2.config_digest(edited3) != cur)
edited4 = list(fv2.PREDECLARED_CONFIGS); edited4[0], edited4[1] = edited4[1], edited4[0]
print("reorder configs changes digest:", fv2.config_digest(edited4) != cur)
# Things the digest does NOT see:
orig = dict(fv2.V1_XGB_PARAMS)
fv2.V1_XGB_PARAMS["n_estimators"] = 9999
print("changing V1_XGB_PARAMS (shared hyperparameters) changes digest:", fv2.config_digest(fv2.PREDECLARED_CONFIGS) != cur)
fv2.V1_XGB_PARAMS.clear(); fv2.V1_XGB_PARAMS.update(orig)
fv2.FEATURE_SETS["leakage_only"].append("current_value")  # a mutable module-level list
print("appending a column to FEATURE_SETS['leakage_only'] changes digest:", fv2.config_digest(fv2.PREDECLARED_CONFIGS) != cur)
fv2.FEATURE_SETS["leakage_only"].pop()
old = fv2.MIN_CHANNEL_PEERS; fv2.MIN_CHANNEL_PEERS = 1
print("changing MIN_CHANNEL_PEERS (feature formula constant) changes digest:", fv2.config_digest(fv2.PREDECLARED_CONFIGS) != cur)
fv2.MIN_CHANNEL_PEERS = old
print("digest covers to_dict fields:", sorted(fv2.PREDECLARED_CONFIGS[0].to_dict().keys()))
