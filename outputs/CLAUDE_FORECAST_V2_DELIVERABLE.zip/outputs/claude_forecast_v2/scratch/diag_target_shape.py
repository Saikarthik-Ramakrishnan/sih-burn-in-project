"""Diagnostic angle: target shape and objective choice (no model fitting).

Questions:
 1. Distribution of y = final/limit, log1p(y), r = y - limit_fraction (persistence residual),
    overall and per profile. Which parameterisation is closest to symmetric / light-tailed?
 2. Why does a squared-error learner lose to persistence on MAE? Conditional mean vs median
    within bins of the 24 h state (in-sample oracle).
 3. Decompose persistence absolute error by healthy / defect / tester fault and y>=1, and
    by the 116 parts already >= limit at 24 h.
 4. Early-detectable oracle floor (perfect for onset <= 24 h, persistence elsewhere).
 5. MAE in microamps vs normalized MAE by profile.

Run from the pack root with the pack's venv python. Reads data/*.csv only; writes
diag_target_shape_summary.json next to this script.
"""
from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

from sih26170.mlcc_prototype import prepare_early_features

warnings.filterwarnings("ignore")
pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 40)

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
OUT = PACK / "outputs" / "claude_forecast_v2" / "scratch" / "diag_target_shape_summary.json"
G = ["component_id", "batch_id", "component_family", "measurement_name"]
DT = {c: str for c in G}
HORIZON = 168.0 - 24.0

summary: dict[str, object] = {}


def f4(x: float) -> float:
    return float(np.round(x, 4))


# --------------------------------------------------------------------------------------
# Load and join
# --------------------------------------------------------------------------------------
early = pd.read_csv(PACK / "data" / "train_early.csv", dtype=DT)
labels = pd.read_csv(PACK / "data" / "train_labels.csv", dtype=DT)
features, _, unscored = prepare_early_features(early)
assert not unscored, f"unexpected unscored parts: {len(unscored)}"
d = features.merge(labels, on=G, validate="one_to_one", suffixes=("", "_lab"))
assert len(d) == 7200 and d["batch_id"].nunique() == 36
assert np.allclose(d["upper_limit"], d["upper_limit_lab"])

d["y"] = d["final_value"] / d["upper_limit"]
d["y_true"] = d["true_final_value"] / d["upper_limit"]
d["pers"] = d["limit_fraction"]                                   # persistence forecast
d["linex"] = np.maximum(d["limit_fraction"] + d["slope_fraction_per_hour"] * HORIZON, 0.0)
d["r"] = d["y"] - d["pers"]                                        # persistence residual
d["log1p_y"] = np.log1p(d["y"])
d["abs_r"] = d["r"].abs()
d["abs_r_ua"] = (d["final_value"] - d["current_value"]).abs()     # microamp error of persistence
for c in ("is_defect", "is_healthy", "is_tester_fault", "is_observed_final_exceedance", "is_future_failure"):
    d[c] = d[c].astype(bool)
d["exceed24"] = d["limit_fraction"] >= 1.0
d["y_ge1"] = d["y"] >= 1.0

print(f"joined parts: {len(d)}, batches: {d.batch_id.nunique()}, profiles: {d.profile_id.nunique()}")
print("upper limit per profile:", d.groupby("profile_id")["upper_limit"].first().to_dict())
print(f"persistence MAE={d.abs_r.mean():.4f}, mean residual={d.r.mean():+.4f}, median residual={d.r.median():+.5f}")
print(f"linear extrapolation MAE={np.abs(d.y - d.linex).mean():.4f}")

# --------------------------------------------------------------------------------------
# Q1. Distribution shape of y, log1p(y), r
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("Q1. Target parameterisation shape: y = final/limit, log1p(y), r = y - limit_fraction")
print("=" * 100)


def shape_row(s: pd.Series) -> dict[str, float]:
    s = s.to_numpy(dtype=float)
    q = np.quantile(s, [0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
    med = q[3]
    mad = np.median(np.abs(s - med))
    iqr = q[4] - q[2]
    # quartile (Bowley) skew: robust symmetry measure in [-1, 1]
    bowley = ((q[4] - med) - (med - q[2])) / iqr if iqr > 0 else np.nan
    # robust tail weight: (p99-p1)/(p75-p25); normal ~3.45
    tail_ratio = (q[6] - q[0]) / iqr if iqr > 0 else np.nan
    return {
        "n": len(s), "mean": s.mean(), "std": s.std(ddof=0), "min": s.min(),
        "p1": q[0], "p5": q[1], "p25": q[2], "p50": med, "p75": q[4], "p95": q[5], "p99": q[6], "max": s.max(),
        "skew": stats.skew(s), "ex_kurt": stats.kurtosis(s), "bowley_skew": bowley,
        "tail_ratio_p99p1_over_iqr": tail_ratio,
        "share_beyond_5MAD": float(np.mean(np.abs(s - med) > 5 * max(mad, 1e-12))),
        "mad": mad,
    }


shape = pd.DataFrame({k: shape_row(d[k]) for k in ("y", "log1p_y", "r")}).T
print("\nOverall shape statistics (normal reference: skew 0, ex_kurt 0, bowley 0, tail_ratio 3.45):")
print(shape.round(4).to_string())

# shares of y buckets
def bucket_shares(s: pd.Series) -> dict[str, float]:
    return {"lt0.3": float((s < 0.3).mean()), "0.3to1": float(((s >= 0.3) & (s < 1)).mean()), "ge1": float((s >= 1).mean())}

print("\nShare of parts by y bucket, overall:", {k: round(v, 4) for k, v in bucket_shares(d.y).items()})
prof_buckets = d.groupby("profile_id")["y"].apply(lambda s: pd.Series(bucket_shares(s))).unstack()
prof_buckets["n"] = d.groupby("profile_id").size()
prof_buckets["upper_limit"] = d.groupby("profile_id")["upper_limit"].first()
print("\nShare of parts by y bucket, per profile:")
print(prof_buckets.round(4).to_string())

# per-profile quantiles for the three parameterisations
per_prof = []
for k in ("y", "log1p_y", "r"):
    for p, g in d.groupby("profile_id"):
        row = shape_row(g[k]); row["target"] = k; row["profile_id"] = p
        per_prof.append(row)
per_prof = pd.DataFrame(per_prof).set_index(["target", "profile_id"])
cols = ["p1", "p5", "p25", "p50", "p75", "p95", "p99", "max", "skew", "ex_kurt", "bowley_skew", "tail_ratio_p99p1_over_iqr", "share_beyond_5MAD"]
print("\nPer-profile shape of the three parameterisations:")
print(per_prof[cols].round(4).to_string())

# residual shares in signed buckets
r_shares = {
    "r<-0.05": float((d.r < -0.05).mean()),
    "-0.05<=r<-0.02": float(((d.r >= -0.05) & (d.r < -0.02)).mean()),
    "|r|<=0.02": float((d.r.abs() <= 0.02).mean()),
    "0.02<r<=0.3": float(((d.r > 0.02) & (d.r <= 0.3)).mean()),
    "0.3<r<1": float(((d.r > 0.3) & (d.r < 1)).mean()),
    "r>=1": float((d.r >= 1).mean()),
}
print("\nPersistence residual r signed buckets (share of parts):", {k: round(v, 4) for k, v in r_shares.items()})

# log1p(y) shape but also log(y) and log ratio y/pers for comparison
d["log_ratio"] = np.log(d.y.clip(lower=1e-6) / d.pers)
extra_shape = pd.DataFrame({k: shape_row(d[k]) for k in ("log_ratio",)}).T
print("\nExtra: shape of log(y / persistence) (multiplicative residual):")
print(extra_shape[["p1", "p5", "p25", "p50", "p75", "p95", "p99", "skew", "ex_kurt", "bowley_skew", "tail_ratio_p99p1_over_iqr", "share_beyond_5MAD"]].round(4).to_string())

summary["q1_shape_overall"] = {k: {c: f4(v) for c, v in shape.loc[k].items()} for k in shape.index}
summary["q1_shape_log_ratio"] = {c: f4(v) for c, v in extra_shape.loc["log_ratio"].items()}
summary["q1_y_buckets_overall"] = {k: f4(v) for k, v in bucket_shares(d.y).items()}
summary["q1_y_buckets_by_profile"] = {p: {c: f4(v) for c, v in row.items()} for p, row in prof_buckets.iterrows()}
summary["q1_r_signed_buckets"] = {k: f4(v) for k, v in r_shares.items()}
summary["q1_per_profile_shape"] = {
    f"{t}|{p}": {c: f4(v) for c, v in per_prof.loc[(t, p), cols].items()} for (t, p) in per_prof.index
}

# --------------------------------------------------------------------------------------
# Q2. Conditional mean vs conditional median vs persistence, inside 24h-state bins
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("Q2. Squared-error (conditional mean) vs absolute-error (conditional median) inside 24h-state bins")
print("    IN-SAMPLE ORACLE: bin statistics computed on the same parts they are scored on.")
print("=" * 100)

# Unconditional demonstration first: shift persistence by mean residual vs median residual.
mean_r, med_r = d.r.mean(), d.r.median()
mae_shift_mean = np.abs(d.y - (d.pers + mean_r)).mean()
mae_shift_med = np.abs(d.y - (d.pers + med_r)).mean()
mae_const_mean = np.abs(d.y - d.y.mean()).mean()
mae_const_med = np.abs(d.y - d.y.median()).mean()
print(f"\nUnconditional: persistence MAE {d.abs_r.mean():.4f} | persistence + mean residual ({mean_r:+.4f}) MAE {mae_shift_mean:.4f}"
      f" | persistence + median residual ({med_r:+.5f}) MAE {mae_shift_med:.4f}")
print(f"Constant predictors: mean(y)={d.y.mean():.4f} gives MAE {mae_const_mean:.4f}; median(y)={d.y.median():.4f} gives MAE {mae_const_med:.4f}")
# where does the bias-shift lose? healthy vs not
for name, mask in (("healthy", d.is_healthy), ("not healthy", ~d.is_healthy)):
    print(f"   {name:12s} n={mask.sum():5d}: persistence MAE {d.abs_r[mask].mean():.4f} -> shifted-by-mean MAE {np.abs(d.y - (d.pers + mean_r))[mask].mean():.4f}")

summary["q2_unconditional"] = {
    "persistence_mae": f4(d.abs_r.mean()), "mean_residual": f4(mean_r), "median_residual": f4(med_r),
    "mae_persistence_plus_mean_residual": f4(mae_shift_mean), "mae_persistence_plus_median_residual": f4(mae_shift_med),
    "mae_const_mean_y": f4(mae_const_mean), "mae_const_median_y": f4(mae_const_med),
    "mae_shift_mean_healthy": f4(np.abs(d.y - (d.pers + mean_r))[d.is_healthy].mean()),
    "mae_shift_mean_not_healthy": f4(np.abs(d.y - (d.pers + mean_r))[~d.is_healthy].mean()),
}


def oracle_bins(frame: pd.DataFrame, bin_cols: list[str], label: str) -> dict[str, float]:
    grp = frame.groupby(bin_cols, observed=True)
    cmean = grp["y"].transform("mean")
    cmed = grp["y"].transform("median")
    res = {
        "n_bins": int(grp.ngroups),
        "mae_persistence": float(frame.abs_r.mean()),
        "mae_cond_mean": float(np.abs(frame.y - cmean).mean()),
        "mae_cond_median": float(np.abs(frame.y - cmed).mean()),
        "rmse_persistence": float(np.sqrt((frame.r ** 2).mean())),
        "rmse_cond_mean": float(np.sqrt(((frame.y - cmean) ** 2).mean())),
        "rmse_cond_median": float(np.sqrt(((frame.y - cmed) ** 2).mean())),
        "share_parts_cond_mean_worse_than_pers": float((np.abs(frame.y - cmean) > frame.abs_r).mean()),
        "share_parts_cond_median_worse_than_pers": float((np.abs(frame.y - cmed) > frame.abs_r).mean()),
    }
    print(f"\n[{label}] {res['n_bins']} bins | MAE: persistence {res['mae_persistence']:.4f}, cond.mean {res['mae_cond_mean']:.4f}, cond.median {res['mae_cond_median']:.4f}"
          f" | RMSE: persistence {res['rmse_persistence']:.4f}, cond.mean {res['rmse_cond_mean']:.4f}, cond.median {res['rmse_cond_median']:.4f}")
    print(f"   share of parts where cond.mean is worse than persistence: {res['share_parts_cond_mean_worse_than_pers']:.3f}; cond.median worse: {res['share_parts_cond_median_worse_than_pers']:.3f}")
    return res


# bins: deciles of limit_fraction (24h state) crossed with slope_batch_robust_z category
d["lf_decile"] = pd.qcut(d.limit_fraction, 10, labels=False, duplicates="drop")
z_edges = [-np.inf, -1.0, 1.0, 3.0, np.inf]
d["z_cat"] = pd.cut(d.slope_batch_robust_z, z_edges, labels=["z<=-1", "-1<z<=1", "1<z<=3", "z>3"])
delta_edges = [-np.inf, -0.02, 0.0, 0.03, np.inf]
d["delta_cat"] = pd.cut(d.delta_fraction_of_limit, delta_edges, labels=["d<=-0.02", "-0.02<d<=0", "0<d<=0.03", "d>0.03"])

summary["q2_oracle"] = {}
summary["q2_oracle"]["lf_decile_x_slope_z"] = oracle_bins(d, ["lf_decile", "z_cat"], "limit_fraction decile x slope_batch_robust_z category")
summary["q2_oracle"]["lf_decile_x_delta"] = oracle_bins(d, ["lf_decile", "delta_cat"], "limit_fraction decile x delta_fraction_of_limit category")
summary["q2_oracle"]["lf_decile_only"] = oracle_bins(d, ["lf_decile"], "limit_fraction decile only")
# finer: 20 quantile bins of limit_fraction x 5 quantile bins of slope z (100 cells, ~72 parts each)
d["lf_v20"] = pd.qcut(d.limit_fraction, 20, labels=False, duplicates="drop")
d["z_q5"] = pd.qcut(d.slope_batch_robust_z.rank(method="first"), 5, labels=False)
summary["q2_oracle"]["lf_v20_x_z_q5"] = oracle_bins(d, ["lf_v20", "z_q5"], "20 limit_fraction bins x 5 slope-z quantile bins (finer, ~72 parts/cell)")

# Per-bin table for the main binning: conditional mean/median vs persistence median, and MAEs
grp = d.groupby(["lf_decile", "z_cat"], observed=True)
tab = grp.agg(
    n=("y", "size"),
    pers_med=("pers", "median"),
    y_mean=("y", "mean"),
    y_med=("y", "median"),
    y_p90=("y", lambda s: s.quantile(0.9)),
    share_y_ge1=("y_ge1", "mean"),
    share_defect=("is_defect", "mean"),
    mae_pers=("abs_r", "mean"),
)
cmean = grp["y"].transform("mean"); cmed = grp["y"].transform("median")
tab["mae_cmean"] = (d.y - cmean).abs().groupby([d.lf_decile, d.z_cat], observed=True).mean()
tab["mae_cmed"] = (d.y - cmed).abs().groupby([d.lf_decile, d.z_cat], observed=True).mean()
tab["mean_minus_med"] = tab.y_mean - tab.y_med
tab["med_minus_pers"] = tab.y_med - tab.pers_med
tab["sum_abs_pers"] = grp["abs_r"].sum()
tab["share_total_abs"] = tab.sum_abs_pers / d.abs_r.sum()
print("\nPer-bin table (limit_fraction decile x slope z category); sorted by share of total persistence abs error:")
print(tab.sort_values("share_total_abs", ascending=False).round(4).head(16).to_string())
print("\n... bins where the conditional MEAN is pulled >0.05 above the conditional MEDIAN (right-skewed cells):")
skewed = tab[tab.mean_minus_med > 0.05]
print(f"   {len(skewed)} of {len(tab)} bins, holding {int(skewed.n.sum())} parts ({skewed.n.sum()/len(d):.3f} of parts) and {skewed.share_total_abs.sum():.3f} of total persistence abs error")
print(f"   In those bins: MAE persistence {(skewed.mae_pers*skewed.n).sum()/skewed.n.sum():.4f}, cond.mean {(skewed.mae_cmean*skewed.n).sum()/skewed.n.sum():.4f}, cond.median {(skewed.mae_cmed*skewed.n).sum()/skewed.n.sum():.4f}")
calm = tab[tab.mean_minus_med <= 0.05]
print(f"   Remaining {len(calm)} bins ({int(calm.n.sum())} parts): MAE persistence {(calm.mae_pers*calm.n).sum()/calm.n.sum():.4f}, cond.mean {(calm.mae_cmean*calm.n).sum()/calm.n.sum():.4f}, cond.median {(calm.mae_cmed*calm.n).sum()/calm.n.sum():.4f}")
summary["q2_skewed_bins"] = {
    "n_bins_mean_gt_median_by_0.05": int(len(skewed)), "n_bins_total": int(len(tab)),
    "parts_in_skewed_bins": int(skewed.n.sum()), "share_total_abs_in_skewed_bins": f4(skewed.share_total_abs.sum()),
    "skewed_mae_pers": f4((skewed.mae_pers*skewed.n).sum()/skewed.n.sum()),
    "skewed_mae_cmean": f4((skewed.mae_cmean*skewed.n).sum()/skewed.n.sum()),
    "skewed_mae_cmed": f4((skewed.mae_cmed*skewed.n).sum()/skewed.n.sum()),
    "calm_mae_pers": f4((calm.mae_pers*calm.n).sum()/calm.n.sum()),
    "calm_mae_cmean": f4((calm.mae_cmean*calm.n).sum()/calm.n.sum()),
    "calm_mae_cmed": f4((calm.mae_cmed*calm.n).sum()/calm.n.sum()),
}
tab.round(5).to_csv(OUT.with_name("diag_target_shape_bins.csv"))

# how concentrated is the residual near zero? (the point mass a squared-error learner has to sacrifice)
share_tiny = float((d.abs_r < 0.02).mean())
share_mid = float(((d.abs_r >= 0.02) & (d.abs_r < 0.2)).mean())
share_big = float((d.abs_r >= 0.2).mean())
print(f"\nPersistence |r| mass: <0.02 -> {share_tiny:.3f} of parts; 0.02-0.2 -> {share_mid:.3f}; >=0.2 -> {share_big:.3f} (these hold {d.abs_r[d.abs_r>=0.2].sum()/d.abs_r.sum():.3f} of total abs error)")
summary["q2_abs_r_mass"] = {"lt0.02": f4(share_tiny), "0.02to0.2": f4(share_mid), "ge0.2": f4(share_big), "ge0.2_share_total_abs": f4(d.abs_r[d.abs_r>=0.2].sum()/d.abs_r.sum())}

# --------------------------------------------------------------------------------------
# Q3. Decompose persistence absolute error
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("Q3. Decomposition of persistence total absolute error (normalized units)")
print("=" * 100)
total_abs = d.abs_r.sum()
d["health_cat"] = np.select(
    [d.is_healthy, d.is_defect & d.is_tester_fault, d.is_defect, d.is_tester_fault],
    ["healthy", "defect+tester_fault", "defect_only", "tester_fault_only"], default="other")


def decomp(frame: pd.DataFrame, by: list[str]) -> pd.DataFrame:
    g = frame.groupby(by, observed=True)
    out = g.agg(n=("y", "size"), mae=("abs_r", "mean"), mean_r=("r", "mean"), med_r=("r", "median"), sum_abs=("abs_r", "sum"))
    out["share_parts"] = out.n / len(frame)
    out["share_total_abs"] = out.sum_abs / total_abs
    out["contrib_to_overall_mae"] = out.sum_abs / len(frame)
    return out


dec_health = decomp(d, ["health_cat"])
print("\nBy mutually exclusive health category:")
print(dec_health.round(4).to_string())
dec_flags = pd.DataFrame({
    flag: {"n": int(d[flag].sum()), "mae": d.abs_r[d[flag]].mean(), "share_total_abs": d.abs_r[d[flag]].sum() / total_abs}
    for flag in ("is_healthy", "is_defect", "is_tester_fault")
}).T
print("\nBy overlapping flag (is_defect and is_tester_fault overlap on 45 parts):")
print(dec_flags.round(4).to_string())
dec_y = decomp(d, ["y_ge1"])
print("\nBy observed final y >= 1:")
print(dec_y.round(4).to_string())
dec_hy = decomp(d, ["health_cat", "y_ge1"])
print("\nBy health category x y>=1:")
print(dec_hy.round(4).to_string())
dec_24 = decomp(d, ["exceed24"])
print("\nBy already >= limit at 24 h (limit_fraction >= 1):")
print(dec_24.round(4).to_string())
e24 = d[d.exceed24]
print(f"   the {len(e24)} parts already >= limit at 24 h: y median {e24.y.median():.3f}, pers median {e24.pers.median():.3f}, mean residual {e24.r.mean():+.4f}, median residual {e24.r.median():+.4f}, "
      f"{(e24.y >= 1).mean():.3f} still >=1 at 168 h; scenarios {e24.scenario.value_counts().to_dict()}")
dec_scn = decomp(d, ["scenario"]).sort_values("share_total_abs", ascending=False)
print("\nBy scenario (for reference):")
print(dec_scn.round(4).to_string())

summary["q3_by_health_cat"] = {k: {c: f4(v) for c, v in row.items()} for k, row in dec_health.iterrows()}
summary["q3_by_flag_overlapping"] = {k: {c: f4(v) for c, v in row.items()} for k, row in dec_flags.iterrows()}
summary["q3_by_y_ge1"] = {str(k): {c: f4(v) for c, v in row.items()} for k, row in dec_y.iterrows()}
summary["q3_by_health_x_yge1"] = {f"{k[0]}|y_ge1={k[1]}": {c: f4(v) for c, v in row.items()} for k, row in dec_hy.iterrows()}
summary["q3_by_exceed24"] = {str(k): {c: f4(v) for c, v in row.items()} for k, row in dec_24.iterrows()}
summary["q3_exceed24_detail"] = {"n": int(len(e24)), "y_median": f4(e24.y.median()), "pers_median": f4(e24.pers.median()),
                                 "mean_r": f4(e24.r.mean()), "median_r": f4(e24.r.median()), "share_still_ge1": f4((e24.y >= 1).mean())}

# --------------------------------------------------------------------------------------
# Q4. Oracle floors
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("Q4. Oracle MAE floors (perfect prediction for a subset, persistence elsewhere)")
print("=" * 100)
onset = d.anomaly_onset_hour            # NaN when not a defect
t_onset = d.tester_fault_onset_hour     # NaN when no tester fault
masks = {
    "none (persistence)": pd.Series(False, index=d.index),
    "defect onset <= 24h": onset.le(24).fillna(False),
    "defect onset <= 24h OR tester onset <= 24h": onset.le(24).fillna(False) | t_onset.le(24).fillna(False),
    "any defect (all onsets)": d.is_defect,
    "any defect OR any tester fault": d.is_defect | d.is_tester_fault,
    "defect onset > 24h only": onset.gt(24).fillna(False),
    "tester onset 72h only": t_onset.eq(72).fillna(False),
    "already >= limit at 24h": d.exceed24,
    "all parts (all-oracle)": pd.Series(True, index=d.index),
}
floors = []
for name, m in masks.items():
    err = d.abs_r.where(~m, 0.0)
    floors.append({"oracle_subset": name, "n_perfect": int(m.sum()), "mae_floor": err.mean(),
                   "share_of_persistence_error_removed": 1 - err.sum() / total_abs})
floors = pd.DataFrame(floors).set_index("oracle_subset")
print(floors.round(4).to_string())
# by onset hour: how much of the error sits in each onset
onset_tab = d[d.is_defect].groupby("anomaly_onset_hour").agg(n=("y", "size"), mae=("abs_r", "mean"), sum_abs=("abs_r", "sum"))
onset_tab["share_total_abs"] = onset_tab.sum_abs / total_abs
print("\nDefect parts by onset hour (share of TOTAL persistence abs error):")
print(onset_tab.round(4).to_string())
t_tab = d[d.is_tester_fault].groupby("tester_fault_onset_hour").agg(n=("y", "size"), mae=("abs_r", "mean"), sum_abs=("abs_r", "sum"))
t_tab["share_total_abs"] = t_tab.sum_abs / total_abs
print("\nTester-fault parts by fault onset hour:")
print(t_tab.round(4).to_string())
# noise floor: even perfect knowledge of the latent trajectory leaves measurement noise in final_value
noise_mae = np.abs(d.y - d.y_true).mean()
print(f"\nMeasurement-noise floor |final - true_final|/limit: MAE {noise_mae:.4f} overall; healthy only {np.abs(d.y - d.y_true)[d.is_healthy].mean():.4f}; tester fault only {np.abs(d.y - d.y_true)[d.is_tester_fault].mean():.4f}")
print("   (a predictor of the LATENT truth cannot beat this on the OBSERVED target; the all-oracle floor of 0 assumes observed-noise is predictable, which it is not)")
summary["q4_oracle_floors"] = {k: {c: f4(v) for c, v in row.items()} for k, row in floors.iterrows()}
summary["q4_by_onset_hour"] = {str(int(k)): {c: f4(v) for c, v in row.items()} for k, row in onset_tab.iterrows()}
summary["q4_by_tester_onset_hour"] = {str(int(k)): {c: f4(v) for c, v in row.items()} for k, row in t_tab.iterrows()}
summary["q4_noise_floor_mae"] = {"overall": f4(noise_mae), "healthy": f4(np.abs(d.y - d.y_true)[d.is_healthy].mean()), "tester_fault": f4(np.abs(d.y - d.y_true)[d.is_tester_fault].mean())}

# --------------------------------------------------------------------------------------
# Q5. Microamp MAE vs normalized MAE by profile
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("Q5. Persistence error by profile: microamps vs normalized")
print("=" * 100)
prof = d.groupby("profile_id").agg(
    n=("y", "size"), upper_limit=("upper_limit", "first"),
    mae_norm=("abs_r", "mean"), mae_ua=("abs_r_ua", "mean"),
    med_abs_norm=("abs_r", "median"), sum_abs_norm=("abs_r", "sum"), sum_abs_ua=("abs_r_ua", "sum"),
    share_y_ge1=("y_ge1", "mean"), share_defect=("is_defect", "mean"), share_tester=("is_tester_fault", "mean"),
    y_med=("y", "median"), y_p99=("y", lambda s: s.quantile(0.99)),
)
prof["share_total_abs_norm"] = prof.sum_abs_norm / prof.sum_abs_norm.sum()
prof["share_total_abs_ua"] = prof.sum_abs_ua / prof.sum_abs_ua.sum()
prof["rank_norm"] = prof.mae_norm.rank(ascending=False).astype(int)
prof["rank_ua"] = prof.mae_ua.rank(ascending=False).astype(int)
prof = prof.sort_values("upper_limit")
print(prof.round(4).to_string())
rho = stats.spearmanr(prof.mae_norm, prof.mae_ua).statistic
print(f"\nSpearman rank correlation of profile MAE ranking, normalized vs uA: {rho:.3f}")
print(f"Overall persistence MAE in uA: {d.abs_r_ua.mean():.4f} uA (normalized {d.abs_r.mean():.4f}); the 1.3 uA profile holds {prof.loc[prof.upper_limit.idxmax(), 'share_total_abs_ua']:.3f} of uA error vs {prof.loc[prof.upper_limit.idxmax(), 'share_total_abs_norm']:.3f} of normalized error")
# healthy parts: microamp noise floor scales with the limit
hp = d[d.is_healthy].groupby("profile_id").agg(mae_norm=("abs_r", "mean"), mae_ua=("abs_r_ua", "mean"), upper_limit=("upper_limit", "first")).sort_values("upper_limit")
print("\nHealthy-only persistence MAE per profile (noise floor):")
print(hp.round(5).to_string())
summary["q5_by_profile"] = {k: {c: f4(v) if isinstance(v, (float, np.floating, int, np.integer)) else v for c, v in row.items()} for k, row in prof.iterrows()}
summary["q5_spearman_norm_vs_ua"] = f4(rho)
summary["q5_overall_mae_ua"] = f4(d.abs_r_ua.mean())
summary["q5_healthy_by_profile"] = {k: {c: f4(v) for c, v in row.items()} for k, row in hp.iterrows()}

# --------------------------------------------------------------------------------------
# Robustness checks (no model family; bin statistics only)
# --------------------------------------------------------------------------------------
print("\n" + "=" * 100)
print("R1. Out-of-fold bin statistics: GroupKFold(5) over batch_id (sorted), bin edges + bin mean/median from the train folds")
print("    This is NOT a model search; it checks whether the in-sample median-vs-mean gap survives whole-batch holdout.")
print("=" * 100)
from sklearn.model_selection import GroupKFold  # noqa: E402

ds = d.sort_values(["batch_id", "component_id"]).reset_index(drop=True)
gkf = GroupKFold(n_splits=5)
oof_mean = np.full(len(ds), np.nan)
oof_med = np.full(len(ds), np.nan)
oof_shift_mean = np.full(len(ds), np.nan)
oof_shift_med = np.full(len(ds), np.nan)
fallback = 0
fold_rows = []
for k, (tr, va) in enumerate(gkf.split(ds, groups=ds["batch_id"])):
    trd, vad = ds.iloc[tr], ds.iloc[va]
    edges = np.quantile(trd.limit_fraction, np.linspace(0, 1, 11))
    edges[0], edges[-1] = -np.inf, np.inf
    tr_bin = pd.cut(trd.limit_fraction, edges, labels=False)
    va_bin = pd.cut(vad.limit_fraction, edges, labels=False)
    tr_z = pd.cut(trd.slope_batch_robust_z, z_edges, labels=False)
    va_z = pd.cut(vad.slope_batch_robust_z, z_edges, labels=False)
    key_tr = pd.MultiIndex.from_arrays([tr_bin, tr_z])
    key_va = pd.MultiIndex.from_arrays([va_bin, va_z])
    stats_tr = trd.groupby([tr_bin.values, tr_z.values])["y"].agg(["mean", "median"])
    stats_tr.index = pd.MultiIndex.from_tuples(stats_tr.index)
    m = np.array(stats_tr["mean"].reindex(key_va).to_numpy(), dtype=float, copy=True)
    md = np.array(stats_tr["median"].reindex(key_va).to_numpy(), dtype=float, copy=True)
    miss = np.isnan(m)
    fallback += int(miss.sum())
    m[miss] = vad.pers.to_numpy()[miss]
    md[miss] = vad.pers.to_numpy()[miss]
    oof_mean[va], oof_med[va] = m, md
    oof_shift_mean[va] = vad.pers + trd.r.mean()
    oof_shift_med[va] = vad.pers + trd.r.median()
    fold_rows.append({"fold": k, "n_val": len(va), "val_batches": int(vad.batch_id.nunique()),
                      "mae_pers": vad.abs_r.mean(), "mae_oof_mean": np.abs(vad.y - m).mean(), "mae_oof_median": np.abs(vad.y - md).mean()})
fold_tab = pd.DataFrame(fold_rows).set_index("fold")
print(fold_tab.round(4).to_string())
oof = {
    "mae_persistence": float(ds.abs_r.mean()),
    "mae_oof_bin_mean": float(np.abs(ds.y - oof_mean).mean()),
    "mae_oof_bin_median": float(np.abs(ds.y - oof_med).mean()),
    "rmse_persistence": float(np.sqrt((ds.r ** 2).mean())),
    "rmse_oof_bin_mean": float(np.sqrt(((ds.y - oof_mean) ** 2).mean())),
    "rmse_oof_bin_median": float(np.sqrt(((ds.y - oof_med) ** 2).mean())),
    "mae_oof_pers_plus_train_mean_resid": float(np.abs(ds.y - oof_shift_mean).mean()),
    "mae_oof_pers_plus_train_median_resid": float(np.abs(ds.y - oof_shift_med).mean()),
    "n_val_parts_with_empty_train_bin_fallback": fallback,
    "share_parts_oof_mean_worse_than_pers": float((np.abs(ds.y - oof_mean) > ds.abs_r).mean()),
    "share_parts_oof_median_worse_than_pers": float((np.abs(ds.y - oof_med) > ds.abs_r).mean()),
    "median_win_folds": int((fold_tab.mae_oof_median < fold_tab.mae_pers).sum()),
    "mean_win_folds": int((fold_tab.mae_oof_mean < fold_tab.mae_pers).sum()),
}
print("\nOut-of-fold pooled:", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in oof.items()})
summary["r1_oof_bin_stats"] = {k: (f4(v) if isinstance(v, float) else v) for k, v in oof.items()}
summary["r1_oof_by_fold"] = {str(k): {c: f4(v) for c, v in row.items()} for k, row in fold_tab.iterrows()}

print("\n" + "=" * 100)
print("R2. Is a defect with onset <= 24 h actually visible at 24 h? Robust-z signal by onset hour vs healthy parts")
print("=" * 100)
vis = d.groupby(d.anomaly_onset_hour.fillna(-1)).agg(
    n=("y", "size"),
    med_abs_slope_z=("slope_batch_robust_z", lambda s: s.abs().median()),
    share_slope_z_gt3=("slope_batch_robust_z", lambda s: (s > 3).mean()),
    share_cur_z_gt3=("current_batch_robust_z", lambda s: (s > 3).mean()),
    share_either_gt3=("slope_batch_robust_z", lambda s: ((s > 3) | (d.loc[s.index, "current_batch_robust_z"] > 3)).mean()),
    med_delta_frac=("delta_fraction_of_limit", "median"),
    mae_pers=("abs_r", "mean"),
)
vis.index = ["no defect" if i < 0 else f"onset {int(i)}h" for i in vis.index]
healthy_ref = d[d.is_healthy]
print(vis.round(4).to_string())
print(f"   healthy reference: share slope_z>3 {(healthy_ref.slope_batch_robust_z > 3).mean():.4f}, share current_z>3 {(healthy_ref.current_batch_robust_z > 3).mean():.4f}")
summary["r2_visibility_by_onset"] = {k: {c: f4(v) for c, v in row.items()} for k, row in vis.iterrows()}
summary["r2_healthy_ref"] = {"share_slope_z_gt3": f4((healthy_ref.slope_batch_robust_z > 3).mean()), "share_cur_z_gt3": f4((healthy_ref.current_batch_robust_z > 3).mean())}

extra_masks = {
    "defect onset < 24h (<=12h)": onset.le(12).fillna(False),
    "defect onset <= 24h AND (slope_z>3 or current_z>3) [signal-visible]": onset.le(24).fillna(False) & ((d.slope_batch_robust_z > 3) | (d.current_batch_robust_z > 3)),
    "any part with slope_z>3 or current_z>3 [signal-visible, label-free subset]": (d.slope_batch_robust_z > 3) | (d.current_batch_robust_z > 3),
}
extra_floors = []
for name, m in extra_masks.items():
    err = d.abs_r.where(~m, 0.0)
    extra_floors.append({"oracle_subset": name, "n_perfect": int(m.sum()), "mae_floor": err.mean(), "share_of_persistence_error_removed": 1 - err.sum() / total_abs})
extra_floors = pd.DataFrame(extra_floors).set_index("oracle_subset")
print("\nAdditional oracle floors:")
print(extra_floors.round(4).to_string())
summary["q4_oracle_floors_extra"] = {k: {c: f4(v) for c, v in row.items()} for k, row in extra_floors.iterrows()}

OUT.write_text(json.dumps(summary, indent=1, default=float))
print(f"\nSummary written to {OUT}")
