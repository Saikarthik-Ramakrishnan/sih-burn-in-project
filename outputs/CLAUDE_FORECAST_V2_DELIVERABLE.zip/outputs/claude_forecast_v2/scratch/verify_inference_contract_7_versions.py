"""Check 7: version mismatch behaviour, tampered artifacts, manifest tampering (integrity bypass)."""
import json
import shutil
from pathlib import Path

import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_leak"
SCR = PACK / "outputs/claude_forecast_v2/scratch/verify_inference_contract_tmp"
shutil.rmtree(SCR, ignore_errors=True); SCR.mkdir(parents=True)
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
early = early_all.loc[early_all["batch_id"] == sorted(early_all["batch_id"].unique())[0]]
ref = fv2.load_forecast_candidate(CAND).predict(early)


def copy(tag):
    d = SCR / tag
    shutil.copytree(CAND, d)
    return d


def attempt(tag, d, **kw):
    try:
        c = fv2.load_forecast_candidate(d, **kw)
        out = c.predict(early)
        same = out.equals(ref)
        print(f"{tag:50s} -> LOADS; predict identical to reference: {same}")
        return c
    except Exception as e:  # noqa: BLE001
        print(f"{tag:50s} -> RAISES {type(e).__name__}: {str(e)[:120]}")


# 1) wrong xgboost version in manifest
d = copy("wrong_xgb"); m = json.loads((d / "manifest.json").read_text()); m["environment"]["versions"]["xgboost"] = "2.1.0"; (d / "manifest.json").write_text(json.dumps(m))
attempt("xgboost version mismatch, strict (default)", d)
attempt("xgboost version mismatch, strict_versions=False", d, strict_versions=False)
# 2) wrong pandas version
d = copy("wrong_pandas"); m = json.loads((d / "manifest.json").read_text()); m["environment"]["versions"]["pandas"] = "2.2.0"; (d / "manifest.json").write_text(json.dumps(m))
attempt("pandas version mismatch, strict", d)
# 3) scipy mismatch (not in the checked list?)
d = copy("wrong_scipy"); m = json.loads((d / "manifest.json").read_text()); m["environment"]["versions"]["scipy"] = "0.0.1"; m["environment"]["python"] = "3.9.0"; (d / "manifest.json").write_text(json.dumps(m))
attempt("scipy+python version mismatch, strict", d)
# 4) environment key missing entirely
d = copy("no_env"); m = json.loads((d / "manifest.json").read_text()); del m["environment"]; (d / "manifest.json").write_text(json.dumps(m))
attempt("manifest without environment block, strict", d)
# 5) tamper model.ubj
d = copy("tamper_ubj"); b = (d / "model.ubj").read_bytes(); (d / "model.ubj").write_bytes(b[:-1] + bytes([b[-1] ^ 0xFF]))
attempt("model.ubj flipped last byte", d)
# 6) tamper model.json only (not used for prediction but hashed)
d = copy("tamper_json"); (d / "model.json").write_text((d / "model.json").read_text() + " ")
attempt("model.json appended space", d)
# 7) delete artifact_sha256 from manifest -> integrity check bypass?
d = copy("no_hashes"); m = json.loads((d / "manifest.json").read_text()); del m["artifact_sha256"]; (d / "manifest.json").write_text(json.dumps(m))
b = (d / "model.ubj").read_bytes(); (d / "model.ubj").write_bytes(b[:-1] + bytes([b[-1] ^ 0xFF]))
attempt("artifact_sha256 removed + model.ubj tampered", d)
# 8) manifest imputation medians tampered (manifest itself is not hashed)
d = copy("tamper_medians"); m = json.loads((d / "manifest.json").read_text()); m["imputation_medians"]["limit_fraction"] = 99.0; m["supported_profiles"] = ["SIM_X7R_1U_25V"]; (d / "manifest.json").write_text(json.dumps(m))
attempt("manifest medians/supported_profiles edited (no hash on manifest)", d)
# 9) swap in the aux model.ubj with leak manifest (feature count mismatch) - rehash so integrity passes
d = copy("swap_model"); shutil.copy(PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_aux/model.ubj", d / "model.ubj"); shutil.copy(PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_aux/model.json", d / "model.json")
m = json.loads((d / "manifest.json").read_text()); m["artifact_sha256"] = {"model.ubj": fv2._hash_file(d / "model.ubj"), "model.json": fv2._hash_file(d / "model.json")}; (d / "manifest.json").write_text(json.dumps(m))
attempt("aux model.ubj under leak manifest (17 vs 10 features)", d)
# 10) candidate_version mismatch
d = copy("wrong_version"); m = json.loads((d / "manifest.json").read_text()); m["candidate_version"] = "claude-forecast-v1.9"; (d / "manifest.json").write_text(json.dumps(m))
attempt("candidate_version mismatch", d)
# 11) missing model.ubj
d = copy("no_ubj"); (d / "model.ubj").unlink()
attempt("model.ubj missing", d)
# 12) manifest config mutated to a different target (normalized) -> predict silently changes semantics
d = copy("target_swap"); m = json.loads((d / "manifest.json").read_text()); m["config"]["target"] = "normalized"; (d / "manifest.json").write_text(json.dumps(m))
c = attempt("manifest config.target changed to 'normalized'", d)
if c is not None:
    o = c.predict(early); print("   -> mean predicted_normalized", o["predicted_normalized"].mean(), "vs reference", ref["predicted_normalized"].mean())
# 13) string path vs Path
attempt("str path", str(CAND))
# 14) manifest with model.json as the load target? (only ubj loaded) - check that model.json reproduces identical predictions
from xgboost import XGBRegressor
r = XGBRegressor(); r.load_model(CAND / "model.json")
c = fv2.load_forecast_candidate(CAND); c.booster = r
print("model.json booster gives identical predictions:", c.predict(early).equals(ref))
shutil.rmtree(SCR, ignore_errors=True)
