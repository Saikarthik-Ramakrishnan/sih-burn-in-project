"""diag_interval_design.py -- what a v2 prediction-interval proposal must handle.

Uses persistence residuals r = y - limit_fraction (y = final_value/upper_limit)
as a proxy for forecast residuals. No fitted models. Labels are used only to
explain errors retrospectively. Whole-batch GroupKFold (5 folds, batches sorted
by batch_id) is used wherever a quantity is "estimated" on one set of batches
and "evaluated" on another.
"""
from __future__ import annotations

import json
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import GroupKFold

from sih26170.mlcc_prototype import prepare_early_features

warnings.filterwarnings("ignore")
pd.set_option("display.width", 220)
pd.set_option("display.max_columns", 40)
pd.set_option("display.float_format", lambda v: f"{v:.4f}")

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
OUT = PACK / "outputs" / "claude_forecast_v2" / "scratch"
G = ["component_id", "batch_id", "component_family", "measurement_name"]
DT = {c: str for c in G}
ALPHA = 0.10
M = 200  # parts per batch
RESULTS: dict[str, object] = {}


def flag(s: pd.Series) -> pd.Series:
    return s.astype(str).str.strip().str.lower().eq("true")


def conformal_q(abs_res: np.ndarray, alpha: float = ALPHA) -> float:
    """Finite-sample split-conformal quantile (same rule as mlcc_prototype.conformal_radius)."""
    a = np.sort(np.asarray(abs_res, dtype=float))
    n = len(a)
    rank = math.ceil((n + 1) * (1 - alpha))
    if n == 0 or rank > n:
        return float("inf")
    return float(a[rank - 1])


def signed_bounds(res: np.ndarray, alpha: float = ALPHA) -> tuple[float, float]:
    """Two-sided asymmetric bounds: lower at alpha/2, upper at 1-alpha/2 (conservative ranks)."""
    a = np.sort(np.asarray(res, dtype=float))
    n = len(a)
    hi_rank = math.ceil((n + 1) * (1 - alpha / 2))
    lo_rank = math.floor((n + 1) * (alpha / 2))
    hi = a[hi_rank - 1] if hi_rank <= n else float("inf")
    lo = a[lo_rank - 1] if lo_rank >= 1 else float("-inf")
    return float(lo), float(hi)


def spread_table(d: pd.DataFrame, key: pd.Series, name: str) -> pd.DataFrame:
    g = d.assign(_bin=key.values).groupby("_bin", observed=True)
    t = g.agg(
        n=("r", "size"),
        defect_share=("is_defect", "mean"),
        r_median=("r", "median"),
        r_mean=("r", "mean"),
        r_p5=("r", lambda s: s.quantile(0.05)),
        r_p95=("r", lambda s: s.quantile(0.95)),
        iqr=("r", lambda s: s.quantile(0.75) - s.quantile(0.25)),
        mad=("r", lambda s: (s - s.median()).abs().median()),
        abs_r_p50=("abs_r", "median"),
        abs_r_p90=("abs_r", lambda s: s.quantile(0.90)),
    )
    t.index.name = name
    return t


# ---------------------------------------------------------------- 0. load + join
early = pd.read_csv(PACK / "data" / "train_early.csv", dtype=DT)
labels = pd.read_csv(PACK / "data" / "train_labels.csv", dtype=DT)
feat, _early_valid, unscored = prepare_early_features(early)
assert len(unscored) == 0 and len(feat) == 7200, (len(unscored), len(feat))

meta = early.drop_duplicates(G)[G + ["profile_id", "tester_id"]]
lab = labels[G + ["final_value", "true_final_value", "is_defect", "is_healthy", "is_tester_fault",
                  "scenario", "anomaly_onset_hour", "tester_fault_onset_hour"]].copy()
for c in ("is_defect", "is_healthy", "is_tester_fault"):
    lab[c] = flag(lab[c])
d = feat.merge(meta, on=G, validate="one_to_one").merge(lab, on=G, validate="one_to_one")
d["y"] = d["final_value"] / d["upper_limit"]
d["r"] = d["y"] - d["limit_fraction"]
d["abs_r"] = d["r"].abs()
d["abs_z"] = d["slope_batch_robust_z"].abs()
d = d.sort_values(["batch_id", "component_id"]).reset_index(drop=True)
assert d["batch_id"].nunique() == 36

print("=" * 100)
print("0. PERSISTENCE RESIDUAL r = y - limit_fraction  (n=%d parts, %d batches)" % (len(d), d.batch_id.nunique()))
print("=" * 100)
overall = {
    "mae": d.abs_r.mean(), "mean_r": d.r.mean(), "median_r": d.r.median(),
    "p5": d.r.quantile(0.05), "p95": d.r.quantile(0.95),
    "abs_q90_conformal": conformal_q(d.abs_r.values),
    "share_r_pos": (d.r > 0).mean(),
    "n_healthy": int(d.is_healthy.sum()), "n_defect": int(d.is_defect.sum()), "n_tester_fault": int(d.is_tester_fault.sum()),
}
print(pd.Series(overall).to_string())
RESULTS["overall"] = {k: float(v) for k, v in overall.items()}

# ---------------------------------------------------------------- 1. heteroscedasticity
print("\n" + "=" * 100)
print("1. HETEROSCEDASTICITY OF r")
print("=" * 100)
lf_edges = [0, 0.08, 0.12, 0.16, 0.25, 0.5, 1.0, np.inf]
t_lf = spread_table(d, pd.cut(d.limit_fraction, lf_edges, right=False), "limit_fraction_bin")
print("\n-- by limit_fraction (x24/limit) bin --")
print(t_lf.to_string())

az_edges = [0, 1, 2, 5, 10, np.inf]
t_az = spread_table(d, pd.cut(d.abs_z, az_edges, right=False), "abs_slope_robust_z_bin")
print("\n-- by |slope_batch_robust_z| bin --")
print(t_az.to_string())

sz_edges = [-np.inf, -2, 0, 2, 5, np.inf]
t_sz = spread_table(d, pd.cut(d.slope_batch_robust_z, sz_edges, right=False), "signed_slope_robust_z_bin")
print("\n-- by SIGNED slope_batch_robust_z bin (negative = settling faster than batch peers) --")
print(t_sz.to_string())

df_edges = [-np.inf, -0.03, -0.01, 0.0, 0.01, 0.03, 0.10, 0.30, np.inf]
t_df = spread_table(d, pd.cut(d.delta_fraction_of_limit, df_edges, right=False), "delta_fraction_of_limit_bin")
print("\n-- by delta_fraction_of_limit (x24-x0)/limit bin --")
print(t_df.to_string())

t_pr = spread_table(d, d.profile_id, "profile_id")
print("\n-- by profile --")
print(t_pr.to_string())

t_sc = spread_table(d, d.scenario, "scenario")
print("\n-- by scenario (retrospective explanation only) --")
print(t_sc.to_string())

RESULTS["hetero"] = {
    "limit_fraction": t_lf.reset_index().astype(str).to_dict(orient="records"),
    "abs_slope_z": t_az.reset_index().astype(str).to_dict(orient="records"),
    "signed_slope_z": t_sz.reset_index().astype(str).to_dict(orient="records"),
    "delta_fraction": t_df.reset_index().astype(str).to_dict(orient="records"),
    "profile": t_pr.reset_index().astype(str).to_dict(orient="records"),
}

# single absolute-residual radius (v1 method), descriptive in-sample version
R_all = conformal_q(d.abs_r.values)
d["cov_single"] = d.abs_r <= R_all
healthy = d[d.is_healthy]
defect = d[d.is_defect]
tf = d[d.is_tester_fault]
single = {
    "radius_q90_all": R_all,
    "width": 2 * R_all,
    "coverage_all": d.cov_single.mean(),
    "coverage_healthy": healthy.cov_single.mean(),
    "coverage_defect": defect.cov_single.mean(),
    "coverage_tester_fault": tf.cov_single.mean(),
    "coverage_defect_onset_le24": d[d.is_defect & (d.anomaly_onset_hour <= 24)].cov_single.mean(),
    "coverage_defect_onset_gt24": d[d.is_defect & (d.anomaly_onset_hour > 24)].cov_single.mean(),
    "healthy_abs_r_median": healthy.abs_r.median(),
    "healthy_abs_r_p90": healthy.abs_r.quantile(0.9),
    "healthy_abs_r_p99": healthy.abs_r.quantile(0.99),
    "width_over_healthy_median_abs_r": 2 * R_all / healthy.abs_r.median(),
    "width_over_healthy_p90_abs_r": 2 * R_all / healthy.abs_r.quantile(0.9),
    "radius_needed_healthy_only_q90": conformal_q(healthy.abs_r.values),
    "radius_needed_defect_only_q90": conformal_q(defect.abs_r.values),
    "radius_needed_all_q99": conformal_q(d.abs_r.values, 0.01),
}
print("\n-- single symmetric radius = conformal 90% quantile of |r| over ALL parts (v1 method, in-sample) --")
print(pd.Series(single).to_string())
print("\n-- coverage of the single radius by scenario --")
cov_sc = d.groupby("scenario").agg(n=("r", "size"), coverage=("cov_single", "mean"), abs_r_p50=("abs_r", "median")).sort_values("coverage")
print(cov_sc.to_string())
RESULTS["single_radius"] = {k: float(v) for k, v in single.items()}
RESULTS["single_radius_by_scenario"] = cov_sc.reset_index().astype(str).to_dict(orient="records")

# ---------------------------------------------------------------- 2. sign asymmetry
print("\n" + "=" * 100)
print("2. SIGN ASYMMETRY OF r")
print("=" * 100)


def sign_row(s: pd.Series) -> dict[str, float]:
    return {
        "n": len(s), "p1": s.quantile(0.01), "p5": s.quantile(0.05), "p25": s.quantile(0.25), "p50": s.median(),
        "p75": s.quantile(0.75), "p95": s.quantile(0.95), "p99": s.quantile(0.99),
        "share_pos": (s > 0).mean(), "share_below_minus_R": (s < -R_all).mean(), "share_above_plus_R": (s > R_all).mean(),
    }


sign_tab = pd.DataFrame({
    "all": sign_row(d.r), "is_defect": sign_row(defect.r), "not_defect": sign_row(d[~d.is_defect].r),
    "is_healthy": sign_row(healthy.r), "tester_fault": sign_row(tf.r),
}).T
print(sign_tab.to_string())
lo_all, hi_all = signed_bounds(d.r.values)
asym = {
    "sym_width_2R": 2 * R_all,
    "asym_lower_q05": lo_all, "asym_upper_q95": hi_all, "asym_width": hi_all - lo_all,
    "asym_width_over_sym_width": (hi_all - lo_all) / (2 * R_all),
    "sym_lower_half_wasted_share": (R_all - abs(lo_all)) / (2 * R_all),  # fraction of symmetric width below the forecast that r never reaches at 5%
    "misses_below_sym": int((d.r < -R_all).sum()), "misses_above_sym": int((d.r > R_all).sum()),
    "share_lower_bound_below_zero_sym": float(((d.limit_fraction - R_all) < 0).mean()),
    "share_lower_bound_below_zero_asym": float(((d.limit_fraction + lo_all) < 0).mean()),
    "healthy_min_r": float(healthy.r.min()), "healthy_p0_1_r": float(healthy.r.quantile(0.001)),
}
print("\n-- symmetric vs asymmetric 90% interval (in-sample, all parts) --")
print(pd.Series(asym).to_string())
RESULTS["sign_asymmetry"] = {"table": sign_tab.reset_index().astype(str).to_dict(orient="records"),
                             "summary": {k: float(v) for k, v in asym.items()}}

# ---------------------------------------------------------------- folds
gkf = GroupKFold(n_splits=5)
folds = []
for i, (tr, va) in enumerate(gkf.split(d, groups=d.batch_id)):
    tr_b = sorted(d.batch_id.iloc[tr].unique())
    va_b = sorted(d.batch_id.iloc[va].unique())
    folds.append((i, tr_b, va_b))
print("\n" + "=" * 100)
print("GroupKFold(5) on batch_id (frame sorted by batch_id, component_id)")
print("=" * 100)
for i, tr_b, va_b in folds:
    vd = d[d.batch_id.isin(va_b)]
    print(f"fold {i}: {len(tr_b)} train batches, val = {va_b} | val defects={int(vd.is_defect.sum())}, val tester_fault={int(vd.is_tester_fault.sum())}, val profiles={sorted(vd.profile_id.unique())}")
RESULTS["folds"] = [{"fold": i, "val_batches": va_b} for i, _, va_b in folds]

# ---------------------------------------------------------------- 3. nested calibration
print("\n" + "=" * 100)
print("3. NESTED CALIBRATION: last-k training batches as calibration subset, single symmetric radius")
print("=" * 100)
rows = []
chunk_rows = []
for i, tr_b, va_b in folds:
    vd = d[d.batch_id.isin(va_b)]
    for k in (4, 6, 8, len(tr_b)):
        cal_b = tr_b[-k:]
        cd = d[d.batch_id.isin(cal_b)]
        R = conformal_q(cd.abs_r.values)
        cov = vd.abs_r <= R
        rows.append({
            "fold": i, "k": k if k < len(tr_b) else f"all{len(tr_b)}", "n_cal": len(cd), "cal_defects": int(cd.is_defect.sum()),
            "cal_defect_share": cd.is_defect.mean(), "radius": R,
            "val_cov": cov.mean(), "val_cov_healthy": cov[vd.is_healthy].mean(), "val_cov_defect": cov[vd.is_defect].mean(),
            "val_cov_tester": cov[vd.is_tester_fault].mean() if vd.is_tester_fault.any() else np.nan,
            "val_n_defect": int(vd.is_defect.sum()),
        })
    # rotating disjoint chunks of the fold's training batches (which batches land in calibration?)
    for k in (4, 6, 8):
        n_chunks = len(tr_b) // k
        for c in range(n_chunks):
            cal_b = tr_b[c * k:(c + 1) * k]
            cd = d[d.batch_id.isin(cal_b)]
            R = conformal_q(cd.abs_r.values)
            chunk_rows.append({"fold": i, "k": k, "chunk": c, "cal_defect_share": cd.is_defect.mean(), "radius": R,
                               "val_cov": (vd.abs_r <= R).mean(), "val_cov_defect": (vd.abs_r <= R)[vd.is_defect].mean()})
nest = pd.DataFrame(rows)
print("\n-- per fold x k (calibration = last k training batches by sorted batch_id) --")
print(nest.to_string(index=False))
nest_sum = nest.groupby("k", sort=False).agg(
    radius_mean=("radius", "mean"), radius_sd=("radius", "std"), radius_min=("radius", "min"), radius_max=("radius", "max"),
    cov_mean=("val_cov", "mean"), cov_sd=("val_cov", "std"), cov_min=("val_cov", "min"), cov_max=("val_cov", "max"),
    cov_healthy_mean=("val_cov_healthy", "mean"), cov_defect_mean=("val_cov_defect", "mean"),
    cov_defect_min=("val_cov_defect", "min"), cov_defect_max=("val_cov_defect", "max"),
    cal_defect_share_min=("cal_defect_share", "min"), cal_defect_share_max=("cal_defect_share", "max"),
)
print("\n-- summary across folds --")
print(nest_sum.to_string())
chunks = pd.DataFrame(chunk_rows)
chunk_sum = chunks.groupby("k").agg(
    n_subsets=("radius", "size"), radius_sd=("radius", "std"), radius_min=("radius", "min"), radius_max=("radius", "max"),
    radius_ratio_max_min=("radius", lambda s: s.max() / s.min()),
    cov_sd=("val_cov", "std"), cov_min=("val_cov", "min"), cov_max=("val_cov", "max"),
    cov_defect_min=("val_cov_defect", "min"), cov_defect_max=("val_cov_defect", "max"),
    cal_defect_share_min=("cal_defect_share", "min"), cal_defect_share_max=("cal_defect_share", "max"),
)
print("\n-- sensitivity to WHICH k batches are used (all disjoint consecutive k-batch chunks of each fold's training batches) --")
print(chunk_sum.to_string())
RESULTS["nested_calibration"] = {"per_fold": nest.astype(str).to_dict(orient="records"),
                                 "summary": nest_sum.reset_index().astype(str).to_dict(orient="records"),
                                 "chunk_sensitivity": chunk_sum.reset_index().astype(str).to_dict(orient="records")}

# ---------------------------------------------------------------- 4. within-batch dependence
print("\n" + "=" * 100)
print("4. WITHIN-BATCH DEPENDENCE (one-way ANOVA ICC, design effect with m=200)")
print("=" * 100)


def icc_oneway(values: pd.Series, groups: pd.Series) -> dict[str, float]:
    df = pd.DataFrame({"v": values.astype(float).values, "g": groups.values})
    gm = df.v.mean()
    gstat = df.groupby("g").v.agg(["mean", "size", "var"])
    k = len(gstat)
    N = len(df)
    msb = float((gstat["size"] * (gstat["mean"] - gm) ** 2).sum() / (k - 1))
    ssw = float(((df.v - df.groupby("g").v.transform("mean")) ** 2).sum())
    msw = ssw / (N - k)
    n0 = (N - (gstat["size"] ** 2).sum() / N) / (k - 1)
    icc = (msb - msw) / (msb + (n0 - 1) * msw) if (msb + (n0 - 1) * msw) > 0 else 0.0
    icc = max(icc, 0.0)
    deff = 1 + (M - 1) * icc
    return {"icc": icc, "design_effect": deff, "n_eff": N / deff, "msb": msb, "msw": msw, "n0": float(n0),
            "batch_mean_sd": float(gstat["mean"].std()), "batch_mean_min": float(gstat["mean"].min()), "batch_mean_max": float(gstat["mean"].max())}


icc_rows = {}
icc_rows["r"] = icc_oneway(d.r, d.batch_id)
icc_rows["abs_r"] = icc_oneway(d.abs_r, d.batch_id)
icc_rows["coverage_indicator_single_R"] = icc_oneway(d.cov_single.astype(float), d.batch_id)
icc_rows["r_within_profile"] = icc_oneway(d.r - d.groupby("profile_id").r.transform("mean"), d.batch_id)
icc_rows["cov_within_profile"] = icc_oneway(d.cov_single.astype(float) - d.groupby("profile_id").cov_single.transform("mean"), d.batch_id)
icc_rows["is_defect"] = icc_oneway(d.is_defect.astype(float), d.batch_id)
icc_rows["is_tester_fault"] = icc_oneway(d.is_tester_fault.astype(float), d.batch_id)
icc_tab = pd.DataFrame(icc_rows).T
print(icc_tab.to_string())
p = d.cov_single.mean()
se_naive = math.sqrt(p * (1 - p) / len(d))
deff_cov = icc_rows["coverage_indicator_single_R"]["design_effect"]
se_deff = se_naive * math.sqrt(deff_cov)
batch_cov = d.groupby("batch_id").cov_single.mean()
se_cluster = batch_cov.std(ddof=1) / math.sqrt(len(batch_cov))
dep = {
    "coverage_point": p, "se_naive_iid_7200": se_naive, "se_design_adjusted": se_deff, "se_cluster_batch_means": se_cluster,
    "n_eff_coverage": len(d) / deff_cov,
    "batch_coverage_min": batch_cov.min(), "batch_coverage_p10": batch_cov.quantile(0.1), "batch_coverage_median": batch_cov.median(),
    "batch_coverage_p90": batch_cov.quantile(0.9), "batch_coverage_max": batch_cov.max(),
    "n_batches_below_0.90": int((batch_cov < 0.90).sum()), "n_batches_below_0.85": int((batch_cov < 0.85).sum()),
}
print("\n-- what the design effect does to a coverage estimate --")
print(pd.Series(dep).to_string())
print("\n-- per-batch coverage at the single radius (sorted) --")
bc = d.groupby("batch_id").agg(profile=("profile_id", "first"), coverage=("cov_single", "mean"), defect_share=("is_defect", "mean"),
                                tester_fault_share=("is_tester_fault", "mean"), mean_r=("r", "mean")).sort_values("coverage")
print(bc.to_string())
RESULTS["dependence"] = {"icc": icc_tab.reset_index().astype(str).to_dict(orient="records"), "coverage_se": {k: float(v) for k, v in dep.items()},
                         "per_batch": bc.reset_index().astype(str).to_dict(orient="records")}

# ---------------------------------------------------------------- 5. quantile-style alternative within slope-z bins
print("\n" + "=" * 100)
print("5. BINNED CONDITIONAL-QUANTILE INTERVALS (bins of signed slope_batch_robust_z: <2, 2-5, >=5), nested folds")
print("=" * 100)
z_edges = [-np.inf, 2, 5, np.inf]
z_labels = ["z<2", "2<=z<5", "z>=5"]
d["zbin"] = pd.cut(d.slope_batch_robust_z, z_edges, right=False, labels=z_labels)
print("\n-- bin composition (all parts) --")
print(d.groupby("zbin", observed=True).agg(n=("r", "size"), defect_share=("is_defect", "mean"), abs_r_p50=("abs_r", "median"),
                                          r_p5=("r", lambda s: s.quantile(0.05)), r_p95=("r", lambda s: s.quantile(0.95))).to_string())
MIN_BIN = 20
q_rows = []
q_bin_rows = []
for i, tr_b, va_b in folds:
    vd = d[d.batch_id.isin(va_b)].copy()
    for k in (4, 6, 8):
        cal_b = tr_b[-k:]
        cd = d[d.batch_id.isin(cal_b)]
        # method A: single symmetric
        R = conformal_q(cd.abs_r.values)
        lo_A = np.full(len(vd), -R); hi_A = np.full(len(vd), R)
        # method B: per-bin symmetric; method C: per-bin asymmetric [q05, q95]
        lo_B = np.empty(len(vd)); hi_B = np.empty(len(vd)); lo_C = np.empty(len(vd)); hi_C = np.empty(len(vd))
        lo_all_c, hi_all_c = signed_bounds(cd.r.values)
        bin_info = {}
        for zb in z_labels:
            cbin = cd[cd.zbin == zb]
            mask = (vd.zbin == zb).values
            if len(cbin) >= MIN_BIN:
                Rb = conformal_q(cbin.abs_r.values); lob, hib = signed_bounds(cbin.r.values); fallback = False
            else:
                Rb = R; lob, hib = lo_all_c, hi_all_c; fallback = True
            lo_B[mask] = -Rb; hi_B[mask] = Rb; lo_C[mask] = lob; hi_C[mask] = hib
            bin_info[zb] = {"n_cal": len(cbin), "fallback": fallback, "R_sym": Rb, "lo_asym": lob, "hi_asym": hib}
            vb = vd[mask]
            if len(vb):
                q_bin_rows.append({"fold": i, "k": k, "zbin": zb, "n_cal": len(cbin), "n_val": len(vb), "val_defect_share": vb.is_defect.mean(),
                                   "covA": (vb.abs_r <= R).mean(), "covB": (vb.abs_r <= Rb).mean(), "covC": ((vb.r >= lob) & (vb.r <= hib)).mean(),
                                   "widthA": 2 * R, "widthB": 2 * Rb, "widthC": hib - lob})
        for name, lo, hi in (("A_single_sym", lo_A, hi_A), ("B_bin_sym", lo_B, hi_B), ("C_bin_asym", lo_C, hi_C)):
            hit = (vd.r.values >= lo) & (vd.r.values <= hi)
            width = hi - lo
            q_rows.append({
                "fold": i, "k": k, "method": name, "cov": hit.mean(), "cov_healthy": hit[vd.is_healthy.values].mean(),
                "cov_defect": hit[vd.is_defect.values].mean(),
                "cov_defect_onset_gt24": hit[(vd.is_defect & (vd.anomaly_onset_hour > 24)).values].mean(),
                "cov_tester": hit[vd.is_tester_fault.values].mean() if vd.is_tester_fault.any() else np.nan,
                "width_median": np.median(width), "width_healthy_median": np.median(width[vd.is_healthy.values]),
                "width_defect_median": np.median(width[vd.is_defect.values]), "width_mean": width.mean(),
                "share_lower_below_zero": ((vd.limit_fraction.values + lo) < 0).mean(),
            })
q = pd.DataFrame(q_rows)
q_sum = q.groupby(["k", "method"]).agg(
    cov_mean=("cov", "mean"), cov_sd=("cov", "std"), cov_min=("cov", "min"), cov_max=("cov", "max"),
    cov_healthy=("cov_healthy", "mean"), cov_defect=("cov_defect", "mean"), cov_defect_min=("cov_defect", "min"),
    cov_defect_gt24=("cov_defect_onset_gt24", "mean"), cov_tester=("cov_tester", "mean"),
    width_median=("width_median", "mean"), width_healthy=("width_healthy_median", "mean"), width_defect=("width_defect_median", "mean"),
    width_mean=("width_mean", "mean"), lower_below_zero=("share_lower_below_zero", "mean"),
)
print("\n-- summary across 5 folds: coverage and widths on validation batches (calibration = last k training batches) --")
print(q_sum.to_string())
qb = pd.DataFrame(q_bin_rows)
qb_sum = qb.groupby(["k", "zbin"], observed=True).agg(
    n_cal_min=("n_cal", "min"), n_val_total=("n_val", "sum"), val_defect_share=("val_defect_share", "mean"),
    covA=("covA", "mean"), covB=("covB", "mean"), covB_min=("covB", "min"), covC=("covC", "mean"), covC_min=("covC", "min"),
    widthA=("widthA", "mean"), widthB=("widthB", "mean"), widthC=("widthC", "mean"),
)
print("\n-- per z-bin coverage/width on validation batches (mean over folds; *_min = worst fold) --")
print(qb_sum.to_string())
print("\n-- per fold detail, k=8 --")
print(q[q.k == 8].drop(columns=["k"]).to_string(index=False))
RESULTS["binned_quantiles"] = {"summary": q_sum.reset_index().astype(str).to_dict(orient="records"),
                               "per_bin": qb_sum.reset_index().astype(str).to_dict(orient="records"),
                               "per_fold": q.astype(str).to_dict(orient="records")}

# extra: how much of the z<2 bin's width is driven by defects hidden in it (late-onset)?
z_low = d[d.zbin == "z<2"]
extra = {
    "zlow_n": len(z_low), "zlow_defects": int(z_low.is_defect.sum()), "zlow_defect_onset_gt24": int((z_low.is_defect & (z_low.anomaly_onset_hour > 24)).sum()),
    "zlow_r_p95": z_low.r.quantile(0.95), "zlow_r_p95_healthy_only": z_low[z_low.is_healthy].r.quantile(0.95),
    "zlow_r_p99": z_low.r.quantile(0.99), "zlow_share_r_gt_0.1": (z_low.r > 0.1).mean(), "zlow_share_r_gt_0.5": (z_low.r > 0.5).mean(),
    "zlow_share_y_ge_1": (z_low.y >= 1).mean(), "zlow_n_y_ge_1": int((z_low.y >= 1).sum()),
}
print("\n-- the z<2 bin: late-onset defects it cannot see --")
print(pd.Series(extra).to_string())
RESULTS["zlow_bin"] = {k: float(v) for k, v in extra.items()}

# ---------------------------------------------------------------- 6. supplementary numbers for the recommendation
print("\n" + "=" * 100)
print("6. SUPPLEMENTARY: calibration-subset composition, quantile cliff, quiet-subgroup floor, upper-only bound, per-batch coverage")
print("=" * 100)
prof_of = d.drop_duplicates("batch_id").set_index("batch_id").profile_id
print("\n-- profile composition of the last-k calibration subsets (k=8) per fold --")
for i, tr_b, va_b in folds:
    cal_b = tr_b[-8:]
    print(f"fold {i}: {dict(prof_of.loc[cal_b].value_counts())}")

quiet_mask = (d.slope_batch_robust_z < 2) & (d.limit_fraction < 0.16) & (d.current_batch_robust_z < 2) & (d.delta_fraction_of_limit < 0.01)
print("\n-- quantile cliff of r in the z<2 bin (85%+ of parts): where does the upper bound land as nominal coverage rises? --")
qs = [0.80, 0.84, 0.86, 0.88, 0.90, 0.92, 0.95, 0.975, 0.99]
cliff = pd.DataFrame({
    "z<2 all": z_low.r.quantile(qs).values, "z<2 healthy only": z_low[z_low.is_healthy].r.quantile(qs).values,
    "z<2 non-defect (healthy+tester)": z_low[~z_low.is_defect].r.quantile(qs).values,
    "quiet subgroup": d[quiet_mask].r.quantile(qs).values,
}, index=[f"q{int(q*1000)/10}" for q in qs])
print(cliff.to_string())
RESULTS["zlow_cliff"] = cliff.reset_index().astype(str).to_dict(orient="records")

quiet = d[quiet_mask]
quiet_stats = {
    "n": len(quiet), "share_of_all": len(quiet) / len(d), "defect_share": quiet.is_defect.mean(),
    "defects": int(quiet.is_defect.sum()), "defects_onset_gt24": int((quiet.is_defect & (quiet.anomaly_onset_hour > 24)).sum()),
    "defects_onset_le24": int((quiet.is_defect & (quiet.anomaly_onset_hour <= 24)).sum()),
    "tester_fault_share": quiet.is_tester_fault.mean(), "tester_onset_72": int((quiet.is_tester_fault & (quiet.tester_fault_onset_hour == 72)).sum()),
    "share_y_ge_1": (quiet.y >= 1).mean(), "n_y_ge_1": int((quiet.y >= 1).sum()),
    "r_p5": quiet.r.quantile(0.05), "r_p90": quiet.r.quantile(0.90), "r_p95": quiet.r.quantile(0.95), "r_p99": quiet.r.quantile(0.99),
    "abs_r_p50": quiet.abs_r.median(),
}
print("\n-- 'quiet' subgroup: z<2 & limit_fraction<0.16 & current_z<2 & delta<0.01 (the best any 0/24h feature set can isolate) --")
print(pd.Series(quiet_stats).to_string())
print("scenario mix in quiet subgroup:", quiet.scenario.value_counts().to_dict())
print("onset hours of defects in quiet subgroup:", quiet[quiet.is_defect].anomaly_onset_hour.value_counts().sort_index().to_dict())
RESULTS["quiet_subgroup"] = {k: float(v) for k, v in quiet_stats.items()}

# upper-only (one-sided 90%) bound per z-bin, nested; plus per-batch coverage of methods A and C (each batch is in exactly one val fold)
print("\n-- one-sided UPPER bound only (q90 of signed r per z-bin, calibration = last 8 training batches) vs two-sided upper margin q95 --")
up_rows = []
batch_cov_rows = []
for i, tr_b, va_b in folds:
    vd = d[d.batch_id.isin(va_b)].copy()
    cd = d[d.batch_id.isin(tr_b[-8:])]
    R = conformal_q(cd.abs_r.values)
    lo_all_c, hi_all_c = signed_bounds(cd.r.values)
    up = np.empty(len(vd)); hiC = np.empty(len(vd)); loC = np.empty(len(vd))
    for zb in z_labels:
        cbin = cd[cd.zbin == zb]; mask = (vd.zbin == zb).values
        if len(cbin) >= MIN_BIN:
            u = conformal_q(cbin.r.values, ALPHA)  # one-sided: ceil((n+1)*0.9)-th smallest signed residual
            lob, hib = signed_bounds(cbin.r.values)
        else:
            u = conformal_q(cd.r.values, ALPHA); lob, hib = lo_all_c, hi_all_c
        up[mask] = u; loC[mask] = lob; hiC[mask] = hib
        vb = vd[mask]
        up_rows.append({"fold": i, "zbin": zb, "n_val": len(vb), "upper_margin_1sided_q90": u, "upper_margin_2sided_q95": hib,
                        "cov_1sided": (vb.r <= u).mean(), "cov_2sided": ((vb.r >= lob) & (vb.r <= hib)).mean(),
                        "cov_1sided_defect": (vb.r <= u)[vb.is_defect].mean() if vb.is_defect.any() else np.nan})
    vd["hitA"] = vd.abs_r <= R
    vd["hitC"] = (vd.r >= loC) & (vd.r <= hiC)
    vd["hitU"] = vd.r <= up
    vd["upper_bound_ge_limit_C"] = (vd.limit_fraction + hiC) >= 1.0
    bcv = vd.groupby("batch_id").agg(profile=("profile_id", "first"), covA=("hitA", "mean"), covC=("hitC", "mean"), covU=("hitU", "mean"),
                                     defect_share=("is_defect", "mean"), share_upper_ge_limit_C=("upper_bound_ge_limit_C", "mean"))
    bcv["fold"] = i
    batch_cov_rows.append(bcv)
upt = pd.DataFrame(up_rows)
print(upt.groupby("zbin", observed=True).agg(n_val=("n_val", "sum"), upper_1sided=("upper_margin_1sided_q90", "mean"), upper_2sided=("upper_margin_2sided_q95", "mean"),
                                             cov_1sided=("cov_1sided", "mean"), cov_1sided_min=("cov_1sided", "min"), cov_2sided=("cov_2sided", "mean"),
                                             cov_1sided_defect=("cov_1sided_defect", "mean")).to_string())
bcv_all = pd.concat(batch_cov_rows)
bsum = pd.DataFrame({
    "A_single_sym": bcv_all.covA.describe(percentiles=[0.1, 0.5, 0.9]),
    "C_bin_asym": bcv_all.covC.describe(percentiles=[0.1, 0.5, 0.9]),
    "U_upper_only": bcv_all.covU.describe(percentiles=[0.1, 0.5, 0.9]),
}).T
print("\n-- per-batch coverage across the 36 validation batches (nested, k=8) --")
print(bsum.to_string())
print("batches with coverage < 0.85:  A=%d  C=%d  U=%d" % ((bcv_all.covA < 0.85).sum(), (bcv_all.covC < 0.85).sum(), (bcv_all.covU < 0.85).sum()))
print("share of parts whose method-C upper bound reaches the limit (a 'may exceed' flag), by batch: min=%.3f median=%.3f max=%.3f; overall=%.3f" % (
    bcv_all.share_upper_ge_limit_C.min(), bcv_all.share_upper_ge_limit_C.median(), bcv_all.share_upper_ge_limit_C.max(),
    (bcv_all.share_upper_ge_limit_C * 200).sum() / len(d)))
print("per-batch coverage by profile (method C):")
print(bcv_all.groupby("profile").covC.agg(["mean", "min", "max"]).to_string())
RESULTS["upper_only"] = upt.astype(str).to_dict(orient="records")
RESULTS["per_batch_nested"] = {"summary": bsum.reset_index().astype(str).to_dict(orient="records"),
                               "per_batch": bcv_all.reset_index().astype(str).to_dict(orient="records")}

(OUT / "diag_interval_design.json").write_text(json.dumps(RESULTS, indent=1, default=str))
print("\nwrote", OUT / "diag_interval_design.json")
