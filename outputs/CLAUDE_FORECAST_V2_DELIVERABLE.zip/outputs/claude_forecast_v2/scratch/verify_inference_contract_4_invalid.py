"""Check 4: invalid components -> unavailable+reason vs ValueError vs silent forecast. Each case run in isolation."""
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"
cand = fv2.load_forecast_candidate(CAND / "xgb_abs_resid_leak")

early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batch = sorted(early_all["batch_id"].unique())[2]
base = early_all.loc[early_all["batch_id"] == batch].reset_index(drop=True)
ids = sorted(base["component_id"].unique())
T = ids[0]  # target component
n_ids = len(ids)


def run(label, frame, target=T, expect_rows=None):
    try:
        out = cand.predict(frame)
    except Exception as e:  # noqa: BLE001
        print(f"{label:55s} -> RAISES {type(e).__name__}: {str(e)[:110]}")
        return None
    exp = n_ids if expect_rows is None else expect_rows
    row = out.loc[out["component_id"] == target] if target is not None else pd.DataFrame()
    st = row["status"].tolist(); rs = row["unavailable_reason"].tolist()
    others = out.loc[out["component_id"] != target, "status"].value_counts().to_dict()
    flag = "" if len(out) == exp else f" !! rows={len(out)} expected {exp}"
    print(f"{label:55s} -> target status={st} reason={[str(r)[:70] for r in rs]} | others={others}{flag}")
    return out


m = lambda: base.astype({"hours": object, "measurement_value": object, "upper_limit": object, "profile_id": object, "nominal_capacitance_nf": object, "capacitance_nf": object, "tester_channel": object}).copy()  # noqa: E731
t0 = lambda f: (f["component_id"] == T) & (f["hours"].astype(float) == 0)  # noqa: E731
t24 = lambda f: (f["component_id"] == T) & (f["hours"].astype(float) == 24)  # noqa: E731

f = m(); run("a) missing 24h row", f.loc[~t24(f)])
f = m(); run("a2) missing 0h row", f.loc[~t0(f)])
f = m(); f.loc[t24(f), "measurement_value"] = np.nan; run("b) NaN value at 24h", f)
f = m(); f.loc[t24(f), "measurement_value"] = -0.01; run("c) negative value at 24h", f)
f = m(); f.loc[t24(f), "upper_limit"] = 0.8; run("d) upper_limit changes 0h->24h", f)
f = m(); f.loc[f["component_id"] == T, "upper_limit"] = 0.8; run("d2) upper_limit differs from batch peers (const per part)", f)
f = m(); f.loc[f["component_id"] == T, "component_family"] = "TANTALUM"; run("e) unsupported family", f)
f = m(); f.loc[f["component_id"] == T, "measurement_name"] = "insulation_resistance_gohm"; run("f) unsupported measurement_name", f)
f = m(); f.loc[f["component_id"] == T, "profile_id"] = "SIM_UNKNOWN"; run("g) unknown profile_id (one part)", f)
f = m(); f["profile_id"] = "SIM_UNKNOWN"; run("g2) unknown profile_id (whole batch)", f)
f = m(); run("h) missing profile_id column", f.drop(columns=["profile_id"]))
f = m(); f.loc[t24(f), "profile_id"] = None; run("h2) profile_id NaN at 24h only", f)
f = m(); f.loc[f["component_id"] == T, "profile_id"] = None; run("h3) profile_id NaN for one whole part", f)
f = m(); f = pd.concat([f, f.loc[t24(f)]]); run("i) duplicate identical 24h row", f)
f = m(); d = f.loc[t24(f)].copy(); d["measurement_value"] *= 1.5; f = pd.concat([f, d]); run("i2) duplicate 24h row, different value", f)
f = m(); f["hours"] = f["hours"].astype(str); run("j) hours as strings '0'/'24'", f)
f = m(); f["hours"] = f["hours"].astype(float).map(lambda h: f"{h:.1f}h"); run("j2) hours as strings '0.0h'", f)
f = m(); f.loc[t24(f), "hours"] = "24h"; run("j3) hours '24h' one part", f)
f = m(); f.loc[t24(f), "hours"] = 24.5; run("j4) hours 24.5 one part", f)
f = m(); f.loc[t24(f), "hours"] = 23.9; run("j5) hours 23.9 one part (no 24h row)", f)
f = m(); f["measurement_value"] = f["measurement_value"].astype(str); run("k) measurement_value as strings", f)
f = m(); f.loc[t24(f), "measurement_value"] = "abc"; run("k2) measurement_value 'abc' one part", f)
f = m(); f.loc[t24(f), "measurement_value"] = np.inf; run("k3) measurement_value inf", f)
f = m(); f.loc[t24(f), "upper_limit"] = 0.0; run("l) upper_limit 0", f)
f = m(); f.loc[t24(f), "upper_limit"] = np.nan; run("l2) upper_limit NaN", f)
f = m(); f.loc[t24(f), "measurement_value"] = 0.0; run("m) 24h value exactly 0 (valid?)", f)
f = m(); f.loc[t0(f), "measurement_value"] = 0.0; run("m2) 0h value exactly 0 (percent_change scale 1e-9)", f)
f = m(); f.loc[t24(f), "measurement_value"] = 1e6; run("m3) huge 24h value 1e6 uA", f)
f = m(); f.loc[f["component_id"] == T, "component_id"] = ""; run("n) blank component_id", f, target="")
f = m(); f.loc[f["component_id"] == T, "component_id"] = None; run("n2) None component_id", f, target=None)
f = m(); f.loc[f["component_id"] == T, "component_id"] = " " + T; run("n3) leading-space component_id", f, target=" " + T)
f = m(); run("o) drop upper_limit column", f.drop(columns=["upper_limit"]))
f = m(); run("o2) drop measurement_name column", f.drop(columns=["measurement_name"]))
f = m(); run("p) empty frame", f.iloc[0:0], target=None, expect_rows=0)
f = m(); f["lower_limit"] = 0.0; run("q) lower_limit column supplied (0.0)", f)
f = m(); f["unit"] = "mA"; run("r) unit column 'mA'", f)
f = m(); f["unit"] = "uA"; run("r2) unit column 'uA'", f)
f = m(); f["lower_limit"] = np.nan; run("q2) lower_limit column all NaN", f)
f = m(); f.loc[f["component_id"] == T, "tester_channel"] = "x"; run("s) tester_channel 'x' (string) one part", f)
f = m(); f.loc[t24(f), "capacitance_nf"] = "bad"; run("t) capacitance_nf 'bad' one part", f)
f = m(); f.loc[t24(f), "nominal_capacitance_nf"] = 999; run("u) nominal_capacitance_nf changes 0->24h one part", f)
f = m(); f.loc[f["component_id"] == T, "nominal_capacitance_nf"] = 999; run("u2) nominal_capacitance_nf differs from batch (const per part)", f)
f = m(); f.loc[f["component_id"] == T, "part_number"] = "OTHER"; run("u3) part_number differs from batch peers", f)
f = m(); f.loc[f["component_id"] == T, "measurement_temperature_c"] = 99.0; run("u4) measurement_temperature_c differs from batch peers", f)
f = m(); f = pd.concat([f, early_all.loc[early_all["batch_id"] == sorted(early_all["batch_id"].unique())[3]]]); run("v) two batches with different profiles same upload", f, expect_rows=n_ids + 200)
f = m(); extra = f.loc[f["component_id"] == T].copy(); extra["hours"] = extra["hours"].astype(float) + 96; extra["measurement_value"] *= 100; run("w) 96/120h rows added for one part (ignored?)", pd.concat([f, extra]))
f = m(); f["hours"] = f["hours"].astype(int); run("x) hours as int dtype", f)
f = m(); f["component_id"] = f["component_id"].str.replace("MLCC_C", "").astype(int); run("y) component_id numeric dtype", f, target=int(T.replace("MLCC_C", "")))
