"""Probe suspected gaps in tests/test_forecast_v2.py before editing it. No src changes."""
import sys, tempfile, dataclasses, json
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack/tests")
import test_forecast_v2 as T
from sih26170 import forecast_v2 as fv2

tmp = Path(tempfile.mkdtemp()); e, l = T.make_fixture(); e.to_csv(tmp/"train_early.csv", index=False); l.to_csv(tmp/"train_labels.csv", index=False)
training = fv2.load_training_data(tmp)
aux_cfg = fv2.CandidateConfig("aux", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_aux", objective="reg:absoluteerror", params={"n_estimators": 30})
aux = fv2.fit_final_candidate(training, aux_cfg, seed=17, n_jobs=1)
peer_cfg = fv2.CandidateConfig("peer", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_channel_peer", objective="reg:absoluteerror", params={"n_estimators": 40})
peer = fv2.fit_final_candidate(training, peer_cfg, seed=1, n_jobs=1)
pers = fv2.fit_final_candidate(training, fv2.CandidateConfig("persistence", "persistence"), seed=1, n_jobs=1)

# 1. aux candidate: future rows carry DIFFERENT capacitance/DF values. Does prediction change?
early, _ = T.make_fixture(n_batches=2, seed=11)
fut, _ = T.make_fixture(n_batches=2, with_future=True, seed=11)
fut = fut.copy(); m = fut["hours"] >= 96
fut.loc[m, "measurement_value"] *= 50; fut.loc[m, "capacitance_nf"] *= 0.1; fut.loc[m, "dissipation_factor_pct"] = 99.0; fut.loc[m, "prior_storage_humidity_pct"] = 1000.0
a, b = aux.predict(early), aux.predict(fut)
print("1 aux future-row invariance:", np.allclose(a.predicted_normalized, b.predicted_normalized), "| frames equal:", a.equals(b))

# 2. Is imputation at inference pinned to TRAINING medians? Simulate a mutant that imputes from the upload.
early9, _ = T.make_fixture(n_batches=1, seed=9)
partial = early9.copy()
ids = sorted(partial.component_id.unique())
partial.loc[partial.component_id.isin(ids[:4]), "capacitance_nf"] = np.nan   # per-component NaN in an aux column
ref = aux.predict(partial)
# explicit: fill the derived aux features with manifest medians and predict manually
feats, val, _ = fv2.prepare_early_features(partial)
aug = fv2.augment_features(feats, val)
print("2 NaN aux features present in matrix:", int(fv2.feature_matrix(aug, aux_cfg.feature_columns).isna().sum().sum()))
orig_impute = fv2.impute
def upload_impute(matrix, medians):
    return orig_impute(matrix, fv2.fit_medians(matrix))  # mutant: recompute medians from the upload
fv2.impute = upload_impute
mut = aux.predict(partial)
fv2.impute = orig_impute
print("2 mutant(upload-median impute) changes predictions on partial-NaN upload:", not np.allclose(ref.predicted_normalized, mut.predicted_normalized))
# would the existing all-missing test notice? (all-NaN column -> upload median NaN -> fillna(NaN) no-op -> xgboost native NaN handling)
stripped = early9.drop(columns=["capacitance_nf", "dissipation_factor_pct", "prior_storage_humidity_pct"])
ref_s = aux.predict(stripped); fv2.impute = upload_impute; mut_s = aux.predict(stripped); fv2.impute = orig_impute
print("2 mutant on all-missing upload: status all forecast:", (mut_s.status == "forecast").all(), "finite:", np.isfinite(mut_s.predicted_final_value).all(), "differs from ref:", not np.allclose(ref_s.predicted_normalized, mut_s.predicted_normalized))

# 3. digest covers the FEATURE allowlist CONTENTS (not just the set name)?
base = fv2.config_digest(fv2.PREDECLARED_CONFIGS)
fv2.FEATURE_SETS["leakage_only"].append("bogus_feature")
print("3 digest changes when FEATURE_SETS['leakage_only'] gains a column:", fv2.config_digest(fv2.PREDECLARED_CONFIGS) != base)
fv2.FEATURE_SETS["leakage_only"].pop()
assert fv2.config_digest(fv2.PREDECLARED_CONFIGS) == base

# 4. persistence candidate end-to-end uA: predicted_final_value == 24 h reading
out = pers.predict(early9)
x24 = early9.loc[early9.hours == 24].set_index("component_id")["measurement_value"]
print("4 persistence predicted uA == 24h reading:", np.allclose(out.predicted_final_value, out.component_id.map(x24)))

# 5. label columns smuggled into train_early.csv: do features / OOF change?
d2 = Path(tempfile.mkdtemp()); e2 = e.copy()
e2["final_value"] = e2["component_id"].map(l.set_index("component_id")["final_value"]) * 3.0
e2["scenario"] = "leaked"; e2["is_future_failure"] = True
e2.to_csv(d2/"train_early.csv", index=False); l.to_csv(d2/"train_labels.csv", index=False)
t2 = fv2.load_training_data(d2)
same_feats = t2.features.equals(training.features)
print("5 features identical with label columns in train_early:", same_feats, "| extra cols:", sorted(set(t2.features.columns) - set(training.features.columns)))
folds = fv2.assign_batch_folds(training.features, n_splits=5)
_, o1 = fv2.run_cross_validation(training, [peer_cfg], folds, seed=1, n_jobs=1)
_, o2 = fv2.run_cross_validation(t2, [peer_cfg], folds, seed=1, n_jobs=1)
print("5 OOF identical:", np.array_equal(o1.predicted_normalized.to_numpy(), o2.predicted_normalized.to_numpy()))

# 6. does load_training_data touch train_readings.csv? put a corrupt one in the dir
(tmp/"train_readings.csv").write_text("garbage,,,\n\x00")
try:
    t3 = fv2.load_training_data(tmp); print("6 train_readings.csv ignored by loader:", t3.features.equals(training.features))
except Exception as ex:
    print("6 loader touched train_readings.csv ->", type(ex).__name__, ex)

# 7. predict determinism across calls and across thread counts
p1 = peer.predict(early); p2 = peer.predict(early)
print("7 predict twice identical:", p1.equals(p2))

# 8. 96/168 rows with NaN measurement_value or missing columns: does predict still ignore them?
fut2 = fut.copy(); fut2.loc[fut2.hours >= 96, "measurement_value"] = np.nan
try:
    print("8 NaN future rows ignored:", peer.predict(early).equals(peer.predict(fut2)))
except Exception as ex:
    print("8 NaN future rows ->", type(ex).__name__, ex)
