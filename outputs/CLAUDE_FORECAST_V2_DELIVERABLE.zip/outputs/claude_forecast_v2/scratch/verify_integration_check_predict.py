"""Functional integration check: load the v2 candidate and predict on demo_early.csv.
INPUT ONLY -- no labels/outcomes opened, no accuracy metrics computed."""
import sys, time, warnings, json
from pathlib import Path
COPY = Path(__file__).resolve().parent / "verify_integration_copy"
sys.path.insert(0, str(COPY / "src"))
warnings.simplefilter("always")
caught = []
def _show(message, category, filename, lineno, file=None, line=None):
    caught.append(f"{category.__name__}: {message} ({filename}:{lineno})")
warnings.showwarning = _show

import numpy as np, pandas as pd
import sih26170
import sih26170.forecast_v2 as fv2
print("sih26170 from:", sih26170.__file__)
print("forecast_v2 from:", fv2.__file__)

CAND = "/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack/outputs/claude_forecast_v2/candidate/xgb_abs_resid_leak"
DEMO = "/Users/saikarthik26/Documents/Codex/2026-09-03/https-www-sih-gov-in-sih2026psgo/outputs/mlcc_v1/demo_early.csv"

t0 = time.perf_counter()
cand = fv2.load_forecast_candidate(CAND)
t_load = time.perf_counter() - t0
print(f"load time: {t_load:.3f}s  booster={type(cand.booster).__name__}  name={cand.manifest['config']['name']}")
print("env recorded:", cand.manifest["environment"].get("versions"))
print("env current :", fv2.environment_record()["versions"])

early = fv2.read_identity_csv(DEMO)
print("demo_early rows:", len(early), "cols:", len(early.columns), "unique identities:", early[fv2.IDENTITY].drop_duplicates().shape[0])
print("hours present:", sorted(early["hours"].unique().tolist()))

t0 = time.perf_counter()
out = cand.predict(early)
t_pred = time.perf_counter() - t0
print(f"predict time: {t_pred:.3f}s")
print("output rows:", len(out), "columns:", list(out.columns))
print("status counts:", out["status"].value_counts(dropna=False).to_dict())
print("unavailable reasons:", out["unavailable_reason"].value_counts(dropna=False).to_dict())
print("profile counts:", out["profile_id"].value_counts(dropna=False).to_dict())
print("peer_count min/max:", out["peer_count"].min(), out["peer_count"].max())
pv = out["predicted_final_value"].astype(float)
print("predicted_final_value: finite=%d, nonneg=%d, min=%.5g max=%.5g" % (np.isfinite(pv).sum(), (pv >= 0).sum(), pv.min(), pv.max()))
print("dtypes:", out.dtypes.astype(str).to_dict())
# determinism vs shuffled input (functional only)
rng = np.random.default_rng(0)
shuffled = early.sample(frac=1.0, random_state=1).reset_index(drop=True)
out2 = cand.predict(shuffled)
print("shuffled-input identical output:", out.equals(out2))
# second call same object identical
out3 = cand.predict(early)
print("repeat-call identical output:", out.equals(out3))
# non-strict load path
cand2 = fv2.load_forecast_candidate(CAND, strict_versions=False)
print("non-strict load ok:", cand2.manifest["config"]["name"])
print("WARNINGS captured (%d):" % len(caught))
for w in dict.fromkeys(caught):
    print("  ", w)
out.head(5).to_csv(Path(__file__).resolve().parent / "verify_integration_check_predict_head.csv", index=False)
