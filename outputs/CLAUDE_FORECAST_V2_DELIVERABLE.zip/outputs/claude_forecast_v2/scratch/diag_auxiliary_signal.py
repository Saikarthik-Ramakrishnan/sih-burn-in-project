"""Diagnostic: do auxiliary early (0h/24h) measurements add information beyond leakage?

Read-only w.r.t. src/. Writes only diag_auxiliary_signal_*.csv/json next to itself.
Labels are used ONLY to explain errors retrospectively, never as model inputs.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(PACK / "src"))
from sih26170.features import GROUP_COLUMNS, MODEL_FEATURE_COLUMNS  # noqa: E402
from sih26170.mlcc_prototype import (  # noqa: E402
    CONDITION_COLUMNS,
    FORECAST_COLUMNS,
    prepare_early_features,
)

OUT = PACK / "outputs" / "claude_forecast_v2" / "scratch"
PREFIX = "diag_auxiliary_signal"
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", 40)
pd.set_option("display.float_format", lambda v: f"{v:.4g}")

ID_DTYPES = {c: str for c in GROUP_COLUMNS}
early = pd.read_csv(PACK / "data" / "train_early.csv", dtype=ID_DTYPES)
labels = pd.read_csv(PACK / "data" / "train_labels.csv", dtype=ID_DTYPES)
assert len(early) == 14400 and len(labels) == 7200

# ---------------------------------------------------------------------------
# 0. Redundancy check: insulation_resistance_gohm == V_meas / (1000 * leakage)
# ---------------------------------------------------------------------------
ir_expected = early["measurement_voltage_v"] / (1000.0 * early["measurement_value"])
ir_rel_err = ((early["insulation_resistance_gohm"] - ir_expected).abs() / ir_expected.abs())
print("== insulation_resistance_gohm redundancy ==")
print(f"max |rel err| = {ir_rel_err.max():.3e}; rows with rel err > 1e-6: {(ir_rel_err > 1e-6).sum()}")
ir_check = {"max_rel_err": float(ir_rel_err.max()), "n_rows_gt_1e-6": int((ir_rel_err > 1e-6).sum())}

# ---------------------------------------------------------------------------
# Feature table from the package's own leakage-safe function (no fitting).
# ---------------------------------------------------------------------------
features, early_valid, unscored = prepare_early_features(early)
assert not unscored, f"unexpected unscored components: {len(unscored)}"
assert len(features) == 7200
df = features.merge(labels, on=GROUP_COLUMNS, validate="one_to_one", suffixes=("", "_lab"))
assert len(df) == 7200
assert np.allclose(df["upper_limit"], df["upper_limit_lab"])
df["y"] = df["final_value"] / df["upper_limit"]
df["r"] = df["y"] - df["limit_fraction"]  # persistence residual
df["lin_extrap"] = df["limit_fraction"] + df["slope_fraction_per_hour"] * 144.0
df["is_defect"] = df["is_defect"].astype(str).str.lower().eq("true")
df["is_tester_fault"] = df["is_tester_fault"].astype(str).str.lower().eq("true")
df["is_moisture"] = df["scenario"].eq("moisture_associated_history")
print(f"\nparts={len(df)} batches={df['batch_id'].nunique()} persistence MAE={df['r'].abs().mean():.4f} "
      f"mean r={df['r'].mean():.4f}; defects={df['is_defect'].sum()} moisture={df['is_moisture'].sum()}")

# Raw aux per-part table: 0h and 24h values plus changes (temperature_c is per reading).
RAW_AUX = ["capacitance_nf", "dissipation_factor_pct", "prior_storage_humidity_pct", "temperature_c",
           "measurement_temperature_c", "voltage_stress_ratio", "applied_voltage_v", "measurement_voltage_v"]
e0 = early_valid.loc[early_valid["hours"] == 0.0].set_index(GROUP_COLUMNS)
e24 = early_valid.loc[early_valid["hours"] == 24.0].set_index(GROUP_COLUMNS)
raw = pd.DataFrame(index=e24.index)
for c in RAW_AUX:
    raw[f"{c}@0"] = e0[c]
    raw[f"{c}@24"] = e24[c]
    raw[f"{c}_d24"] = e24[c] - e0[c]
raw["capacitance_frac@0"] = e0["capacitance_nf"] / e0["nominal_capacitance_nf"]
raw["capacitance_frac@24"] = e24["capacitance_nf"] / e24["nominal_capacitance_nf"]
raw = raw.reset_index()
df = df.merge(raw, on=GROUP_COLUMNS, validate="one_to_one")

# ---------------------------------------------------------------------------
# 1. Describe aux features: distinct values per batch; between-batch share of variance
# ---------------------------------------------------------------------------
AUX_FORECAST = [c for c in FORECAST_COLUMNS if c not in MODEL_FEATURE_COLUMNS and c != "initial_fraction_of_limit"]
DESC_COLS = [f"{c}@0" for c in RAW_AUX] + [f"{c}@24" for c in RAW_AUX] + [f"{c}_d24" for c in RAW_AUX] + AUX_FORECAST


def between_share(frame: pd.DataFrame, col: str) -> tuple[float, float]:
    v = frame[col].astype(float)
    tot = ((v - v.mean()) ** 2).sum()
    if tot <= 0:
        return np.nan, np.nan
    gm = frame.groupby("batch_id")[col].transform("mean")
    between = ((gm - v.mean()) ** 2).sum()
    # ratio of between-batch SD to within-batch SD as an interpretable second view
    within_sd = (v - gm).std()
    between_sd = frame.groupby("batch_id")[col].mean().std()
    return float(between / tot), float(between_sd / within_sd) if within_sd > 0 else np.inf


rows = []
for c in DESC_COLS:
    if c not in df:
        continue
    nun = df.groupby("batch_id")[c].nunique(dropna=False)
    share, ratio = between_share(df, c)
    rows.append({
        "feature": c,
        "n_distinct_total": int(df[c].nunique(dropna=False)),
        "distinct_per_batch_min": int(nun.min()), "distinct_per_batch_median": float(nun.median()),
        "distinct_per_batch_max": int(nun.max()),
        "between_batch_var_share": share, "betweenSD_over_withinSD": ratio,
        "n_na": int(df[c].isna().sum()),
        "sd_total": float(df[c].std()),
    })
desc = pd.DataFrame(rows)
desc["batch_identifier_like"] = (desc["distinct_per_batch_max"] <= 2) | (desc["between_batch_var_share"] >= 0.95)
print("\n== 1. aux feature structure (7200 parts, 36 batches, 200 parts/batch) ==")
print(desc.to_string(index=False))
desc.to_csv(OUT / f"{PREFIX}_structure.csv", index=False)

# how many distinct per-profile values do the batch-constant columns take?
prof = df.groupby("profile_id")[["measurement_temperature_c", "voltage_stress_ratio", "measurement_voltage_v"]].nunique()
print("\ndistinct values per profile for batch-constant columns:\n", prof.to_string())
tc_batch = df.groupby("batch_id")["temperature_c"].agg(["mean", "std", "min", "max"])
print("\ntemperature_c (24h reading) per batch: mean of batch means {:.2f}, SD of batch means {:.3f}, "
      "median within-batch SD {:.3f}".format(tc_batch["mean"].mean(), tc_batch["mean"].std(), tc_batch["std"].median()))
print("temperature_c 0h->24h within-part change: mean {:.4f}, SD {:.4f}".format(
    df["temperature_c_d24"].mean(), df["temperature_c_d24"].std()))
print("prior_storage_humidity_pct: overall mean {:.2f} SD {:.2f}; batch-mean SD {:.3f}".format(
    df["prior_storage_humidity_pct"].mean(), df["prior_storage_humidity_pct"].std(),
    df.groupby("batch_id")["prior_storage_humidity_pct"].mean().std()))

# ---------------------------------------------------------------------------
# 2. Relationship to persistence residual r and to scenario membership
# ---------------------------------------------------------------------------
REL_COLS = AUX_FORECAST + [f"{c}_d24" for c in ("capacitance_nf", "dissipation_factor_pct", "temperature_c")] + \
    ["capacitance_frac@0", "capacitance_frac@24"]
REL_COLS = list(dict.fromkeys(REL_COLS))
LEAK_REF = ["limit_fraction", "delta_fraction_of_limit", "slope_fraction_per_hour", "current_batch_robust_z",
            "slope_batch_robust_z", "variability_fraction_of_limit", "initial_fraction_of_limit"]


def sp(a: pd.Series, b: pd.Series) -> float:
    m = a.notna() & b.notna()
    if m.sum() < 10 or a[m].nunique() < 2:
        return np.nan
    return float(spearmanr(a[m], b[m]).statistic)


def within_batch_sp(frame: pd.DataFrame, col: str, target: str) -> float:
    vals = []
    for _, g in frame.groupby("batch_id"):
        v = sp(g[col], g[target])
        if np.isfinite(v):
            vals.append(v)
    return float(np.mean(vals)) if vals else np.nan


defect = df.loc[df["is_defect"]]
rel_rows = []
for c in REL_COLS + LEAK_REF:
    rel_rows.append({
        "feature": c,
        "spearman_r_all": sp(df[c], df["r"]),
        "spearman_r_within_batch_mean": within_batch_sp(df, c, "r"),
        "spearman_r_defect": sp(defect[c], defect["r"]),
        "spearman_absr_all": sp(df[c], df["r"].abs()),
        "auc_is_defect": roc_auc_score(df["is_defect"], df[c].fillna(df[c].median())),
        "auc_moisture_vs_rest": roc_auc_score(df["is_moisture"], df[c].fillna(df[c].median())),
        "auc_tester_fault": roc_auc_score(df["is_tester_fault"], df[c].fillna(df[c].median())),
    })
rel = pd.DataFrame(rel_rows)
print("\n== 2. Spearman with persistence residual r and univariate AUCs (leakage features shown as reference) ==")
print(rel.to_string(index=False))
rel.to_csv(OUT / f"{PREFIX}_relationships.csv", index=False)

# Scenario means of the key aux features
scen_cols = ["prior_storage_humidity_pct", "capacitance_change_fraction", "dissipation_factor_change_pct",
             "current_capacitance_fraction", "current_dissipation_factor_pct", "r"]
scen = df.groupby("scenario")[scen_cols].agg(["mean", "median"]).round(4)
scen["n"] = df.groupby("scenario").size()
print("\n== scenario means/medians of key aux features ==")
print(scen.to_string())
scen.to_csv(OUT / f"{PREFIX}_scenario_means.csv")

# Requested headline AUCs
auc_hum_moist = roc_auc_score(df["is_moisture"], df["prior_storage_humidity_pct"])
auc_cap_def = roc_auc_score(df["is_defect"], df["capacitance_change_fraction"])
auc_capneg_def = roc_auc_score(df["is_defect"], -df["capacitance_change_fraction"])
auc_df_def = roc_auc_score(df["is_defect"], df["dissipation_factor_change_pct"])
auc_hum_def = roc_auc_score(df["is_defect"], df["prior_storage_humidity_pct"])
auc_delta_def = roc_auc_score(df["is_defect"], df["delta_fraction_of_limit"])
auc_slopez_def = roc_auc_score(df["is_defect"], df["slope_batch_robust_z"])
print("\n== headline AUCs ==")
print(f"moisture_associated_history vs rest, prior_storage_humidity_pct alone: AUC={auc_hum_moist:.4f}")
print(f"is_defect, capacitance_change_fraction alone: AUC={auc_cap_def:.4f} (sign-flipped {auc_capneg_def:.4f})")
print(f"is_defect, dissipation_factor_change_pct alone: AUC={auc_df_def:.4f}")
print(f"is_defect, prior_storage_humidity_pct alone: AUC={auc_hum_def:.4f}")
print(f"reference: is_defect, delta_fraction_of_limit alone: AUC={auc_delta_def:.4f}; slope_batch_robust_z: {auc_slopez_def:.4f}")

# humidity threshold view for moisture scenario
for thr in (50, 60, 70, 80):
    hi = df["prior_storage_humidity_pct"] >= thr
    print(f"  RH>={thr}: n={hi.sum():5d}  moisture share among them={df.loc[hi,'is_moisture'].mean():.3f}  "
          f"share of all moisture parts captured={df.loc[hi,'is_moisture'].sum()/df['is_moisture'].sum():.3f}  "
          f"mean r among them={df.loc[hi,'r'].mean():.3f} vs below {df.loc[~hi,'r'].mean():.3f}")
# moisture parts' residual: how much of total abs error do they carry, and is humidity informative about r within them?
moist = df.loc[df["is_moisture"]]
print(f"moisture parts: n={len(moist)} mean r={moist['r'].mean():.3f}; Spearman(humidity, r) within moisture={sp(moist['prior_storage_humidity_pct'], moist['r']):.3f}; "
      f"humidity mean {moist['prior_storage_humidity_pct'].mean():.1f} vs others {df.loc[~df['is_moisture'],'prior_storage_humidity_pct'].mean():.1f}")

# capacitance / DF change by is_defect and onset<=24 vs later
df["onset_num"] = pd.to_numeric(df["anomaly_onset_hour"], errors="coerce")
grp = np.select([~df["is_defect"], df["onset_num"] <= 24, df["onset_num"] > 24], ["non_defect", "defect_onset<=24", "defect_onset>24"], "other")
tab = df.groupby(grp)[["capacitance_change_fraction", "dissipation_factor_change_pct", "r"]].agg(["mean", "std"])
tab["n"] = pd.Series(grp).value_counts()
print("\n== capacitance/DF change by defect onset timing ==")
print(tab.to_string())
auc_cap_early = roc_auc_score(df["onset_num"].le(24).fillna(False), df["capacitance_change_fraction"])
auc_df_early = roc_auc_score(df["onset_num"].le(24).fillna(False), df["dissipation_factor_change_pct"])
print(f"AUC(onset<=24 defect vs everything else): cap_change {auc_cap_early:.4f}, DF_change {auc_df_early:.4f}")

# ---------------------------------------------------------------------------
# 3. THE ONE fitted diagnostic: Ridge on r, 5-fold GroupKFold over sorted batches
# ---------------------------------------------------------------------------
SET_A = MODEL_FEATURE_COLUMNS + ["initial_fraction_of_limit"]
SET_B = list(FORECAST_COLUMNS)
SET_C = [c for c in FORECAST_COLUMNS if c not in CONDITION_COLUMNS]
SETS = {"A_leakage_only(10)": SET_A, "B_plus_all_aux(21)": SET_B, "C_plus_aux_no_condition(17)": SET_C}
assert len(SET_A) == 10 and len(SET_B) == 21 and len(SET_C) == 17, (len(SET_A), len(SET_B), len(SET_C))

work = df.sort_values(["batch_id", "component_id"]).reset_index(drop=True)
groups = work["batch_id"].to_numpy()
gkf = GroupKFold(n_splits=5)
fold_rows = []
coef_rows = []
oof = {name: np.full(len(work), np.nan) for name in SETS}
for k, (tr, te) in enumerate(gkf.split(work, work["r"], groups)):
    assert not set(groups[tr]) & set(groups[te])
    y_te = work["y"].to_numpy()[te]
    pers = work["limit_fraction"].to_numpy()[te]
    lin = np.maximum(work["lin_extrap"].to_numpy()[te], 0.0)
    row = {"fold": k, "n_test": len(te), "test_batches": ",".join(sorted(set(groups[te]))),
           "mae_persistence": float(np.abs(y_te - pers).mean()),
           "mae_linear_extrap": float(np.abs(y_te - lin).mean())}
    for name, cols in SETS.items():
        pipe = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=10.0))
        pipe.fit(work.loc[tr, cols], work.loc[tr, "r"])
        r_hat = pipe.predict(work.loc[te, cols])
        pred = np.maximum(pers + r_hat, 0.0)
        oof[name][te] = pred
        row[f"mae_{name}"] = float(np.abs(y_te - pred).mean())
        if name != "A_leakage_only(10)":
            coefs = pipe.named_steps["ridge"].coef_
            for c, b in zip(cols, coefs):
                coef_rows.append({"set": name, "fold": k, "feature": c, "std_coef": float(b)})
    fold_rows.append(row)
folds = pd.DataFrame(fold_rows)
mean_row = folds.drop(columns=["fold", "test_batches"]).mean(numeric_only=True)
mean_row["fold"] = "mean"; mean_row["test_batches"] = ""
folds = pd.concat([folds, mean_row.to_frame().T], ignore_index=True)
print("\n== 3. GroupKFold(5) Ridge(alpha=10) on r; forecast = limit_fraction + r_hat (clipped >=0). MAE normalized to limit ==")
print("   (information-content diagnostic, NOT a candidate model selection)")
print(folds.to_string(index=False))
folds.to_csv(OUT / f"{PREFIX}_ridge_folds.csv", index=False)

# per-fold deltas (B-A, C-A) and win counts
fa = folds.iloc[:5]
dBA = (fa["mae_B_plus_all_aux(21)"] - fa["mae_A_leakage_only(10)"]).astype(float)
dCA = (fa["mae_C_plus_aux_no_condition(17)"] - fa["mae_A_leakage_only(10)"]).astype(float)
dAP = (fa["mae_A_leakage_only(10)"] - fa["mae_persistence"]).astype(float)
print(f"\nper-fold MAE(B)-MAE(A): {np.round(dBA.to_numpy(),4).tolist()} mean {dBA.mean():+.4f}; B better in {(dBA<0).sum()}/5 folds")
print(f"per-fold MAE(C)-MAE(A): {np.round(dCA.to_numpy(),4).tolist()} mean {dCA.mean():+.4f}; C better in {(dCA<0).sum()}/5 folds")
print(f"per-fold MAE(A)-MAE(persistence): {np.round(dAP.to_numpy(),4).tolist()} mean {dAP.mean():+.4f}")

# OOF error decomposition by scenario for A, B, C
work["pers_err"] = (work["y"] - work["limit_fraction"]).abs()
for name in SETS:
    work[f"err_{name}"] = (work["y"] - oof[name]).abs()
by_scen = work.groupby("scenario")[["pers_err"] + [f"err_{n}" for n in SETS]].mean()
by_scen["n"] = work.groupby("scenario").size()
print("\n== OOF MAE by scenario (persistence vs A/B/C) ==")
print(by_scen.sort_values("pers_err", ascending=False).to_string())
by_scen.to_csv(OUT / f"{PREFIX}_ridge_by_scenario.csv")
by_def = work.groupby("is_defect")[["pers_err"] + [f"err_{n}" for n in SETS]].mean()
print("\nOOF MAE by is_defect:\n", by_def.to_string())

# Standardized coefficients (mean over folds) for aux features in B and C
coef = pd.DataFrame(coef_rows).groupby(["set", "feature"])["std_coef"].agg(["mean", "std"]).reset_index()
coef_aux = coef.loc[coef["feature"].isin(AUX_FORECAST)].sort_values(["set", "mean"], key=lambda s: s if s.name == "set" else s.abs(), ascending=[True, False])
print("\n== mean standardized Ridge coefficient of aux features (r-units per 1 SD), across folds ==")
print(coef_aux.to_string(index=False))
coef.to_csv(OUT / f"{PREFIX}_ridge_coefs.csv", index=False)
big_leak = coef.loc[coef["feature"].isin(MODEL_FEATURE_COLUMNS + ["initial_fraction_of_limit"]) & coef["set"].eq("C_plus_aux_no_condition(17)")]
print("\nleakage feature coefs in set C for scale:\n", big_leak.sort_values("mean", key=abs, ascending=False).to_string(index=False))

# Batch-constant condition columns: do they explain batch-mean residual? (why they are risky)
bm = work.groupby("batch_id").agg(mean_r=("r", "mean"), n_def=("is_defect", "sum"), profile=("profile_id", "first"),
                                  vsr=("voltage_stress_ratio", "first"), mt=("measurement_temperature_c", "first"),
                                  mv=("measurement_voltage_v", "first"), tc=("temperature_c", "mean"),
                                  hum=("prior_storage_humidity_pct", "mean"))
print("\n== batch-level: Spearman of batch-constant columns with batch mean residual (36 points) ==")
for c in ("vsr", "mt", "mv", "tc", "hum", "n_def"):
    print(f"  {c:6s}: rho={sp(bm[c], bm['mean_r']):+.3f}")
print("batch mean r: SD across batches {:.4f}; within-profile SD {:.4f}".format(
    bm["mean_r"].std(), bm.groupby("profile")["mean_r"].std().mean()))

summary = {
    "ir_redundancy": ir_check,
    "n_parts": int(len(df)), "n_batches": int(df["batch_id"].nunique()),
    "persistence_mae": float(df["r"].abs().mean()),
    "auc_humidity_moisture": float(auc_hum_moist),
    "auc_capchange_defect": float(auc_cap_def), "auc_dfchange_defect": float(auc_df_def),
    "auc_humidity_defect": float(auc_hum_def), "auc_delta_defect_ref": float(auc_delta_def),
    "ridge_fold_table": folds.to_dict(orient="records"),
    "batch_identifier_like": desc.loc[desc["batch_identifier_like"], "feature"].tolist(),
}
(OUT / f"{PREFIX}_summary.json").write_text(json.dumps(summary, indent=2, default=str))
print("\nwrote", OUT / f"{PREFIX}_summary.json")

# ---------------------------------------------------------------------------
# 4. Follow-ups that decide the allowlist
# ---------------------------------------------------------------------------
print("\n== 4a. humidity: between-batch vs within-batch signal for moisture scenario ==")
df["hum_within_rank"] = df.groupby("batch_id")["prior_storage_humidity_pct"].rank(pct=True)
df["hum_batch_mean"] = df.groupby("batch_id")["prior_storage_humidity_pct"].transform("mean")
print(f"AUC(moisture) humidity raw={roc_auc_score(df['is_moisture'], df['prior_storage_humidity_pct']):.4f}  "
      f"within-batch rank={roc_auc_score(df['is_moisture'], df['hum_within_rank']):.4f}  "
      f"batch-mean only={roc_auc_score(df['is_moisture'], df['hum_batch_mean']):.4f}")
bt = df.groupby("batch_id").agg(hum_mean=("prior_storage_humidity_pct", "mean"), n_moist=("is_moisture", "sum"),
                                n_tf=("is_tester_fault", "sum"), n_def=("is_defect", "sum"), mean_r=("r", "mean"))
print(f"36 batches: Spearman(batch mean humidity, n_moisture)={sp(bt['hum_mean'], bt['n_moist']):+.3f}; "
      f"Spearman(batch mean humidity, n_tester_fault)={sp(bt['hum_mean'], bt['n_tf']):+.3f}; "
      f"Spearman(batch mean humidity, n_defect)={sp(bt['hum_mean'], bt['n_def']):+.3f}")
print("batch mean humidity: min {:.1f} median {:.1f} max {:.1f}; moisture parts per batch min {} median {} max {}".format(
    bt["hum_mean"].min(), bt["hum_mean"].median(), bt["hum_mean"].max(), bt["n_moist"].min(), bt["n_moist"].median(), bt["n_moist"].max()))
tf_batches = bt.loc[bt["n_tf"] > 0]
print(f"tester-fault batches: {len(tf_batches)} -> {tf_batches['n_tf'].to_dict()}; their humidity means {tf_batches['hum_mean'].round(1).to_dict()} "
      f"vs non-fault-batch mean {bt.loc[bt['n_tf']==0,'hum_mean'].mean():.1f} (SD {bt.loc[bt['n_tf']==0,'hum_mean'].std():.1f})")
print(f"is_tester_fault total={df['is_tester_fault'].sum()} (scenario tester_channel_fault={df['scenario'].eq('tester_channel_fault').sum()})")
# effect sizes (Cohen's d) for the part-level aux changes
for c in ("capacitance_change_fraction", "dissipation_factor_change_pct", "prior_storage_humidity_pct"):
    a, b = df.loc[df["is_defect"], c], df.loc[~df["is_defect"], c]
    d = (a.mean() - b.mean()) / np.sqrt((a.var() + b.var()) / 2)
    a2, b2 = df.loc[df["is_moisture"], c], df.loc[~df["is_moisture"], c]
    d2 = (a2.mean() - b2.mean()) / np.sqrt((a2.var() + b2.var()) / 2)
    print(f"Cohen d {c}: defect vs non-defect {d:+.3f}; moisture vs rest {d2:+.3f}")

print("\n== 4b. Ridge ablations, same protocol (which aux columns carry the tiny gain?) ==")
ABL = {
    "A_leakage_only(10)": SET_A,
    "A+humidity(11)": SET_A + ["prior_storage_humidity_pct"],
    "A+cap_df_change(12)": SET_A + ["capacitance_change_fraction", "dissipation_factor_change_pct"],
    "A+all_part_level_aux(17)": SET_C,
    "A+condition_only(14)": SET_A + CONDITION_COLUMNS,
}
abl_rows = []
for k, (tr, te) in enumerate(gkf.split(work, work["r"], groups)):
    y_te = work["y"].to_numpy()[te]; pers = work["limit_fraction"].to_numpy()[te]
    row = {"fold": k}
    for name, cols in ABL.items():
        pipe = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(alpha=10.0))
        pipe.fit(work.loc[tr, cols], work.loc[tr, "r"])
        pred = np.maximum(pers + pipe.predict(work.loc[te, cols]), 0.0)
        row[name] = float(np.abs(y_te - pred).mean())
        m = work["is_defect"].to_numpy()[te]
        row[name + "_defect"] = float(np.abs(y_te[m] - pred[m]).mean())
    abl_rows.append(row)
abl = pd.DataFrame(abl_rows)
abl["fold"] = abl["fold"].astype(str)
mean_abl = abl.drop(columns=["fold"]).mean().to_frame().T; mean_abl.insert(0, "fold", "mean")
abl = pd.concat([abl, mean_abl], ignore_index=True)
print(abl[["fold"] + list(ABL)].to_string(index=False))
print("defect-only MAE:")
print(abl[["fold"] + [n + "_defect" for n in ABL]].to_string(index=False))
abl.to_csv(OUT / f"{PREFIX}_ridge_ablations.csv", index=False)
for name in list(ABL)[1:]:
    d = (abl.iloc[:5][name] - abl.iloc[:5]["A_leakage_only(10)"]).astype(float)
    print(f"  {name:28s} MAE minus A per fold: {np.round(d.to_numpy(),4).tolist()} mean {d.mean():+.4f}; better in {(d<0).sum()}/5")
