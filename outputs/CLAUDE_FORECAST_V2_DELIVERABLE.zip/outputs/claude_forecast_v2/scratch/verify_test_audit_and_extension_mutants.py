"""pytest plugin that injects one source mutation (selected by env MUTANT) into sih26170.forecast_v2
at collection time, so the full test file can be run against it without touching src/.
Usage: MUTANT=<name> PYTHONPATH=<this dir> pytest -p verify_test_audit_and_extension_mutants tests/test_forecast_v2.py
"""
import os
import numpy as np
import pandas as pd
from sih26170 import forecast_v2 as fv2

MUTANT = os.environ.get("MUTANT", "")


def pytest_configure(config):
    if MUTANT == "upload_medians":
        # inference-time fitting: predict_normalized recomputes the imputation medians from the upload
        def predict_normalized(self, features):
            persistence = fv2.persistence_forecast(features)
            if self.config.model == "persistence":
                return fv2.decode_prediction(persistence, "normalized")
            if self.config.model == "linear_extrapolation":
                return fv2.decode_prediction(fv2.linear_extrapolation_forecast(features), "normalized")
            matrix = fv2.feature_matrix(features, self.config.feature_columns)
            filled = matrix.fillna(matrix.median()).fillna(0.0).to_numpy(dtype=float)  # upload medians, not manifest
            _, margin = fv2.target_encoding(None, persistence, self.config.target)
            raw = self.booster.predict(filled) if margin is None else self.booster.predict(filled, base_margin=margin)
            return fv2.decode_prediction(raw, self.config.target)
        fv2.FittedModel.predict_normalized = predict_normalized
    elif MUTANT == "digest_ignores_allowlist":
        def to_dict(self):
            from dataclasses import asdict
            return asdict(self)  # feature_columns no longer part of the digest payload
        fv2.CandidateConfig.to_dict = to_dict
    elif MUTANT == "persistence_forgets_limit":
        orig = fv2.ForecastCandidate.predict
        def predict(self, early):
            out = orig(self, early)
            if self.manifest["config"]["model"] == "persistence":
                out["predicted_final_value"] = out["predicted_normalized"]  # uA conversion dropped for the baseline candidate
            return out
        fv2.ForecastCandidate.predict = predict
    elif MUTANT == "aux_reads_future_rows":
        # a leak that only the aux feature set can see: capacitance fraction taken from the LAST row per component
        orig_aug = fv2.augment_features
        def augment_features(features, early=None):
            out = orig_aug(features, early)
            if early is not None and "capacitance_nf" in early.columns and "hours" in early.columns:
                last = early.sort_values("hours").groupby("component_id")["capacitance_nf"].last()
                nominal = early.drop_duplicates("component_id").set_index("component_id")["nominal_capacitance_nf"]
                out["current_capacitance_fraction"] = out["component_id"].map(last / nominal).to_numpy()
            return out
        fv2.augment_features = augment_features
    elif MUTANT == "loader_keeps_label_columns_as_features":
        # training-time label leak: a label column present in train_early.csv is appended to the leakage feature set
        fv2.FEATURE_SETS["leakage_plus_channel_peer"] = fv2.FEATURE_SETS["leakage_plus_channel_peer"] + ["prior_storage_humidity_pct"]
    elif MUTANT == "calibration_from_validation":
        orig = fv2.choose_calibration_batches
        fv2._orig_choose = orig
        def choose(train_features, *, per_profile):
            return orig(train_features, per_profile=per_profile)  # placeholder, cannot see validation here
        fv2.choose_calibration_batches = choose
    elif MUTANT and MUTANT != "aux_reads_raw_upload":
        raise RuntimeError(f"unknown mutant {MUTANT}")


if MUTANT == "aux_reads_raw_upload":
    # realistic regression: predict passes the RAW upload (future rows included) to augment_features,
    # and augment_features derives current_capacitance_fraction from the last row per component
    orig_prepare = fv2.prepare_early_features
    def prepare(early, **kw):
        f, v, u = orig_prepare(early, **kw)
        return f, early.copy(), u
    fv2.prepare_early_features = prepare
    orig_aug = fv2.augment_features
    def augment_features(features, early=None):
        out = orig_aug(features, early)
        if early is not None and "capacitance_nf" in early.columns and "hours" in early.columns:
            e = early.copy(); e["component_id"] = e["component_id"].astype(str)
            last = e.sort_values("hours").groupby("component_id")["capacitance_nf"].last()
            nominal = e.drop_duplicates("component_id").set_index("component_id")["nominal_capacitance_nf"]
            out["current_capacitance_fraction"] = out["component_id"].astype(str).map(last / nominal).to_numpy()
        return out
    fv2.augment_features = augment_features
