"""peer_count semantics when some parts of the batch are unavailable; json-safety of output; strict-version double check."""
import json
from pathlib import Path
import numpy as np, pandas as pd
from sih26170 import forecast_v2 as fv2
PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
c = fv2.load_forecast_candidate(PACK / "outputs/claude_forecast_v2/candidate/xgb_abs_resid_leak")
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
b = sorted(early_all["batch_id"].unique())[1]
e = early_all.loc[early_all["batch_id"] == b].reset_index(drop=True)
ids = sorted(e["component_id"].unique())
full = c.predict(e).set_index("component_id")
broken = e.loc[~((e["component_id"].isin(ids[:10])) & (e["hours"].astype(float) == 24))]
o = c.predict(broken).set_index("component_id")
print("10 parts lack 24h: statuses", o["status"].value_counts().to_dict(), "| peer_count of forecast rows:", o.loc[o.status=='forecast','peer_count'].unique().tolist())
d = (o.loc[o.status=='forecast','predicted_normalized'] - full.loc[o.index[o.status=='forecast'],'predicted_normalized']).abs()
print("   forecasts of the other 190 moved vs full batch: changed", int((d>0).sum()), "max|d|", round(d.max(),4))
# json round trip as an integrator would do
rec = o.reset_index().to_dict("records")
try: json.dumps(rec, allow_nan=False); print("json.dumps(records, allow_nan=False): OK")
except ValueError as ex: print("json.dumps(records, allow_nan=False) FAILS:", str(ex)[:60])
print("types of NaN fields in unavailable row:", {k: type(v).__name__ for k, v in rec[0].items() if k in ('predicted_final_value','peer_count','profile_id','unavailable_reason')}, "status", rec[0]['status'])
fr = [r for r in rec if r['status']=='forecast'][0]
print("forecast row unavailable_reason repr:", repr(fr['unavailable_reason']), "peer_count type:", type(fr['peer_count']).__name__)
# whitespace / case identity normalisation
f = e.copy(); f.loc[f["component_id"] == ids[0], "component_id"] = ids[0] + " "
o = c.predict(f); print("trailing-space id kept verbatim:", (ids[0] + " ") in set(o["component_id"]), "| rows", len(o))
