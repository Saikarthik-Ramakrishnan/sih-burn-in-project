"""Probe the properties I intend to add as tests, before editing tests/test_forecast_v2.py."""
import sys, json, dataclasses, importlib.metadata, tempfile, traceback
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack/tests")
from test_forecast_v2 import make_fixture, PROFILES
from sih26170 import forecast_v2 as fv2

tmp = Path(tempfile.mkdtemp())
early, labels = make_fixture()
early.to_csv(tmp / "train_early.csv", index=False); labels.to_csv(tmp / "train_labels.csv", index=False)
training = fv2.load_training_data(tmp)

def probe(name, fn):
    try:
        r = fn(); print(f"[OK ] {name}: {r}")
    except Exception as e:
        print(f"[ERR] {name}: {type(e).__name__}: {e}"); traceback.print_exc(limit=2)

# 1 shuffled train_early rows -> identical TrainingData
def p1():
    d = Path(tempfile.mkdtemp()); early.sample(frac=1, random_state=3).to_csv(d/"train_early.csv", index=False); labels.to_csv(d/"train_labels.csv", index=False)
    t2 = fv2.load_training_data(d)
    pd.testing.assert_frame_equal(t2.features, training.features); pd.testing.assert_frame_equal(t2.labels, training.labels)
    return "identical features/labels; hashes differ: %s" % (t2.input_hashes != training.input_hashes)
probe("shuffle train_early", p1)

# 2 96h rows in train_early rejected
def p2():
    d = Path(tempfile.mkdtemp()); e2,_ = make_fixture(with_future=True); e2.to_csv(d/"train_early.csv", index=False); labels.to_csv(d/"train_labels.csv", index=False)
    try: fv2.load_training_data(d); return "NOT REJECTED"
    except ValueError as e: return f"rejected: {e}"
probe("future rows in train_early", p2)

# 3 aux/peer no NaN on fixture
probe("aux/peer NaN count", lambda: training.features[fv2.AUX_FEATURES + fv2.CHANNEL_PEER_FEATURES].isna().sum().to_dict())

cfg_xgb = fv2.CandidateConfig("x", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_aux", objective="reg:absoluteerror", params={"n_estimators": 30})
folds = fv2.assign_batch_folds(training.features, n_splits=5)

# 4 label perturbation on fold-0 validation labels leaves fold-0 OOF unchanged, changes others
def p4():
    _, oof_a = fv2.run_cross_validation(training, [cfg_xgb], folds, seed=1, n_jobs=1)
    lab = training.labels.copy(); m = training.features["batch_id"].map(folds.set_index("batch_id")["fold"]).eq(0).to_numpy()
    lab.loc[m, "y_normalized"] *= 7.0; lab.loc[m, "final_value"] *= 7.0
    t2 = fv2.TrainingData(training.features, lab, training.input_hashes, training.validation)
    _, oof_b = fv2.run_cross_validation(t2, [cfg_xgb], folds, seed=1, n_jobs=1)
    same0 = np.allclose(oof_a.loc[oof_a.fold==0,"predicted_normalized"], oof_b.loc[oof_b.fold==0,"predicted_normalized"])
    diff_other = not np.allclose(oof_a.loc[oof_a.fold!=0,"predicted_normalized"], oof_b.loc[oof_b.fold!=0,"predicted_normalized"])
    return f"fold0 unchanged={same0}, other folds changed={diff_other}"
probe("label perturbation OOF", p4)

# 5 OOF equals manual refit for fold 1
def p5():
    _, oof = fv2.run_cross_validation(training, [cfg_xgb], folds, seed=1, n_jobs=1)
    k, tr, va = fv2.fold_masks(training.features, folds)[1]
    fitted = fv2.fit_model(cfg_xgb, training.features.loc[tr].reset_index(drop=True), training.y[tr], seed=1, n_jobs=1)
    pred = fitted.predict_normalized(training.features.loc[va].reset_index(drop=True))
    sub = oof.loc[oof.fold==k].set_index("component_id")["predicted_normalized"]
    return np.allclose(sub.loc[training.features.loc[va,"component_id"]].to_numpy(), pred)
probe("OOF == manual refit", p5)

# 6 all predeclared configs fit+predict, and candidate roundtrip
def p6():
    out = {}
    small,_ = make_fixture(n_batches=1, seed=9)
    for c in fv2.PREDECLARED_CONFIGS:
        cc = dataclasses.replace(c, params={**c.params, "n_estimators": 5}) if c.model == "xgboost" else c
        cand = fv2.fit_final_candidate(training, cc, seed=1, n_jobs=1)
        d = Path(tempfile.mkdtemp())/c.name; fv2.save_forecast_candidate(cand, d)
        pred = fv2.load_forecast_candidate(d).predict(small)
        out[c.name] = (pred.status.eq("forecast").all(), bool(np.isfinite(pred.predicted_final_value).all()), bool((pred.predicted_final_value>=0).all()))
    return out
probe("all predeclared configs", p6)

# 7 column entirely missing at inference for aux candidate; and tester_channel missing for peer candidate
def p7():
    cand = fv2.fit_final_candidate(training, cfg_xgb, seed=1, n_jobs=1)
    small,_ = make_fixture(n_batches=1, seed=9)
    a = cand.predict(small)
    b = cand.predict(small.drop(columns=["capacitance_nf", "dissipation_factor_pct", "prior_storage_humidity_pct"]))
    peer = fv2.CandidateConfig("p", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_channel_peer", objective="reg:absoluteerror", params={"n_estimators": 30})
    cp = fv2.fit_final_candidate(training, peer, seed=1, n_jobs=1)
    c = cp.predict(small.drop(columns=["tester_channel"]))
    return dict(aux_status_all_forecast=b.status.eq("forecast").all(), aux_changed=not np.allclose(a.predicted_normalized, b.predicted_normalized), peer_nochannel_ok=c.status.eq("forecast").all(), finite=bool(np.isfinite(b.predicted_normalized).all()))
probe("missing columns at inference", p7)

# 8 structural errors
def p8():
    cand = fv2.fit_final_candidate(training, cfg_xgb, seed=1, n_jobs=1)
    small,_ = make_fixture(n_batches=1, seed=9); res = {}
    for name, frame in [("missing upper_limit", small.drop(columns=["upper_limit"])), ("blank component_id", small.assign(component_id=lambda d: d.component_id.where(d.index != 0, ""))), ("nan batch_id", small.assign(batch_id=lambda d: d.batch_id.where(d.index != 0, np.nan))), ("empty", small.iloc[0:0]), ("mixed profile in batch", small.assign(profile_id=lambda d: np.where(d.index < 2, "P_B", d.profile_id)))]:
        try: cand.predict(frame); res[name] = "NO ERROR"
        except ValueError as e: res[name] = f"ValueError: {e}"
    return res
probe("structural errors", p8)

# 9 strict version mismatch
def p9():
    cand = fv2.fit_final_candidate(training, cfg_xgb, seed=1, n_jobs=1)
    d = Path(tempfile.mkdtemp())/"c"; fv2.save_forecast_candidate(cand, d)
    m = json.loads((d/"manifest.json").read_text()); m["environment"]["versions"]["xgboost"] = "0.0.1"; (d/"manifest.json").write_text(json.dumps(m))
    try: fv2.load_forecast_candidate(d); r = "NO ERROR"
    except ValueError as e: r = f"strict raises: {str(e)[:60]}"
    fv2.load_forecast_candidate(d, strict_versions=False)
    return r + "; non-strict loads"
probe("version mismatch", p9)

# 10 manifest fields
def p10():
    cand = fv2.fit_final_candidate(training, cfg_xgb, seed=17, n_jobs=1)
    m = cand.manifest
    return dict(hashes=m["training"]["input_sha256"] == training.input_hashes, seed=m["training"]["seed"], xgb=m["environment"]["versions"]["xgboost"] == importlib.metadata.version("xgboost"), cols=m["feature_columns"] == cfg_xgb.feature_columns, medians=set(m["imputation_medians"]) == set(cfg_xgb.feature_columns))
probe("manifest fields", p10)

# 11 cross-batch independence of predict
def p11():
    cand = fv2.fit_final_candidate(training, cfg_xgb, seed=1, n_jobs=1)
    two,_ = make_fixture(n_batches=2, seed=21)
    a = cand.predict(two); one = cand.predict(two.loc[two.batch_id=="B00"])
    sub = a.loc[a.batch_id=="B00"].reset_index(drop=True)
    pd.testing.assert_frame_equal(sub, one); return "batch predictions independent of other uploaded batches"
probe("cross-batch independence", p11)

# 12 digest
def p12():
    base = fv2.config_digest(fv2.PREDECLARED_CONFIGS)
    changed = list(fv2.PREDECLARED_CONFIGS); changed[6] = dataclasses.replace(changed[6], params={"n_estimators": 351})
    return dict(stable=base == fv2.config_digest(fv2.PREDECLARED_CONFIGS), changes=base != fv2.config_digest(changed), order_sensitive=base != fv2.config_digest(list(reversed(fv2.PREDECLARED_CONFIGS))))
probe("digest", p12)

# 13 choose_calibration_batches
def p13():
    k, tr, va = fv2.fold_masks(training.features, folds)[0]
    trf = training.features.loc[tr]
    cal = fv2.choose_calibration_batches(trf, per_profile=1)
    ok = set(cal) <= set(trf.batch_id) and not set(cal) & set(training.features.loc[va,"batch_id"])
    try: fv2.choose_calibration_batches(trf, per_profile=4); raised = False
    except ValueError: raised = True
    return dict(subset_and_disjoint=ok, n=len(cal), raises_when_too_few=raised)
probe("calibration batches", p13)

# 14 folds without profile_id
def p14():
    f = fv2.assign_batch_folds(training.features.drop(columns=["profile_id"]), n_splits=4)
    return dict(profile=set(f.profile_id), per_fold=f.groupby("fold").size().to_dict(), covers=set(f.batch_id)==set(training.features.batch_id))
probe("folds without profile", p14)
