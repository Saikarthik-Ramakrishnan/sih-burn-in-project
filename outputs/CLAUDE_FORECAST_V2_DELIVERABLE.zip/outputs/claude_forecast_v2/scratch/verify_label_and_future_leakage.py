"""Adversarial verifier: can post-24 h observations, label columns, identifiers or
batch-constant conditions influence the saved v2 candidates' predictions or the
training features?  Read-only on the pack; writes nothing but stdout."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(ROOT / "src"))
from sih26170 import forecast_v2 as fv2  # noqa: E402
from sih26170.mlcc_prototype import FORECAST_COLUMNS  # noqa: E402

OUT = ROOT / "outputs/claude_forecast_v2"
DATA = ROOT / "data"
LABEL_COLS = ["final_value", "true_final_value", "scenario", "component_scenario", "is_future_failure",
              "is_observed_final_exceedance", "is_defect", "is_healthy", "is_tester_fault",
              "anomaly_onset_hour", "tester_fault_onset_hour", "ever_latent_exceedance"]


def section(title: str) -> None:
    print("\n" + "=" * 90 + f"\n{title}\n" + "=" * 90)


def same(a: pd.DataFrame, b: pd.DataFrame, label: str) -> bool:
    try:
        pd.testing.assert_frame_equal(a, b, check_exact=True)
        print(f"  [PASS] {label}: predictions bit-identical ({len(a)} rows)")
        return True
    except AssertionError as exc:
        diff = (a["predicted_normalized"] - b["predicted_normalized"]).abs()
        print(f"  [FAIL] {label}: max |delta predicted_normalized| = {diff.max():.3e}; {(diff > 0).sum()} rows differ")
        print("        ", str(exc).splitlines()[0][:200])
        return False


# --------------------------------------------------------------------------- #
section("1. Columns reaching a model matrix per FEATURE_SET, forbidden-token check")
for name, cols in fv2.FEATURE_SETS.items():
    print(f"  {name} ({len(cols)}): {cols}")
    hits = [c for c in cols if any(t in c for t in fv2.FORBIDDEN_FEATURE_TOKENS)]
    print(f"     forbidden-token hits: {hits}")
    cond = [c for c in cols if c in fv2.CONDITION_FEATURES or c == "prior_storage_humidity_pct"]
    print(f"     batch-constant / lot-level columns present: {cond}")
used_by_predeclared = {c.feature_set for c in fv2.PREDECLARED_CONFIGS if c.model == "xgboost"}
print("  feature sets used by predeclared xgboost configs:", sorted(used_by_predeclared))
print("  configs whose fold models see condition columns:",
      [c.name for c in fv2.PREDECLARED_CONFIGS if set(c.feature_columns) & set(fv2.CONDITION_FEATURES)])

# --------------------------------------------------------------------------- #
section("2. Data: hours present, label columns absent from early, hashes match manifests")
early_all = fv2.read_identity_csv(DATA / "train_early.csv")
readings_all = fv2.read_identity_csv(DATA / "train_readings.csv")
labels_all = fv2.read_identity_csv(DATA / "train_labels.csv")
print("  train_early hours:", sorted(pd.to_numeric(early_all["hours"]).unique()))
print("  train_readings hours:", sorted(pd.to_numeric(readings_all["hours"]).unique()))
print("  label-ish columns in train_early:", sorted(set(LABEL_COLS) & set(early_all.columns)))
print("  rows/component in train_early:", early_all.groupby("component_id").size().value_counts().to_dict())
for cand in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    man = json.loads((OUT / "candidate" / cand / "manifest.json").read_text())
    ok = {k: man["training"]["input_sha256"][k] == fv2._hash_file(DATA / k) for k in man["training"]["input_sha256"]}
    print(f"  {cand}: manifest input hashes match current data files: {ok}")

# --------------------------------------------------------------------------- #
section("3. load_training_data: which files does it open? does it need train_readings.csv?")
opened: list[str] = []
_orig_read_csv = pd.read_csv
def _spy(path, *a, **k):
    opened.append(str(path))
    return _orig_read_csv(path, *a, **k)
pd.read_csv = _spy
training = fv2.load_training_data(DATA)
pd.read_csv = _orig_read_csv
print("  files opened by load_training_data:", [Path(p).name for p in opened])
assert not any("train_readings" in p for p in opened), "train_readings.csv was read"
# label columns must not be in the feature frame
leaked_cols = sorted(set(LABEL_COLS) & set(training.features.columns))
print("  label columns present in training.features:", leaked_cols)
# and none of the matrix columns can be reconstructed from labels: check no matrix column equals y exactly
y = training.y
for name, cols in fv2.FEATURE_SETS.items():
    M = fv2.feature_matrix(training.features, cols)
    corr = M.corrwith(pd.Series(y, index=M.index)).abs().sort_values(ascending=False)
    print(f"  {name}: max |corr(feature, y)| = {corr.iloc[0]:.3f} ({corr.index[0]})")
# a copy of the data dir WITHOUT train_readings.csv must still load identically
import tempfile, shutil
with tempfile.TemporaryDirectory(dir=OUT / "scratch") as tmp:
    for f in ("train_early.csv", "train_labels.csv"):
        shutil.copy(DATA / f, Path(tmp) / f)
    t2 = fv2.load_training_data(tmp)
    pd.testing.assert_frame_equal(training.features, t2.features)
    print("  [PASS] load_training_data gives identical features without train_readings.csv present")

# --------------------------------------------------------------------------- #
section("4. Quantitative batch-identifiability of each feature set (training features)")
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import StratifiedKFold, cross_val_score
feat = training.features
batch = feat["batch_id"].to_numpy()
profile = feat["profile_id"].to_numpy()

def between_share(x: np.ndarray, g: np.ndarray) -> float:
    s = pd.Series(x)
    ok = np.isfinite(x)
    s, gg = s[ok], pd.Series(g)[ok]
    if s.var(ddof=0) == 0:
        return float("nan")
    means = s.groupby(gg.to_numpy()).transform("mean")
    return float(means.var(ddof=0) / s.var(ddof=0))

all_cols = sorted(set().union(*fv2.FEATURE_SETS.values()))
print("  between-batch variance share (eta^2) of every feature column (1.0 = batch constant):")
shares = {}
for c in all_cols:
    x = pd.to_numeric(feat[c], errors="coerce").to_numpy(dtype=float)
    shares[c] = between_share(x, batch)
    within_prof = np.nanmean([between_share(x[profile == p], batch[profile == p]) for p in np.unique(profile)])
    nuniq_per_batch = feat.groupby("batch_id")[c].nunique().agg(["min", "max"]).tolist()
    print(f"    {c:42s} eta2(batch)={shares[c]:.3f}  eta2(batch|profile)={within_prof:.3f}  distinct/batch={nuniq_per_batch}")

print("\n  RandomForest 5-fold CV accuracy predicting batch_id from the imputed feature matrix")
print("  (chance overall 1/36 = 0.028; within a known profile 1/9 = 0.111; RF sees no profile column):")
skf = StratifiedKFold(5, shuffle=True, random_state=0)
for name, cols in fv2.FEATURE_SETS.items():
    M = fv2.feature_matrix(feat, cols)
    X = fv2.impute(M, fv2.fit_medians(M))
    rf = RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=4)
    acc = cross_val_score(rf, X, batch, cv=skf, scoring="accuracy")
    print(f"    {name:28s} batch-id accuracy = {acc.mean():.3f} +/- {acc.std():.3f}")
    # within-profile: does the set distinguish the 9 batches of one profile?
    per_prof = []
    for p in np.unique(profile):
        m = profile == p
        per_prof.append(cross_val_score(RandomForestClassifier(n_estimators=150, random_state=0, n_jobs=4), X[m], batch[m], cv=StratifiedKFold(5, shuffle=True, random_state=0)).mean())
    print(f"    {'':28s} within-profile batch accuracy (9 batches, chance 0.111): {np.round(per_prof, 3).tolist()}")
# Profile is legitimately encoded (upper_limit differs by profile); show profile predictability for context
M = fv2.feature_matrix(feat, fv2.FEATURE_SETS["leakage_only"]); X = fv2.impute(M, fv2.fit_medians(M))
print(f"    leakage_only -> profile_id accuracy (chance 0.25): {cross_val_score(RandomForestClassifier(n_estimators=100, random_state=0, n_jobs=4), X, profile, cv=skf).mean():.3f}")

# humidity rank: marginal distribution identical across batches?
rank = feat["prior_storage_humidity_batch_rank_v2"]
per_batch_sorted = feat.groupby("batch_id")["prior_storage_humidity_batch_rank_v2"].apply(lambda s: np.round(np.sort(s.to_numpy()), 6))
ref = per_batch_sorted.iloc[0]
print(f"\n  humidity rank: batches whose sorted rank vector equals the first batch's: {sum(np.array_equal(v, ref) for v in per_batch_sorted)}/{len(per_batch_sorted)}")
print(f"  humidity rank: corr with raw humidity within batch (mean Spearman) = {feat.groupby('batch_id').apply(lambda g: g['prior_storage_humidity_batch_rank_v2'].corr(pd.to_numeric(g['prior_storage_humidity_pct']), method='spearman')).mean():.3f};"
      f" corr of batch-mean rank with batch-mean humidity = {feat.groupby('batch_id')[['prior_storage_humidity_batch_rank_v2']].mean().iloc[:,0].corr(feat.groupby('batch_id')['prior_storage_humidity_pct'].apply(lambda s: pd.to_numeric(s).mean())):.3f}")
# channel peer: is the batch-level mean of channel_peer_median_current_z_v2 informative of batch?
cp = feat["channel_peer_median_current_z_v2"]
print(f"  channel_peer_median_current_z_v2: eta2(batch)={shares['channel_peer_median_current_z_v2']:.3f}; NaN share {cp.isna().mean():.3f}; distinct values per batch min/max = {feat.groupby('batch_id')['channel_peer_median_current_z_v2'].nunique().agg(['min','max']).tolist()}")
print(f"  channel_peer_elevated_fraction_v2: eta2(batch)={shares['channel_peer_elevated_fraction_v2']:.3f}")
# tester-fault batches: does channel_peer_elevated_fraction identify them?
lab = training.labels
fault_batches = lab.groupby(feat["batch_id"].to_numpy())["is_tester_fault"].sum()
print(f"  batches with tester faults: {int((fault_batches>0).sum())}/36; mean channel_peer_elevated_fraction in fault vs non-fault batches: "
      f"{feat.loc[feat['batch_id'].isin(fault_batches[fault_batches>0].index),'channel_peer_elevated_fraction_v2'].mean():.4f} vs "
      f"{feat.loc[~feat['batch_id'].isin(fault_batches[fault_batches>0].index),'channel_peer_elevated_fraction_v2'].mean():.4f}")

# --------------------------------------------------------------------------- #
section("5. Saved candidates: adversarial uploads must give bit-identical predictions")
batches = sorted(early_all["batch_id"].unique())[:2]
clean = early_all.loc[early_all["batch_id"].isin(batches)].reset_index(drop=True)
print(f"  upload batches: {batches}; rows {len(clean)}; components {clean['component_id'].nunique()}")

future = readings_all.loc[readings_all["batch_id"].isin(batches) & (pd.to_numeric(readings_all["hours"]) >= 48)].copy()
future["measurement_value"] = pd.to_numeric(future["measurement_value"]) * 100.0
mid = readings_all.loc[readings_all["batch_id"].isin(batches) & pd.to_numeric(readings_all["hours"]).isin([6, 12])].copy()
mid["measurement_value"] = pd.to_numeric(mid["measurement_value"]) * 100.0

rng = np.random.default_rng(7)

def adversarial(base: pd.DataFrame, extra: pd.DataFrame | None, poison_meta_in_extra: bool = False) -> pd.DataFrame:
    df = base.copy()
    if extra is not None:
        extra = extra.copy()
        if poison_meta_in_extra:
            # future rows carrying different metadata/limits/channels: must be ignored entirely
            extra["upper_limit"] = pd.to_numeric(extra["upper_limit"]) * 10
            extra["tester_channel"] = "99"
            extra["prior_storage_humidity_pct"] = "999"
            extra["capacitance_nf"] = "1"
            extra["dissipation_factor_pct"] = "50"
        df = pd.concat([df, extra], ignore_index=True)
    # adversarial label columns joined by identity (so they are "true" labels, scrambled)
    lab_map = labels_all.set_index("component_id")
    df["final_value"] = 1e6
    df["true_final_value"] = df["component_id"].map(lab_map["true_final_value"]).astype(float) * 1000
    df["scenario"] = df["component_id"].map(lab_map["scenario"])
    df["is_future_failure"] = True
    df["is_defect"] = df["component_id"].map(lab_map["is_defect"])
    df["anomaly_onset_hour"] = 0
    return df.sample(frac=1.0, random_state=int(rng.integers(1e9))).reset_index(drop=True)

failures = 0
for cand_name in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    print(f"\n  --- candidate {cand_name} ---")
    cand = fv2.load_forecast_candidate(OUT / "candidate" / cand_name)
    base = cand.predict(clean)
    assert (base["status"] == fv2.FORECAST_STATUS).all(), base["status"].value_counts()
    print(f"  clean predictions: {len(base)} rows, all status=forecast; mean predicted_normalized {base['predicted_normalized'].mean():.5f}")
    failures += not same(base, cand.predict(adversarial(clean, None)), "labels added + shuffled (no future rows)")
    failures += not same(base, cand.predict(adversarial(clean, future)), "48-168 h rows x100 + labels + shuffled")
    failures += not same(base, cand.predict(adversarial(clean, pd.concat([mid, future]))), "6/12 h + 48-168 h rows x100 + labels + shuffled")
    failures += not same(base, cand.predict(adversarial(clean, future, poison_meta_in_extra=True)), "future rows also carry poisoned upper_limit/channel/humidity/cap/DF")
    # identifiers renamed: batch_id / component_id strings must not matter (output identity changes, so compare values only)
    renamed = clean.copy()
    renamed["batch_id"] = renamed["batch_id"].map({b: f"LOT_{i}" for i, b in enumerate(batches)})
    renamed["component_id"] = "X" + renamed["component_id"].str[6:]
    out_r = cand.predict(renamed)
    keyed_base = base.assign(k=base["component_id"].str[6:]).set_index("k")["predicted_normalized"]
    keyed_r = out_r.assign(k=out_r["component_id"].str[1:]).set_index("k")["predicted_normalized"]
    d = (keyed_base - keyed_r.reindex(keyed_base.index)).abs().max()
    print(f"  [{'PASS' if d == 0 else 'FAIL'}] renaming batch_id and component_id: max |delta| = {d:.3e}")
    failures += d != 0
    # profile_id swapped to another supported profile: predictions must not move (profile only gates support)
    swapped = clean.copy()
    other = {p: q for p, q in zip(sorted(cand.manifest["supported_profiles"]), sorted(cand.manifest["supported_profiles"])[1:] + sorted(cand.manifest["supported_profiles"])[:1])}
    swapped["profile_id"] = swapped["profile_id"].map(other)
    out_s = cand.predict(swapped)
    d = (base["predicted_normalized"] - out_s["predicted_normalized"]).abs().max()
    print(f"  [{'PASS' if d == 0 else 'FAIL'}] profile_id relabelled to another supported profile: max |delta| = {d:.3e}")
    failures += d != 0
    # batch-constant condition columns changed: temperature, voltages, tester_id, board_position, part_number
    cond = clean.copy()
    for c, v in {"temperature_c": "0", "measurement_temperature_c": "0", "applied_voltage_v": "1", "measurement_voltage_v": "1",
                 "voltage_stress_ratio": "0", "tester_id": "T_X", "board_position": "0", "part_number": "PN_X",
                 "data_source": "field", "generator_version": "x"}.items():
        cond[c] = v
    failures += not same(base, cand.predict(cond), "batch-constant condition/identifier columns overwritten")
    # batch-level humidity shift (adds a constant per batch): rank unchanged -> must be identical
    hum = clean.copy()
    hum["prior_storage_humidity_pct"] = pd.to_numeric(hum["prior_storage_humidity_pct"]) + hum["batch_id"].map({batches[0]: 500.0, batches[1]: -30.0})
    failures += not same(base, cand.predict(hum), "batch-constant shift of prior_storage_humidity_pct (rank preserved)")
    # tester_channel permuted (relabel channel numbers): channel identity must not matter
    chan = clean.copy()
    chan["tester_channel"] = (pd.to_numeric(chan["tester_channel"]) * 7 + 100).astype(int).astype(str)
    failures += not same(base, cand.predict(chan), "tester_channel relabelled bijectively")
    # cross-batch independence: predicting batch 0 alone must equal its rows in the two-batch upload
    solo = cand.predict(clean.loc[clean["batch_id"] == batches[0]].reset_index(drop=True))
    sub = base.loc[base["batch_id"] == batches[0]].reset_index(drop=True)
    failures += not same(sub, solo, "batch 0 alone vs inside a two-batch upload (cross-batch independence)")
    # a real change to a 24 h reading MUST change the prediction (sanity: the test is not vacuous)
    sens = clean.copy()
    m = (sens["component_id"] == sens["component_id"].iloc[0]) & (pd.to_numeric(sens["hours"]) == 24)
    sens.loc[m, "measurement_value"] = pd.to_numeric(sens.loc[m, "measurement_value"]) * 3
    d = (base["predicted_normalized"] - cand.predict(sens)["predicted_normalized"]).abs()
    print(f"  [{'PASS' if d.max() > 0 else 'FAIL'}] sanity: tripling one 24 h reading changes {int((d > 0).sum())} prediction(s), max |delta| = {d.max():.4f}")
    failures += d.max() == 0
    # no label / future column reaches the output
    print(f"  output columns containing label names: {sorted(set(LABEL_COLS) & set(base.columns))}")

print(f"\n  TOTAL adversarial prediction failures: {failures}")

# --------------------------------------------------------------------------- #
section("6. prepare_early_features: rows other than exactly 0 and 24 h are discarded")
probe = clean.loc[clean["component_id"] == clean["component_id"].iloc[0]].copy()
extra = probe.iloc[[1]].copy(); extra["hours"] = "48"; extra["measurement_value"] = "9999"
f_probe, e_probe, u = fv2.prepare_early_features(pd.concat([probe, extra], ignore_index=True))
print(f"  hours kept in validated early frame: {sorted(e_probe['hours'].unique())}; unscored: {len(u)}; n_observations={int(f_probe['n_observations'].iloc[0])}")
extra["hours"] = "23.999"
f2, e2, u2 = fv2.prepare_early_features(pd.concat([probe, extra], ignore_index=True))
print(f"  with an extra 23.999 h row: hours kept {sorted(e2['hours'].unique())}, unscored {len(u2)}")
dup = probe.iloc[[1]].copy(); dup["measurement_value"] = "9999"
f3, e3, u3 = fv2.prepare_early_features(pd.concat([probe, dup], ignore_index=True))
print(f"  duplicate 24 h row: features rows {len(f3)}, unscored {len(u3)} reason: {u3[0]['data_quality_warning'] if u3 else None}")
only24 = probe.loc[pd.to_numeric(probe['hours']) == 24]
f4, e4, u4 = fv2.prepare_early_features(pd.concat([only24, only24.assign(hours='168')], ignore_index=True))
print(f"  24 h + 168 h only (no 0 h): features rows {len(f4)}, unscored {len(u4)}")

# --------------------------------------------------------------------------- #
section("7. OOF file / training frame: labels only as targets and reporting")
oof = pd.read_csv(OUT / "oof_predictions.csv", dtype={c: str for c in fv2.IDENTITY})
print("  oof columns:", list(oof.columns))
# every OOF prediction was made by a model whose training batches exclude the row's batch
folds = pd.read_csv(OUT / "fold_assignment.csv", dtype={"batch_id": str})
fmap = folds.set_index("batch_id")["fold"]
print(f"  oof rows whose fold != fold_assignment of their batch: {int((oof['batch_id'].map(fmap) != oof['fold']).sum())}")
print(f"  fold assignment uses profile_id (from early) and batch_id only; columns: {list(folds.columns)}")
