"""Completeness critic: recompute headline numbers from the six diagnostic angles.

Read-only with respect to src/. Writes only diag_critic_summary.json next to itself.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import GroupKFold
from threadpoolctl import threadpool_limits

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(PACK / "src"))
from sih26170.features import GROUP_COLUMNS  # noqa: E402
from sih26170.mlcc_prototype import (  # noqa: E402
    AS_OF_HOUR, FORECAST_COLUMNS, TARGET_HOUR, _new_models, prepare_early_features,
)

OUT = PACK / "outputs/claude_forecast_v2/scratch"
STR = {c: str for c in GROUP_COLUMNS}
early_raw = pd.read_csv(PACK / "data/train_early.csv", dtype=STR)
labels = pd.read_csv(PACK / "data/train_labels.csv", dtype=STR)
readings = pd.read_csv(PACK / "data/train_readings.csv", dtype=STR)
assert len(early_raw) == 14400 and len(labels) == 7200 and len(readings) == 72000

features, early, unscored = prepare_early_features(early_raw)
assert not unscored
# tester_channel / profile from the 24h reading row
meta = early.loc[early["hours"] == AS_OF_HOUR, GROUP_COLUMNS + ["tester_channel", "tester_id", "profile_id"]]
features = features.merge(meta, on=GROUP_COLUMNS, validate="one_to_one")
df = features.merge(labels.drop(columns=["upper_limit", "profile_id"]), on=GROUP_COLUMNS, validate="one_to_one")
df = df.sort_values(["batch_id", "component_id"]).reset_index(drop=True)
for c in ("is_defect", "is_tester_fault", "is_healthy", "is_future_failure", "is_observed_final_exceedance"):
    df[c] = df[c].astype(str).str.lower().eq("true")
df["final_value"] = df["final_value"].astype(float)
df["true_final_value"] = df["true_final_value"].astype(float)
df["onset"] = pd.to_numeric(df["anomaly_onset_hour"], errors="coerce")
df["t_onset"] = pd.to_numeric(df["tester_fault_onset_hour"], errors="coerce")
df["y"] = df["final_value"] / df["upper_limit"]
df["pers"] = df["limit_fraction"]
df["linx"] = np.maximum(df["limit_fraction"] + df["slope_fraction_per_hour"] * (TARGET_HOUR - AS_OF_HOUR), 0.0)
df["r"] = df["y"] - df["pers"]
res: dict[str, object] = {}
tot = df["r"].abs().sum()

print("=== 1. persistence / linear extrapolation ===")
res["pers_mae"] = float(df["r"].abs().mean())
res["pers_mean_resid"] = float(df["r"].mean())
res["linx_mae"] = float((df["y"] - df["linx"]).abs().mean())
res["pers_rmse"] = float(np.sqrt((df["r"] ** 2).mean()))
print(res)

gkf = GroupKFold(n_splits=5)
df["fold"] = -1
for k, (_, va) in enumerate(gkf.split(df, groups=df["batch_id"])):
    df.loc[va, "fold"] = k
fold_tab = df.groupby("fold").apply(lambda g: pd.Series({
    "n": len(g), "batches": g["batch_id"].nunique(),
    "pers_mae": g["r"].abs().mean(), "linx_mae": (g["y"] - g["linx"]).abs().mean(),
}), include_groups=False)
print(fold_tab.round(4))
res["pers_mae_per_fold"] = fold_tab["pers_mae"].round(4).tolist()
res["fold_batches"] = {int(k): sorted(g["batch_id"].unique().tolist()) for k, g in df.groupby("fold")}

print("\n=== 2. error decomposition shares of persistence abs error ===")
def share(mask, name):
    s = df.loc[mask, "r"].abs().sum() / tot
    res[f"share_{name}"] = float(s)
    print(f"{name:28s} n={int(mask.sum()):5d} share={s:.4f} MAE={df.loc[mask,'r'].abs().mean():.4f} mean_r={df.loc[mask,'r'].mean():+.4f}")
share(df["is_defect"], "is_defect")
share(df["is_tester_fault"], "is_tester_fault")
share(df["is_healthy"], "healthy")
share(df["is_defect"] & ~df["is_tester_fault"], "defect_only")
share(~df["is_defect"] & df["is_tester_fault"], "tester_only")
share(df["y"] >= 1, "y_ge_1")
share(df["limit_fraction"] >= 1, "lf24_ge_1")
share(df["is_defect"] & ~df["is_tester_fault"] & (df["y"] < 1), "defect_only_sublimit")
share(df["onset"] > 24, "defect_onset_gt24")
share(df["t_onset"] == 72, "tester_onset_72")
print("healthy_settling MAE", round(df.loc[df.scenario == "healthy_settling", "r"].abs().mean(), 4),
      "ordinary_noise MAE", round(df.loc[df.scenario == "ordinary_noise", "r"].abs().mean(), 4))

print("\n=== 3. oracle floors ===")
def oracle(mask):
    return float(np.where(mask, 0.0, df["r"].abs()).mean())
res["oracle_onset_le24"] = oracle(df["onset"] <= 24)
zvis = (df["slope_batch_robust_z"] > 3) | (df["current_batch_robust_z"] > 3)
res["n_zvis"] = int(zvis.sum()); res["n_zvis_onset_le24"] = int((zvis & (df["onset"] <= 24)).sum())
res["oracle_zvis_onset_le24"] = oracle(zvis & (df["onset"] <= 24))
res["oracle_zvis_all"] = oracle(zvis)
warned = ~((df["slope_batch_robust_z"].abs() < 2) & (df["delta_fraction_of_limit"] < 0.05) & (df["current_batch_robust_z"].abs() < 2) & (df["limit_fraction"] < 0.5))
res["n_warned_loose4"] = int(warned.sum()); res["oracle_warned_loose4"] = oracle(warned)
res["noise_floor_obs_vs_true"] = float(((df["final_value"] - df["true_final_value"]) / df["upper_limit"]).abs().mean())
print({k: v for k, v in res.items() if k.startswith(("oracle", "n_zvis", "n_warned", "noise"))})

print("\n=== 4. AUCs ===")
hs = df.scenario == "healthy_settling"
def auc(pos, neg, col):
    m = pos | neg
    return float(roc_auc_score(pos[m].astype(int), df.loc[m, col]))
res["auc_gradual_vs_healthy_delta"] = auc(df.scenario == "gradual_drift", hs, "delta_fraction_of_limit")
res["auc_lateabrupt_vs_healthy_delta"] = auc(df.scenario == "late_abrupt_onset", hs, "delta_fraction_of_limit")
res["auc_accel_vs_healthy_delta"] = auc(df.scenario == "accelerating_drift", hs, "delta_fraction_of_limit")
res["auc_isdefect_delta"] = float(roc_auc_score(df["is_defect"].astype(int), df["delta_fraction_of_limit"]))
res["auc_isdefect_slopez"] = float(roc_auc_score(df["is_defect"].astype(int), df["slope_batch_robust_z"]))
res["auc_moisture_humidity"] = float(roc_auc_score((df.scenario == "moisture_associated_history").astype(int), df["prior_storage_humidity_pct"].astype(float)))
res["auc_isdefect_capchange"] = float(roc_auc_score(df["is_defect"].astype(int), df["capacitance_change_fraction"]))
res["auc_testerfault_onset0_curz"] = auc(df["t_onset"] == 0, ~df["is_tester_fault"], "current_batch_robust_z")
res["auc_testerfault_onset72_curz"] = auc(df["t_onset"] == 72, ~df["is_tester_fault"], "current_batch_robust_z")
res["auc_cross_all_lf"] = float(roc_auc_score((df["y"] >= 1).astype(int), df["limit_fraction"]))
res["auc_cross_onset_gt24_vs_noncross_lf"] = auc((df["y"] >= 1) & (df["onset"] > 24), df["y"] < 1, "limit_fraction")
print({k: round(v, 4) for k, v in res.items() if k.startswith("auc")})

print("\n=== 5. tester fault channel structure ===")
cell = df.groupby(["batch_id", "tester_channel"]).agg(n=("is_tester_fault", "size"), nf=("is_tester_fault", "sum"))
aff = cell[cell.nf > 0]
res["n_fault_cells"] = int(len(aff)); res["fault_cell_frac_min"] = float((aff.nf / aff.n).min()); res["fault_cell_frac_max"] = float((aff.nf / aff.n).max())
res["n_fault_batches"] = int(aff.reset_index()["batch_id"].nunique())
res["n_fault_parts"] = int(df["is_tester_fault"].sum())
print({k: v for k, v in res.items() if "fault" in k})
# LOO peer flag: fraction of channel peers with cur_z>3 >= 0.5
g = df.groupby(["batch_id", "tester_channel"])["current_batch_robust_z"]
elev = (df["current_batch_robust_z"] > 3).astype(float)
cnt = g.transform("size"); s = elev.groupby([df["batch_id"], df["tester_channel"]]).transform("sum")
peer_frac = (s - elev) / (cnt - 1)
flag = peer_frac >= 0.5
res["peer_flag_n"] = int(flag.sum()); res["peer_flag_nonfault"] = int((flag & ~df["is_tester_fault"]).sum())
res["peer_flag_fault_onset0_12"] = int((flag & df["t_onset"].isin([0, 12])).sum())
print({k: v for k, v in res.items() if k.startswith("peer")})

print("\n=== 6. single conformal radius (in-sample) & ICC ===")
a = np.sort(df["r"].abs().to_numpy()); n = len(a)
rank = int(np.ceil((n + 1) * 0.9)); R = float(a[rank - 1])
cov = df["r"].abs() <= R
res["conformal_radius_q90"] = R
res["cov_all"] = float(cov.mean()); res["cov_healthy"] = float(cov[df.is_healthy].mean()); res["cov_defect"] = float(cov[df.is_defect].mean()); res["cov_tester"] = float(cov[df.is_tester_fault].mean())
res["healthy_absr_median"] = float(df.loc[df.is_healthy, "r"].abs().median())
res["healthy_absr_p90"] = float(df.loc[df.is_healthy, "r"].abs().quantile(0.9))
print({k: round(v, 4) for k, v in res.items() if k.startswith(("conformal", "cov", "healthy_absr"))})
def icc(x, grp):
    d = pd.DataFrame({"x": x, "g": grp}); k = d.groupby("g").size(); m = k.mean()
    gm = d["x"].mean(); means = d.groupby("g")["x"].mean()
    msb = (k * (means - gm) ** 2).sum() / (len(k) - 1)
    msw = ((d["x"] - d["g"].map(means)) ** 2).sum() / (len(d) - len(k))
    return float((msb - msw) / (msb + (m - 1) * msw))
res["icc_r_batch"] = icc(df["r"], df["batch_id"])
res["icc_r_batch_channel"] = icc(df["r"], df["batch_id"] + "_" + df["tester_channel"].astype(str))
print("ICC r within batch", round(res["icc_r_batch"], 4), "within (batch,channel)", round(res["icc_r_batch_channel"], 4))

print("\n=== 7. gradual drift growth multiplier from readings ===")
rd = readings.copy(); rd["hours"] = rd["hours"].astype(float); rd["measurement_value"] = rd["measurement_value"].astype(float)
piv = rd.pivot_table(index=GROUP_COLUMNS, columns="hours", values="measurement_value").reset_index()
piv = piv.merge(df[GROUP_COLUMNS + ["scenario", "upper_limit", "delta_fraction_of_limit", "onset"]], on=GROUP_COLUMNS, validate="one_to_one")
gd = piv[(piv.scenario == "gradual_drift") & (piv.delta_fraction_of_limit > 0.01)]
mult = (gd[168.0] - gd[24.0]) / (gd[24.0] - gd[0.0])
res["gradual_mult_median"] = float(mult.median()); res["gradual_mult_n"] = int(len(gd))
res["gradual_mult_q25_q75"] = [float(mult.quantile(0.25)), float(mult.quantile(0.75))]
# consistency check: persistence at 24h from readings equals features
chk = piv.merge(df[GROUP_COLUMNS + ["current_value"]], on=GROUP_COLUMNS)
res["max_abs_diff_current_value_vs_readings24"] = float((chk[24.0] - chk["current_value"]).abs().max())
print({k: v for k, v in res.items() if k.startswith(("gradual", "max_abs"))})

print("\n=== 8. XGBoost v1 config refit, GroupKFold(5), healthy inflation & paired power ===")
X = df[FORECAST_COLUMNS].to_numpy(float)
assert np.isfinite(X).all()
oof = np.full(len(df), np.nan)
with threadpool_limits(1):
    for k in range(5):
        tr, va = df["fold"] != k, df["fold"] == k
        model = _new_models(26170)["xgboost"]
        model.fit(X[tr.to_numpy()], df.loc[tr, "y"].to_numpy())
        oof[va.to_numpy()] = np.maximum(model.predict(X[va.to_numpy()]), 0.0)
df["xgb"] = oof
e = df["xgb"] - df["y"]
res["xgb_mae"] = float(e.abs().mean()); res["xgb_rmse"] = float(np.sqrt((e ** 2).mean())); res["xgb_mean_signed"] = float(e.mean())
h = df["is_healthy"]
res["xgb_healthy_mean_signed"] = float(e[h].mean()); res["xgb_healthy_median_signed"] = float(e[h].median())
res["xgb_healthy_frac_pred_gt_y"] = float((e[h] > 0).mean()); res["xgb_healthy_mae"] = float(e[h].abs().mean())
res["xgb_healthy_frac_worse_than_pers"] = float((e[h].abs() > df.loc[h, "r"].abs()).mean())
res["xgb_defect_only_mae"] = float(e[df.is_defect & ~df.is_tester_fault].abs().mean())
res["xgb_sumabs_delta_healthy"] = float(e[h].abs().sum() - df.loc[h, "r"].abs().sum())
res["xgb_sumabs_delta_defect_only"] = float(e[df.is_defect & ~df.is_tester_fault].abs().sum() - df.loc[df.is_defect & ~df.is_tester_fault, "r"].abs().sum())
fold_x = df.assign(ex=e.abs()).groupby("fold").apply(lambda g: g["ex"].mean() - g["r"].abs().mean(), include_groups=False)
res["xgb_minus_pers_per_fold"] = fold_x.round(4).tolist()
bt = df.assign(ex=e.abs()).groupby("batch_id").apply(lambda g: pd.Series({"pers": g["r"].abs().mean(), "xgb": g["ex"].mean()}), include_groups=False)
bt["d"] = bt["xgb"] - bt["pers"]
res["batches_xgb_beats_pers"] = int((bt["d"] < 0).sum())
res["batch_delta_mean"] = float(bt["d"].mean()); res["batch_delta_sd"] = float(bt["d"].std(ddof=1)); res["batch_delta_se"] = float(bt["d"].std(ddof=1) / np.sqrt(len(bt)))
res["batch_pers_mae_sd"] = float(bt["pers"].std(ddof=1))
# per-batch paired persistence-vs-linx too, to show scale of paired SE for a different model
bl = df.assign(el=(df["y"] - df["linx"]).abs()).groupby("batch_id").apply(lambda g: g["el"].mean() - g["r"].abs().mean(), include_groups=False)
res["linx_batch_delta_sd"] = float(bl.std(ddof=1))
# crossing recall
pred_cross = df["xgb"] >= 1; true_cross = df["y"] >= 1
res["xgb_obs_recall"] = float((pred_cross & true_cross).sum() / true_cross.sum()); res["xgb_obs_fp"] = int((pred_cross & ~true_cross).sum())
res["xgb_new_cross_tp"] = int((pred_cross & true_cross & (df["limit_fraction"] < 1)).sum())
nt = ~df["is_tester_fault"]
res["xgb_latent_recall_nontester"] = float((pred_cross & df["is_future_failure"] & nt).sum() / (df["is_future_failure"] & nt).sum())
print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in res.items() if k.startswith(("xgb", "batch", "linx_batch"))})
# compare to the sibling angle's OOF file
sib = pd.read_csv(OUT / "diag_baseline_reproduction_oof.csv", dtype=STR)
cmp_ = df[GROUP_COLUMNS + ["xgb", "y"]].merge(sib, on=GROUP_COLUMNS, validate="one_to_one")
res["sibling_xgb_max_abs_diff"] = float((cmp_["xgb"] - cmp_["forecast_xgboost"].astype(float)).abs().max())
res["sibling_y_max_abs_diff"] = float((cmp_["y_x"] - cmp_["y_y"].astype(float)).abs().max())
print("sibling OOF max abs diff xgb", res["sibling_xgb_max_abs_diff"], "y", res["sibling_y_max_abs_diff"])

print("\n=== 9. prevalence sensitivity of squared-error inflation (descriptive, no refit) ===")
# conditional mean of r for looks-healthy parts as function of defect prevalence: E[r | quiet] = p_def * mean_r_def_quiet + (1-p) * mean_r_healthy_quiet
quiet = ~warned
mr_def = df.loc[quiet & df.is_defect, "r"].mean(); mr_non = df.loc[quiet & ~df.is_defect, "r"].mean(); p = float((quiet & df.is_defect).mean() / quiet.mean())
res["quiet_n"] = int(quiet.sum()); res["quiet_defect_share"] = p; res["quiet_mean_r_defect"] = float(mr_def); res["quiet_mean_r_nondefect"] = float(mr_non)
res["quiet_cond_mean_r_at_train_prevalence"] = float(p * mr_def + (1 - p) * mr_non)
res["quiet_cond_mean_r_at_half_prevalence"] = float(0.5 * p * mr_def + (1 - 0.5 * p) * mr_non)
print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in res.items() if k.startswith("quiet")})

print("\n=== 10. intermittent parts over limit at 24h ===")
m = (df["limit_fraction"] >= 1)
print(df.loc[m].groupby("scenario")["r"].agg(["size", "mean", "median"]).round(3))
res["lf24_ge1_intermittent_mean_r"] = float(df.loc[m & (df.scenario == "intermittent_leakage"), "r"].mean())
res["lf24_ge1_tester_median_r"] = float(df.loc[m & df.is_tester_fault, "r"].median())

json.dump({k: (v if not isinstance(v, float) else round(v, 6)) for k, v in res.items()}, open(OUT / "diag_critic_summary.json", "w"), indent=1, default=str)
print("\nwrote", OUT / "diag_critic_summary.json")
