"""Check 6: determinism - predict twice, threadpool_limits removed, different n_jobs on the booster, reordering, fresh load."""
import contextlib
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batches = sorted(early_all["batch_id"].unique())
early = early_all.loc[early_all["batch_id"].isin(batches[:4])].reset_index(drop=True)

for name in ("xgb_abs_resid_leak", "xgb_abs_resid_aux"):
    c = fv2.load_forecast_candidate(CAND / name)
    a = c.predict(early); b = c.predict(early)
    pd.testing.assert_frame_equal(a, b); print(f"[{name}] twice identical: OK")
    shuffled = early.sample(frac=1.0, random_state=42).reset_index(drop=True)
    s = c.predict(shuffled); pd.testing.assert_frame_equal(a, s); print(f"[{name}] shuffled identical: OK")
    # fresh load
    c2 = fv2.load_forecast_candidate(CAND / name)
    pd.testing.assert_frame_equal(a, c2.predict(early)); print(f"[{name}] fresh load identical: OK")
    # threadpool_limits removed
    orig = fv2.threadpool_limits
    fv2.threadpool_limits = lambda *a_, **k_: contextlib.nullcontext()
    try:
        t = c.predict(early)
    finally:
        fv2.threadpool_limits = orig
    eq = np.array_equal(a["predicted_normalized"].to_numpy(), t["predicted_normalized"].to_numpy())
    print(f"[{name}] without threadpool_limits identical: {eq}; max|d|={np.abs(a['predicted_normalized']-t['predicted_normalized']).max():.3e}")
    # booster n_jobs variation
    for nj in (1, 4, 8):
        c.booster.set_params(n_jobs=nj)
        u = c.predict(early)
        print(f"[{name}] booster n_jobs={nj} identical: {np.array_equal(a['predicted_normalized'].to_numpy(), u['predicted_normalized'].to_numpy())}")
    c.booster.set_params(n_jobs=None)
    # predict on batch subsets vs full concatenation (per-batch independence)
    per = pd.concat([c.predict(early_all.loc[early_all["batch_id"] == b]) for b in batches[:4]]).sort_values(fv2.SORT_KEYS).reset_index(drop=True)
    pd.testing.assert_frame_equal(a, per); print(f"[{name}] per-batch predictions == pooled upload: OK")
    # dtype robustness: float32 measurement values vs float64
    e32 = early.copy(); e32["measurement_value"] = e32["measurement_value"].astype(np.float32)
    d32 = c.predict(e32)
    print(f"[{name}] float32 input max|d|={np.abs(a['predicted_normalized']-d32['predicted_normalized']).max():.3e}")
    # loaded booster params
    bp = c.booster.get_params()
    print(f"[{name}] loaded booster n_jobs={bp.get('n_jobs')} device={bp.get('device')} objective={bp.get('objective')} base_score={bp.get('base_score')} n_estimators={bp.get('n_estimators')}")
    # does the loaded XGBRegressor know feature names? (matrix is numpy so no)
    print(f"[{name}] feature_names in booster: {c.booster.get_booster().feature_names}")
