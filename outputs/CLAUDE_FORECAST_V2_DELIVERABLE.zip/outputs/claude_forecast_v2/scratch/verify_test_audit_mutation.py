"""Mutation check: simulate an OOF leak (train on ALL rows, including the validation fold)
and see which tests notice. Nothing in src is modified; the leak is injected via monkeypatch."""
import sys, tempfile
from pathlib import Path
import numpy as np, pandas as pd
sys.path.insert(0, "/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack/tests")
import test_forecast_v2 as T
from sih26170 import forecast_v2 as fv2

tmp = Path(tempfile.mkdtemp()); e, l = T.make_fixture(); e.to_csv(tmp/"train_early.csv", index=False); l.to_csv(tmp/"train_labels.csv", index=False)
training = fv2.load_training_data(tmp)
configs = [fv2.CandidateConfig("persistence", "persistence"), fv2.CandidateConfig("linear_extrapolation", "linear_extrapolation"),
           fv2.CandidateConfig("xgb_abs_resid", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_channel_peer", objective="reg:absoluteerror", params={"n_estimators": 40}),
           fv2.CandidateConfig("xgb_log1p", "xgboost", target="log1p_normalized", feature_set="leakage_only", objective="reg:squarederror", params={"n_estimators": 40})]

real_fold_masks = fv2.fold_masks
def leaky_fold_masks(features, folds):
    return [(k, np.ones_like(tr), va) for k, tr, va in real_fold_masks(features, folds)]  # train on everything

def run(name, fn):
    try: fn(); print(f"  {name}: PASSED (did not catch the leak)")
    except AssertionError as ex: print(f"  {name}: FAILED as it should -> {str(ex).splitlines()[0][:90]}")

# Only the ORIGINAL body of the OOF test (before this audit): the tautological mapping check
def original_oof_test():
    folds = fv2.assign_batch_folds(training.features, n_splits=5)
    results, oof = fv2.run_cross_validation(training, configs, folds, seed=1, n_jobs=1)
    mapping = folds.set_index("batch_id")["fold"]
    assert (oof["batch_id"].map(mapping) == oof["fold"]).all()
    assert len(oof) == len(configs) * len(training.features)
    assert set(oof["config"]) == {c.name for c in configs}
    for config in configs:
        entry = results["configs"][config.name]
        assert entry["fold_summary"]["folds"] == 5
        assert entry["pooled"]["components"] == len(training.features)
    assert np.isfinite(fv2.comparison_table(results)["mae_norm_pooled"]).all()

print("With an injected OOF leak (models trained on all rows including the validation fold):")
fv2.fold_masks = leaky_fold_masks
real_guard = fv2.assert_folds_disjoint; fv2.assert_folds_disjoint = lambda features, folds: None  # the module's own guard would catch this; bypass it to test the TESTS
try:
    run("ORIGINAL test_cross_validation_predictions_are_out_of_fold body", original_oof_test)
    run("PATCHED test_cross_validation_predictions_are_out_of_fold", lambda: T.test_cross_validation_predictions_are_out_of_fold(training, configs))
    run("NEW test_validation_fold_labels_cannot_influence_their_own_oof_predictions", lambda: T.test_validation_fold_labels_cannot_influence_their_own_oof_predictions(training, configs))
finally:
    fv2.fold_masks = real_fold_masks; fv2.assert_folds_disjoint = real_guard

# Second mutation: predict() forgets to sort output (order leak). Which tests notice?
print("With predict() output left in input order:")
orig_predict = fv2.ForecastCandidate.predict
def unsorted_predict(self, early):
    out = orig_predict(self, early)
    order = list(dict.fromkeys(early["component_id"].astype(str)))  # first-appearance order of the INPUT
    return out.set_index("component_id").loc[order].reset_index()[fv2.OUTPUT_COLUMNS]
cand = fv2.fit_final_candidate(training, configs[2], seed=1, n_jobs=1); d = Path(tempfile.mkdtemp())/"c"; fv2.save_forecast_candidate(cand, d)
fv2.ForecastCandidate.predict = unsorted_predict
try:
    run("test_predict_is_invariant_to_input_order_and_keeps_identity", lambda: T.test_predict_is_invariant_to_input_order_and_keeps_identity(d))
finally:
    fv2.ForecastCandidate.predict = orig_predict

# Third mutation: manifest stops recording the seed -> which test notices?
print("With the seed dropped from the manifest:")
orig_fit_final = fv2.fit_final_candidate
def no_seed(*a, **k):
    c = orig_fit_final(*a, **k); c.manifest["training"].pop("seed"); return c
fv2.fit_final_candidate = no_seed
try:
    aux_cfg = T.aux_config.__wrapped__() if hasattr(T.aux_config, "__wrapped__") else fv2.CandidateConfig("xgb_abs_resid_aux_small", "xgboost", target="residual_over_persistence", feature_set="leakage_plus_aux", objective="reg:absoluteerror", params={"n_estimators": 30})
    aux = fv2.fit_final_candidate(training, aux_cfg, seed=17, n_jobs=1)
    def manifest_test():
        try: T.test_manifest_records_provenance(tmp, training, aux, aux_cfg, d, Path(tempfile.mkdtemp()))
        except KeyError as ex: raise AssertionError(f"KeyError {ex}")
    run("NEW test_manifest_records_provenance", manifest_test)
    run("ORIGINAL test_saved_candidate_reloads_and_matches", lambda: T.test_saved_candidate_reloads_and_matches(training, configs, d))
finally:
    fv2.fit_final_candidate = orig_fit_final
