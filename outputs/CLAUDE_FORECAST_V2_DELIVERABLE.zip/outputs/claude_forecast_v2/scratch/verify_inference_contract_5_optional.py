"""Check 5: dropping optional columns -> aux imputes with medians, leak unaffected."""
from pathlib import Path

import numpy as np
import pandas as pd

from sih26170 import forecast_v2 as fv2

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
CAND = PACK / "outputs/claude_forecast_v2/candidate"
early_all = fv2.read_identity_csv(PACK / "data/train_early.csv")
batch = sorted(early_all["batch_id"].unique())[7]
early = early_all.loc[early_all["batch_id"] == batch].reset_index(drop=True)
OPTIONAL = ["capacitance_nf", "dissipation_factor_pct", "prior_storage_humidity_pct", "tester_channel"]

leak = fv2.load_forecast_candidate(CAND / "xgb_abs_resid_leak")
aux = fv2.load_forecast_candidate(CAND / "xgb_abs_resid_aux")
full_leak, full_aux = leak.predict(early), aux.predict(early)

for drop in ([c] for c in OPTIONAL):
    d = early.drop(columns=drop)
    l2, a2 = leak.predict(d), aux.predict(d)
    pd.testing.assert_frame_equal(full_leak, l2)
    diff = (a2["predicted_normalized"] - full_aux["predicted_normalized"]).abs()
    print(f"drop {drop}: leak identical=True | aux mean|d|={diff.mean():.4f} max={diff.max():.4f} share changed={(diff>0).mean():.2f} statuses={a2['status'].value_counts().to_dict()}")

d = early.drop(columns=OPTIONAL)
l2, a2 = leak.predict(d), aux.predict(d)
pd.testing.assert_frame_equal(full_leak, l2)
diff = (a2["predicted_normalized"] - full_aux["predicted_normalized"]).abs()
print(f"drop ALL optional: leak identical=True | aux mean|d|={diff.mean():.4f} max={diff.max():.4f}")
# verify aux imputes exactly with manifest medians
feats, val, _ = fv2.prepare_early_features(d)
feats = fv2.augment_features(feats, val)
med = aux.manifest["imputation_medians"]
for c in fv2.AUX_FEATURES:
    assert feats[c].isna().all(), c
X = fv2.impute(fv2.feature_matrix(feats, aux.manifest["feature_columns"]), med)
for i, c in enumerate(aux.manifest["feature_columns"]):
    if c in fv2.AUX_FEATURES:
        assert np.allclose(X[:, i], med[c]), c
print("aux features all NaN when optional columns dropped and imputed exactly with manifest medians: OK")

# drop ALL metadata columns (minimal REQUIRED_COLUMNS + profile_id)
minimal = early[fv2.IDENTITY + ["hours", "measurement_value", "upper_limit", "profile_id"]]
print("minimal columns leak:", leak.predict(minimal)["status"].value_counts().to_dict(), "identical:", full_leak.equals(leak.predict(minimal)))
print("minimal columns aux:", aux.predict(minimal)["status"].value_counts().to_dict())
# partially missing optional values (NaN in some rows) - aux should median-impute those parts only
p = early.copy(); ids = sorted(p["component_id"].unique())[:5]
p.loc[p["component_id"].isin(ids), "capacitance_nf"] = np.nan
a3 = aux.predict(p)
ch = (a3["predicted_normalized"] - full_aux["predicted_normalized"]).abs()
print("partial NaN capacitance_nf for 5 parts: changed parts =", sorted(a3.loc[ch > 0, "component_id"]), "statuses", a3["status"].value_counts().to_dict())
# nominal_capacitance_nf missing -> capacitance fractions NaN
p = early.drop(columns=["nominal_capacitance_nf"])
print("drop nominal_capacitance_nf: aux statuses", aux.predict(p)["status"].value_counts().to_dict())
