"""Diagnostic: which scenarios / onset times are predictable from 0h+24h signals.

Retrospective analysis only. No predictive model is fitted; only descriptive
statistics, Spearman/Pearson correlations and roc_auc_score are used.
Labels are used exclusively to EXPLAIN persistence / linear-extrapolation errors.
"""
from __future__ import annotations

import json
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import spearmanr, pearsonr
from sklearn.metrics import roc_auc_score

warnings.filterwarnings("ignore")
pd.set_option("display.width", 250)
pd.set_option("display.max_columns", 40)
pd.set_option("display.max_rows", 200)
pd.set_option("display.float_format", lambda v: f"{v:.4f}")

PACK = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
sys.path.insert(0, str(PACK / "src"))
from sih26170.mlcc_prototype import prepare_early_features  # noqa: E402

DATA = PACK / "data"
OUT = PACK / "outputs" / "claude_forecast_v2" / "scratch"
PREFIX = "diag_scenario_predictability"
ID_COLS = ["component_id", "batch_id", "component_family", "measurement_name"]
ID_DTYPES = {c: str for c in ID_COLS}
HOURS = [0, 6, 12, 24, 48, 72, 96, 120, 144, 168]
DRIFT = ["accelerating_drift", "gradual_drift", "moisture_associated_history", "late_abrupt_onset"]

results: dict[str, object] = {}


def banner(title: str) -> None:
    print("\n" + "=" * 100)
    print(title)
    print("=" * 100)


# ----------------------------------------------------------------------------
# Load
# ----------------------------------------------------------------------------
early = pd.read_csv(DATA / "train_early.csv", dtype=ID_DTYPES)
labels = pd.read_csv(DATA / "train_labels.csv", dtype=ID_DTYPES)
readings = pd.read_csv(DATA / "train_readings.csv", dtype=ID_DTYPES)
assert len(early) == 14400 and len(labels) == 7200 and len(readings) == 72000

features, _, unscored = prepare_early_features(early)
assert not unscored and len(features) == 7200

df = features.merge(labels, on=ID_COLS, how="inner", validate="one_to_one", suffixes=("", "_lab"))
assert len(df) == 7200
assert np.allclose(df["upper_limit"], df["upper_limit_lab"])

df["y"] = df["final_value"] / df["upper_limit"]
df["y_true"] = df["true_final_value"] / df["upper_limit"]
df["persist"] = df["limit_fraction"]
df["resid"] = df["y"] - df["persist"]
df["linext"] = np.maximum(df["limit_fraction"] + df["slope_fraction_per_hour"] * 144.0, 0.0)
df["resid_lin"] = df["y"] - df["linext"]
df["cross"] = df["y"] >= 1.0
df["onset"] = df["anomaly_onset_hour"]
is_tcf = df["scenario"] == "tester_channel_fault"
df.loc[is_tcf, "onset"] = df.loc[is_tcf, "tester_fault_onset_hour"]

# normalized trajectory matrix from readings (retrospective only)
readings["hours"] = readings["hours"].astype(float)
readings["norm"] = readings["measurement_value"] / readings["upper_limit"]
traj = readings.pivot_table(index="component_id", columns="hours", values="norm", aggfunc="first")
traj.columns = [int(c) for c in traj.columns]
assert list(traj.columns) == HOURS
traj = traj.loc[df["component_id"].to_numpy()]
T = traj.to_numpy(dtype=float)  # 7200 x 10 aligned with df rows
assert np.allclose(T[:, 3], df["limit_fraction"].to_numpy(), atol=1e-9)
assert np.allclose(T[:, 9], df["y"].to_numpy(), atol=1e-9)

banner("SANITY")
print("rows", len(df), "| scenarios:")
print(df["scenario"].value_counts().to_string())
print("\nscenario vs component_scenario (off-diagonal = defect + tester fault coexisting):")
print(pd.crosstab(df["scenario"], df["component_scenario"]).to_string())
print(f"\npersistence MAE={df['resid'].abs().mean():.4f}, mean resid={df['resid'].mean():.4f}; "
      f"linext MAE={df['resid_lin'].abs().mean():.4f}, mean resid={df['resid_lin'].mean():.4f}")
print("observed crossings y>=1:", int(df["cross"].sum()), "| already >= limit at 24h:", int((df["persist"] >= 1).sum()))
results["sanity"] = {
    "n": int(len(df)),
    "persistence_mae": float(df["resid"].abs().mean()),
    "persistence_mean_resid": float(df["resid"].mean()),
    "linext_mae": float(df["resid_lin"].abs().mean()),
    "linext_mean_resid": float(df["resid_lin"].mean()),
    "n_cross": int(df["cross"].sum()),
}

# ----------------------------------------------------------------------------
# 1. scenario x onset cells
# ----------------------------------------------------------------------------
banner("1. SCENARIO x ONSET CELLS (onset = anomaly_onset_hour; tester_fault_onset_hour for tester_channel_fault)")
FEATS = ["delta_fraction_of_limit", "percent_change", "slope_batch_robust_z", "current_batch_robust_z"]


def cell_stats(g: pd.DataFrame) -> pd.Series:
    out = {
        "n": len(g),
        "n_cross": int(g["cross"].sum()),
        "mean_y": g["y"].mean(),
        "mean_resid": g["resid"].mean(),
        "mae": g["resid"].abs().mean(),
    }
    for f in FEATS:
        out[f"{f}_mean"] = g[f].mean()
        out[f"{f}_med"] = g[f].median()
    return pd.Series(out)


df["onset_str"] = df["onset"].map(lambda v: "none" if pd.isna(v) else str(int(v)))
cells = df.groupby(["scenario", "onset_str"]).apply(cell_stats, include_groups=False).reset_index()
cells["onset_num"] = cells["onset_str"].map(lambda s: -1 if s == "none" else int(s))
cells = cells.sort_values(["scenario", "onset_num"]).drop(columns="onset_num")
# print in two blocks for readability
print(cells[["scenario", "onset_str", "n", "n_cross", "mean_y", "mean_resid", "mae"]].to_string(index=False))
print()
print(cells[["scenario", "onset_str", "n"] + [f"{f}_{s}" for f in FEATS for s in ("mean", "med")]].to_string(index=False))
cells.to_csv(OUT / f"{PREFIX}_cells.csv", index=False)

# healthy reference for the 24h features
healthy = df[df["scenario"] == "healthy_settling"]
print("\nhealthy_settling reference (24h features):")
print(healthy[FEATS].describe(percentiles=[0.05, 0.5, 0.95, 0.99]).T.to_string())

# per-scenario abs error share
share = df.groupby("scenario")["resid"].apply(lambda s: s.abs().sum())
share = (share / share.sum()).sort_values(ascending=False)
print("\nshare of total persistence absolute error by scenario:")
print(share.to_string())
results["abs_error_share_by_scenario"] = {k: float(v) for k, v in share.items()}

# --- is there a 24h signal for onset > 24h? ---
banner("1b. LATE ONSET (>24h): 24h-feature separability vs healthy_settling  (AUC, positives = late-onset parts)")
late = df[(df["is_defect"]) & (df["onset"] > 24)]
early_on = df[(df["is_defect"]) & (df["onset"] <= 24)]
print(f"defect parts with onset>24: {len(late)} (crossers {int(late['cross'].sum())}); onset<=24: {len(early_on)} (crossers {int(early_on['cross'].sum())})")


def auc_vs_healthy(pos: pd.DataFrame, feat: str, absval: bool = False) -> float:
    a = pd.concat([pos.assign(_lab=1), healthy.assign(_lab=0)])
    x = a[feat].abs() if absval else a[feat]
    return roc_auc_score(a["_lab"], x)


rows = []
for scen in ["late_abrupt_onset", "gradual_drift", "accelerating_drift", "moisture_associated_history", "intermittent_leakage"]:
    for grp_name, grp in [("onset<=24", early_on), ("onset>24", late)]:
        sub = grp[grp["scenario"] == scen]
        if len(sub) < 5:
            continue
        r = {"scenario": scen, "group": grp_name, "n": len(sub), "n_cross": int(sub["cross"].sum())}
        for f in FEATS:
            r[f"auc_{f}"] = auc_vs_healthy(sub, f)
        r["auc_abs_slope_z"] = auc_vs_healthy(sub, "slope_batch_robust_z", absval=True)
        r["auc_abs_cur_z"] = auc_vs_healthy(sub, "current_batch_robust_z", absval=True)
        r["auc_limit_fraction"] = auc_vs_healthy(sub, "limit_fraction")
        rows.append(r)
sep = pd.DataFrame(rows)
print(sep.to_string(index=False))
sep.to_csv(OUT / f"{PREFIX}_late_onset_auc_vs_healthy.csv", index=False)
results["auc_vs_healthy_by_scenario_group"] = sep.to_dict(orient="records")

# late_abrupt_onset per onset hour vs healthy
rows = []
lao = df[df["scenario"] == "late_abrupt_onset"]
for on, sub in lao.groupby("onset"):
    r = {"onset": int(on), "n": len(sub), "n_cross": int(sub["cross"].sum()), "mean_y": sub["y"].mean()}
    for f in ["delta_fraction_of_limit", "slope_batch_robust_z", "current_batch_robust_z", "limit_fraction"]:
        r[f"auc_{f}"] = auc_vs_healthy(sub, f)
    rows.append(r)
lao_auc = pd.DataFrame(rows)
print("\nlate_abrupt_onset by onset hour, AUC vs healthy:")
print(lao_auc.to_string(index=False))
results["late_abrupt_onset_auc_by_onset"] = lao_auc.to_dict(orient="records")

# --- separability for 'will cross' ---
banner("1c. AUC for 'will cross (y>=1)'")
rows = []
noncross_all = df[~df["cross"]]


def auc_block(name: str, pos: pd.DataFrame, neg: pd.DataFrame) -> dict:
    a = pd.concat([pos.assign(_lab=1), neg.assign(_lab=0)])
    r = {"setting": name, "n_pos": len(pos), "n_neg": len(neg)}
    for f in ["slope_batch_robust_z", "delta_fraction_of_limit", "current_batch_robust_z", "limit_fraction", "percent_change"]:
        r[f"auc_{f}"] = roc_auc_score(a["_lab"], a[f])
    return r


rows.append(auc_block("all parts: cross vs not", df[df["cross"]], noncross_all))
rows.append(auc_block("all parts excl already>=1 @24h", df[df["cross"] & (df["persist"] < 1)], noncross_all))
rows.append(auc_block("onset<=24 crossers vs ALL non-crossers", early_on[early_on["cross"]], noncross_all))
rows.append(auc_block("onset>24 crossers vs ALL non-crossers", late[late["cross"]], noncross_all))
rows.append(auc_block("onset<=24 crossers vs healthy_settling", early_on[early_on["cross"]], healthy))
rows.append(auc_block("onset>24 crossers vs healthy_settling", late[late["cross"]], healthy))
rows.append(auc_block("WITHIN defects onset<=24: cross vs not", early_on[early_on["cross"]], early_on[~early_on["cross"]]))
rows.append(auc_block("WITHIN defects onset>24: cross vs not", late[late["cross"]], late[~late["cross"]]))
for on_lo, on_hi, nm in [(48, 72, "onset 48-72"), (96, 144, "onset 96-144")]:
    sub = late[(late["onset"] >= on_lo) & (late["onset"] <= on_hi)]
    rows.append(auc_block(f"{nm} crossers vs healthy", sub[sub["cross"]], healthy))
cross_auc = pd.DataFrame(rows)
print(cross_auc.to_string(index=False))
cross_auc.to_csv(OUT / f"{PREFIX}_cross_auc.csv", index=False)
results["cross_auc"] = cross_auc.to_dict(orient="records")

# retrospective trajectory of late-onset parts: when does the normalized value depart from its 24h value?
banner("1d. RETROSPECTIVE mean normalized trajectory by scenario x onset (from train_readings)")
traj_df = pd.DataFrame(T, columns=[f"h{h}" for h in HOURS])
traj_df["scenario"] = df["scenario"].to_numpy()
traj_df["onset_str"] = df["onset_str"].to_numpy()
mt = traj_df.groupby(["scenario", "onset_str"]).mean(numeric_only=True)
mt["n"] = traj_df.groupby(["scenario", "onset_str"]).size()
mt = mt.reset_index()
mt["onset_num"] = mt["onset_str"].map(lambda s: -1 if s == "none" else int(s))
mt = mt.sort_values(["scenario", "onset_num"]).drop(columns="onset_num")
print(mt.to_string(index=False))
mt.to_csv(OUT / f"{PREFIX}_mean_traj.csv", index=False)

# ----------------------------------------------------------------------------
# 2. Drift scenarios with onset <= 24h: linear relation delta -> residual
# ----------------------------------------------------------------------------
banner("2. DRIFT SCENARIOS onset<=24: correlation of 24h delta/slope with 168h persistence residual; linext bias")
rows = []
for scen in DRIFT:
    for grp_name, mask in [("onset<=24", df["onset"] <= 24), ("onset>24", df["onset"] > 24), ("all", df["onset"].notna())]:
        sub = df[(df["scenario"] == scen) & mask]
        if len(sub) < 10:
            continue
        rho_d, _ = spearmanr(sub["delta_fraction_of_limit"], sub["resid"])
        rho_s, _ = spearmanr(sub["slope_fraction_per_hour"], sub["resid"])
        r_d, _ = pearsonr(sub["delta_fraction_of_limit"], sub["resid"])
        rho_dy, _ = spearmanr(sub["delta_fraction_of_limit"], sub["y"])
        rho_zy, _ = spearmanr(sub["slope_batch_robust_z"], sub["resid"])
        rows.append({
            "scenario": scen, "group": grp_name, "n": len(sub), "n_cross": int(sub["cross"].sum()),
            "spearman_delta_resid": rho_d, "spearman_slope_resid": rho_s, "spearman_slopez_resid": rho_zy,
            "pearson_delta_resid": r_d, "pearson_r2": r_d ** 2, "spearman_delta_y": rho_dy,
            "mean_resid_persist": sub["resid"].mean(), "mae_persist": sub["resid"].abs().mean(),
            "mean_resid_linext": sub["resid_lin"].mean(), "mae_linext": sub["resid_lin"].abs().mean(),
            "median_resid_linext": sub["resid_lin"].median(),
            "median_ratio_resid_over_delta": (sub["resid"] / sub["delta_fraction_of_limit"].where(sub["delta_fraction_of_limit"].abs() > 1e-6)).median(),
            "median_ratio_resid_over_delta_x6": 6.0,  # linear extrapolation implies resid = 6 * delta (144/24)
        })
drift = pd.DataFrame(rows)
print(drift.to_string(index=False))
drift.to_csv(OUT / f"{PREFIX}_drift_corr.csv", index=False)
results["drift_corr"] = drift.to_dict(orient="records")

# by onset hour within drift scenarios (onset<=24): linext bias
print("\nlinear-extrapolation residual by scenario x onset (onset<=24):")
lo = df[df["scenario"].isin(DRIFT) & (df["onset"] <= 24)]
g = lo.groupby(["scenario", "onset"]).agg(
    n=("y", "size"), mean_y=("y", "mean"), mean_delta=("delta_fraction_of_limit", "mean"),
    mean_resid_persist=("resid", "mean"), mean_resid_linext=("resid_lin", "mean"),
    median_resid_linext=("resid_lin", "median"), mae_persist=("resid", lambda s: s.abs().mean()),
    mae_linext=("resid_lin", lambda s: s.abs().mean()),
    frac_linext_over=("resid_lin", lambda s: (s < 0).mean()),
).reset_index()
print(g.to_string(index=False))
results["drift_linext_by_onset"] = g.to_dict(orient="records")

# curvature: retrospective ratio of (168-24 change) to (24-0 change) per scenario
print("\nretrospective growth multiplier (y168 - y24) / (y24 - y0), median, for onset<=24 (linear => 6.0):")
for scen in DRIFT:
    sub = lo[lo["scenario"] == scen]
    d24 = sub["delta_fraction_of_limit"]
    ok = d24 > 0.01
    mult = (sub.loc[ok, "resid"] / d24[ok])
    print(f"  {scen:30s} n={ok.sum():4d}  median mult={mult.median():7.2f}  q25={mult.quantile(.25):7.2f}  q75={mult.quantile(.75):7.2f}  (n with delta<=0.01: {(~ok).sum()})")

# ----------------------------------------------------------------------------
# 3. Healthy settling
# ----------------------------------------------------------------------------
banner("3. HEALTHY SETTLING: direction/magnitude of 24h->168h change; persistence bias")
h = healthy
desc = h["resid"].describe(percentiles=[0.01, 0.05, 0.25, 0.5, 0.75, 0.95, 0.99])
print("persistence residual (y - limit_fraction) on healthy_settling:")
print(desc.to_string())
ratio = (h["y"] / h["persist"])
print(f"\ny/persist ratio: median={ratio.median():.4f} mean={ratio.mean():.4f} q05={ratio.quantile(.05):.4f} q95={ratio.quantile(.95):.4f}")
print(f"fraction of healthy with y < persist (falling): {(h['resid'] < 0).mean():.3f}")
print(f"mean limit_fraction@24h={h['persist'].mean():.4f}, mean y={h['y'].mean():.4f}, mean y_true={h['y_true'].mean():.4f}")
print(f"mean 0h fraction={h['initial_fraction_of_limit'].mean():.4f}; mean 0->24 delta={h['delta_fraction_of_limit'].mean():.4f}")
mean_traj_h = T[(df["scenario"] == "healthy_settling").to_numpy()].mean(axis=0)
print("mean normalized trajectory healthy:", dict(zip(HOURS, np.round(mean_traj_h, 4))))
# noise floor: latent vs observed
print(f"healthy |y - y_true| mean={ (h['y']-h['y_true']).abs().mean():.4f} (observation noise at 168h, normalized)")
print(f"healthy |y_true - persist| mean={ (h['y_true']-h['persist']).abs().mean():.4f}")

# What would a bias correction buy?
tot_abs = df["resid"].abs().sum()
h_abs = h["resid"].abs().sum()
med_bias = h["resid"].median()
mean_bias = h["resid"].mean()
h_abs_after_add = (h["resid"] - med_bias).abs().sum()
med_ratio = ratio.median()
h_abs_after_mult = (h["y"] - h["persist"] * med_ratio).abs().sum()
# also oracle: best possible per-part = noise floor |y - y_true|
noise_floor = (h["y"] - h["y_true"]).abs().sum()
print(f"\nhealthy abs error total={h_abs:.2f} of overall {tot_abs:.2f} ({100*h_abs/tot_abs:.1f}%); healthy MAE={h_abs/len(h):.4f}")
print(f"  additive median-bias correction ({med_bias:+.4f}): healthy MAE -> {h_abs_after_add/len(h):.4f}; overall MAE {tot_abs/len(df):.4f} -> {(tot_abs-h_abs+h_abs_after_add)/len(df):.4f}")
print(f"  multiplicative median-ratio correction (x{med_ratio:.3f}): healthy MAE -> {h_abs_after_mult/len(h):.4f}; overall MAE -> {(tot_abs-h_abs+h_abs_after_mult)/len(df):.4f}")
print(f"  oracle (predict y_true exactly): healthy MAE -> {noise_floor/len(h):.4f}; overall MAE -> {(tot_abs-h_abs+noise_floor)/len(df):.4f}")
# same for ordinary_noise
on = df[df["scenario"] == "ordinary_noise"]
print(f"\nordinary_noise: n={len(on)} mean resid={on['resid'].mean():+.4f} median={on['resid'].median():+.4f} MAE={on['resid'].abs().mean():.4f}; "
      f"y/persist median={ (on['y']/on['persist']).median():.4f}; |y-y_true| mean={(on['y']-on['y_true']).abs().mean():.4f}")
# healthy by profile
print("\nhealthy_settling by profile_id:")
print(h.groupby("profile_id").agg(n=("y", "size"), mean_persist=("persist", "mean"), mean_y=("y", "mean"),
                                  mean_resid=("resid", "mean"), median_resid=("resid", "median"),
                                  median_ratio=("y", lambda s: (s / h.loc[s.index, "persist"]).median()),
                                  mae=("resid", lambda s: s.abs().mean())).to_string())
results["healthy"] = {
    "n": int(len(h)), "mean_resid": float(mean_bias), "median_resid": float(med_bias),
    "mae": float(h_abs / len(h)), "median_ratio_y_over_persist": float(med_ratio),
    "frac_falling": float((h["resid"] < 0).mean()),
    "mae_after_additive": float(h_abs_after_add / len(h)), "mae_after_mult": float(h_abs_after_mult / len(h)),
    "mae_oracle_noise_floor": float(noise_floor / len(h)),
    "overall_mae_before": float(tot_abs / len(df)),
    "overall_mae_after_mult": float((tot_abs - h_abs + h_abs_after_mult) / len(df)),
    "overall_mae_after_oracle_healthy": float((tot_abs - h_abs + noise_floor) / len(df)),
    "healthy_share_abs_err": float(h_abs / tot_abs),
    "mean_traj": {str(k): float(v) for k, v in zip(HOURS, mean_traj_h)},
}

# ----------------------------------------------------------------------------
# 4. Intermittent leakage
# ----------------------------------------------------------------------------
banner("4. INTERMITTENT LEAKAGE: trajectory shape, spikes, persistence residual")
im = (df["scenario"] == "intermittent_leakage").to_numpy()
Ti = T[im]
di = df[im]
print(f"n={im.sum()}, onset counts: {di['onset_str'].value_counts().to_dict()}")
print("persistence residual:", di["resid"].describe(percentiles=[0.05, 0.25, 0.5, 0.75, 0.95]).to_string())
print(f"crossers at 168h (y>=1): {int(di['cross'].sum())}; latent y_true>=1: {int((di['y_true']>=1).sum())}; ever_latent_exceedance: {int(di['ever_latent_exceedance'].sum())}; is_future_failure: {int(di['is_future_failure'].sum())}")
# per-part baseline = median over all 10 checkpoints; spike = value > baseline + max(0.1, 2*baseline)
base = np.median(Ti, axis=1)
spike_thr = base + np.maximum(0.10, 1.0 * base)  # more than double the baseline and at least +0.1 of limit
is_spike = Ti > spike_thr[:, None]
n_spikes = is_spike.sum(axis=1)
print(f"\nspike definition: norm value > baseline(median of 10) + max(0.10, 1.0*baseline)")
print("spikes per part distribution:", pd.Series(n_spikes).value_counts().sort_index().to_dict())
print("spike frequency by checkpoint hour:", dict(zip(HOURS, is_spike.mean(axis=0).round(3))))
spike24 = is_spike[:, 3]
spike168 = is_spike[:, 9]
print(f"24h reading is a spike: {spike24.sum()} ({spike24.mean():.1%}); 168h reading is a spike: {spike168.sum()} ({spike168.mean():.1%}); both: {(spike24 & spike168).sum()}")
print(f"24h is the max of the trajectory: {(Ti.argmax(axis=1)==3).sum()}; 168h is the max: {(Ti.argmax(axis=1)==9).sum()}")
r = di["resid"].to_numpy()
print(f"mean resid | 24h spike: {r[spike24].mean():+.4f} (n={spike24.sum()}) ; | no 24h spike: {r[~spike24].mean():+.4f} (n={(~spike24).sum()})")
print(f"mean resid | 168h spike: {r[spike168].mean():+.4f} (n={spike168.sum()}) ; | no 168h spike: {r[~spike168].mean():+.4f} (n={(~spike168).sum()})")
print(f"median resid | no spike at 24 or 168: {np.median(r[~spike24 & ~spike168]):+.4f} (n={(~spike24 & ~spike168).sum()})")
# amplitude of spikes
amp = (Ti - base[:, None])[is_spike]
print(f"spike amplitude above baseline (normalized): median={np.median(amp):.3f} q90={np.quantile(amp,.9):.3f} max={amp.max():.3f}")
print(f"baseline (median of 10): median={np.median(base):.3f} q90={np.quantile(base,.9):.3f}")
# how many crossers had 168h spike
cr = di["cross"].to_numpy()
print(f"of {cr.sum()} crossers: 168h spike {spike168[cr].sum()}, 24h spike {spike24[cr].sum()}, baseline>=1: {(base[cr]>=1).sum()}")
# alternative anchors available at 24h for the 24h-spike parts: 0h value, min(0h,24h)
y_i = di["y"].to_numpy(); p24 = di["limit_fraction"].to_numpy(); p0 = di["initial_fraction_of_limit"].to_numpy()
for nm, m in [("24h spike", spike24), ("no 24h spike", ~spike24), ("all intermittent", np.ones(len(di), bool))]:
    print(f"  anchor MAE [{nm}, n={m.sum()}]: persist(24h)={np.abs(y_i[m]-p24[m]).mean():.3f}  0h={np.abs(y_i[m]-p0[m]).mean():.3f}  "
          f"min(0h,24h)={np.abs(y_i[m]-np.minimum(p0[m],p24[m])).mean():.3f}  mean(0h,24h)={np.abs(y_i[m]-0.5*(p0[m]+p24[m])).mean():.3f}")
# how identifiable is a 24h spike from 24h data alone? ratio 24h/0h
ratio24 = di["limit_fraction"] / di["initial_fraction_of_limit"].clip(lower=1e-6)
print(f"  24h/0h ratio > 2 among intermittent: {(ratio24>2).sum()} parts, of which retrospective 24h-spike: {(spike24 & (ratio24>2).to_numpy()).sum()}; "
      f"ratio>2 among healthy_settling: {int((healthy['limit_fraction']/healthy['initial_fraction_of_limit']>2).sum())}, ordinary_noise: "
      f"{int((on['limit_fraction']/on['initial_fraction_of_limit']>2).sum())}, all non-intermittent: {int(((df['limit_fraction']/df['initial_fraction_of_limit'])>2)[~im].sum())}")
# mean trajectory
print("mean normalized trajectory intermittent:", dict(zip(HOURS, np.round(Ti.mean(axis=0), 4))))
print("median normalized trajectory intermittent:", dict(zip(HOURS, np.round(np.median(Ti, axis=0), 4))))
# 24h features distribution
print("\n24h features for intermittent (mean / median):")
print(di[FEATS + ["limit_fraction", "variability_fraction_of_limit"]].agg(["mean", "median"]).T.to_string())
# share of positive residual mass from a few parts
pos_r = np.sort(r[r > 0])[::-1]
print(f"positive residual: n={len(pos_r)}, sum={pos_r.sum():.2f}; top 20 parts carry {pos_r[:20].sum()/pos_r.sum():.1%} of positive residual mass")
results["intermittent"] = {
    "n": int(im.sum()), "mean_resid": float(r.mean()), "median_resid": float(np.median(r)),
    "n_cross": int(cr.sum()), "n_latent_cross": int((di["y_true"] >= 1).sum()),
    "n_ever_latent_exceedance": int(di["ever_latent_exceedance"].sum()),
    "spike24_n": int(spike24.sum()), "spike168_n": int(spike168.sum()),
    "mean_resid_spike24": float(r[spike24].mean()) if spike24.any() else None,
    "mean_resid_nospike24": float(r[~spike24].mean()),
    "mean_resid_spike168": float(r[spike168].mean()) if spike168.any() else None,
    "spike_freq_by_hour": {str(k): float(v) for k, v in zip(HOURS, is_spike.mean(axis=0))},
    "spikes_per_part": {str(k): int(v) for k, v in pd.Series(n_spikes).value_counts().sort_index().items()},
}

# ----------------------------------------------------------------------------
# 5. Crossings by scenario and 'unwarned' crossings
# ----------------------------------------------------------------------------
banner("5. OBSERVED CROSSINGS (y>=1) BY SCENARIO; UNWARNED = |slope_z|<2 and delta_frac<0.05")
crossers = df[df["cross"]].copy()
crossers["unwarned"] = (crossers["slope_batch_robust_z"].abs() < 2) & (crossers["delta_fraction_of_limit"] < 0.05)
crossers["unwarned_strict"] = crossers["unwarned"] & (crossers["current_batch_robust_z"].abs() < 2) & (crossers["limit_fraction"] < 0.5)
crossers["already_over"] = crossers["limit_fraction"] >= 1
by_scen = crossers.groupby("scenario").agg(
    n_cross=("y", "size"), already_over_24h=("already_over", "sum"),
    unwarned=("unwarned", "sum"), unwarned_strict=("unwarned_strict", "sum"),
    mean_limit_frac_24h=("limit_fraction", "mean"), median_limit_frac_24h=("limit_fraction", "median"),
    mean_y=("y", "mean"),
).sort_values("n_cross", ascending=False)
by_scen["share_of_553"] = by_scen["n_cross"] / len(crossers)
print(by_scen.to_string())
print(f"\nTOTAL crossers={len(crossers)}, unwarned={int(crossers['unwarned'].sum())} ({crossers['unwarned'].mean():.1%}), "
      f"unwarned_strict={int(crossers['unwarned_strict'].sum())} ({crossers['unwarned_strict'].mean():.1%}); "
      f"already>=1 at 24h={int(crossers['already_over'].sum())}")
print(f"=> honest recall ceiling for a 24h-only forecaster (warned crossers / all crossers): "
      f"{1-crossers['unwarned'].mean():.3f} (loose) ; {1-crossers['unwarned_strict'].mean():.3f} (strict incl. cur_z<2 & limit_frac<0.5)")
print("\nunwarned crossers by scenario x onset:")
uw = crossers[crossers["unwarned"]].groupby(["scenario", "onset_str"]).size().rename("n").reset_index()
uw["onset_num"] = uw["onset_str"].map(lambda s: -1 if s == "none" else int(s))
print(uw.sort_values(["scenario", "onset_num"]).drop(columns="onset_num").to_string(index=False))
print("\ncrossers by onset (all scenarios):")
co = crossers.groupby("onset_str").agg(n_cross=("y", "size"), unwarned=("unwarned", "sum")).reset_index()
co["onset_num"] = co["onset_str"].map(lambda s: -1 if s == "none" else int(s))
print(co.sort_values("onset_num").drop(columns="onset_num").to_string(index=False))

# how far above limit are the unwarned crossers? (a small exceedance is 'near miss')
uwc = crossers[crossers["unwarned"]]
print(f"\nunwarned crossers y: median={uwc['y'].median():.3f} q25={uwc['y'].quantile(.25):.3f} q75={uwc['y'].quantile(.75):.3f}; "
      f"y_true>=1 among them: {(uwc['y_true']>=1).sum()}; y in [1,1.1): {((uwc['y']>=1)&(uwc['y']<1.1)).sum()}")
# false-alarm cost of the warning rule among non-crossers
nc = df[~df["cross"]]
warned_nc = ~((nc["slope_batch_robust_z"].abs() < 2) & (nc["delta_fraction_of_limit"] < 0.05))
print(f"non-crossers flagged by the same loose rule: {int(warned_nc.sum())} of {len(nc)} ({warned_nc.mean():.1%}); by scenario:")
print(nc[warned_nc].groupby("scenario").size().sort_values(ascending=False).to_string())
# sensitivity: alternative thresholds
print("\nsensitivity of unwarned count to thresholds (slope_z, delta_frac):")
for zt in (1.5, 2, 3):
    for dt_ in (0.02, 0.05, 0.10):
        u = ((crossers["slope_batch_robust_z"].abs() < zt) & (crossers["delta_fraction_of_limit"] < dt_)).sum()
        w = (~((nc["slope_batch_robust_z"].abs() < zt) & (nc["delta_fraction_of_limit"] < dt_))).sum()
        print(f"  |slope_z|<{zt} & delta<{dt_}: unwarned crossers={u:3d} ({u/len(crossers):.1%})  flagged non-crossers={w:4d} ({w/len(nc):.1%})")
results["crossings"] = {
    "n_cross": int(len(crossers)), "n_unwarned": int(crossers["unwarned"].sum()),
    "n_unwarned_strict": int(crossers["unwarned_strict"].sum()),
    "n_already_over_24h": int(crossers["already_over"].sum()),
    "recall_ceiling_loose": float(1 - crossers["unwarned"].mean()),
    "recall_ceiling_strict": float(1 - crossers["unwarned_strict"].mean()),
    "by_scenario": by_scen.reset_index().to_dict(orient="records"),
    "unwarned_by_scenario_onset": uw.drop(columns="onset_num").to_dict(orient="records"),
    "flagged_noncrossers_loose": int(warned_nc.sum()),
}

# ----------------------------------------------------------------------------
# 6. 'Looks healthy at 24h' population: error floor and interval implications
# ----------------------------------------------------------------------------
banner("6. LOOKS-HEALTHY-AT-24h POPULATION (|slope_z|<2 & delta<0.05 & |cur_z|<2 & limit_frac<0.5): floor for any 24h-only forecaster")
looks_ok = ((df["slope_batch_robust_z"].abs() < 2) & (df["delta_fraction_of_limit"] < 0.05)
            & (df["current_batch_robust_z"].abs() < 2) & (df["limit_fraction"] < 0.5))
lk = df[looks_ok]
print(f"n looks-healthy = {len(lk)} ({looks_ok.mean():.1%} of parts); crossers among them = {int(lk['cross'].sum())} "
      f"({lk['cross'].mean():.2%}); defects among them = {int(lk['is_defect'].sum())}; tester faults = {int(lk['is_tester_fault'].sum())}")
print("scenario mix of looks-healthy parts:")
print(lk["scenario"].value_counts().to_string())
print(f"\npersistence residual within looks-healthy: mean={lk['resid'].mean():+.4f} median={lk['resid'].median():+.4f} MAE={lk['resid'].abs().mean():.4f}")
qs = lk["resid"].quantile([0.5, 0.9, 0.95, 0.99, 0.995]).to_dict()
print("residual quantiles (looks-healthy):", {f"q{int(k*1000)/10}": round(v, 4) for k, v in qs.items()})
qs_h = healthy["resid"].quantile([0.5, 0.9, 0.95, 0.99]).to_dict()
print("residual quantiles (healthy_settling only):", {f"q{int(k*1000)/10}": round(v, 4) for k, v in qs_h.items()})
abs_lk = lk["resid"].abs().sum()
print(f"abs error carried by looks-healthy parts = {abs_lk:.1f} of {tot_abs:.1f} total ({abs_lk/tot_abs:.1%}); "
      f"=> if every WARNED part were forecast perfectly, overall MAE floor = {abs_lk/len(df):.4f} (vs persistence {tot_abs/len(df):.4f})")
# a best-constant-shift on looks-healthy parts cannot help: optimal constant for MAE is the median
print(f"looks-healthy: best constant additive shift (median) = {lk['resid'].median():+.4f} -> MAE {(lk['resid']-lk['resid'].median()).abs().mean():.4f}")
# conformal-style radius comparison
r_all = df["resid"].abs().quantile(0.9)
r_h = healthy["resid"].abs().quantile(0.9)
r_lk = lk["resid"].abs().quantile(0.9)
print(f"\n90% abs-residual quantile of persistence: all parts={r_all:.4f}; healthy_settling={r_h:.4f}; looks-healthy={r_lk:.4f}  "
      f"(ratio all/healthy = {r_all/r_h:.0f}x)")
print(f"share of looks-healthy parts with y>=0.5: {(lk['y']>=0.5).mean():.2%}; y>=1: {(lk['y']>=1).mean():.2%}")
# warned population
wk = df[~looks_ok]
print(f"\nWARNED population n={len(wk)}: crossers={int(wk['cross'].sum())} ({wk['cross'].mean():.1%}); persistence MAE={wk['resid'].abs().mean():.4f}; "
      f"mean resid={wk['resid'].mean():+.4f}; abs-error share={wk['resid'].abs().sum()/tot_abs:.1%}")
print("scenario mix of warned parts:")
print(wk["scenario"].value_counts().to_string())
results["looks_healthy"] = {
    "n": int(len(lk)), "n_cross": int(lk["cross"].sum()), "n_defect": int(lk["is_defect"].sum()),
    "mae_persist": float(lk["resid"].abs().mean()), "mean_resid": float(lk["resid"].mean()),
    "median_resid": float(lk["resid"].median()), "abs_err_share": float(abs_lk / tot_abs),
    "overall_mae_floor_if_warned_perfect": float(abs_lk / len(df)),
    "resid_quantiles": {str(k): float(v) for k, v in qs.items()},
    "q90_abs_resid_all": float(r_all), "q90_abs_resid_healthy": float(r_h), "q90_abs_resid_looks_healthy": float(r_lk),
    "scenario_mix": {k: int(v) for k, v in lk["scenario"].value_counts().items()},
    "warned_n": int(len(wk)), "warned_n_cross": int(wk["cross"].sum()), "warned_mae": float(wk["resid"].abs().mean()),
}

with open(OUT / f"{PREFIX}_results.json", "w") as fh:
    json.dump(results, fh, indent=1, default=lambda o: o.item() if hasattr(o, "item") else str(o))
print("\nwrote", OUT / f"{PREFIX}_results.json")
