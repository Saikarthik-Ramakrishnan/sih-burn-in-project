import time, numpy as np, pandas as pd
from sih26170 import forecast_v2 as fv2
t=time.time()
tr = fv2.load_training_data("data")
print("loaded", tr.features.shape, tr.labels.shape, round(time.time()-t,1), "s")
print({k: tr.validation[k] for k in ("components","batches","observed_final_crossing_count","already_at_or_above_limit_at_24h")})
folds = fv2.assign_batch_folds(tr.features)
print(folds.groupby("fold").agg(n=("batch_id","size"), profiles=("profile_id","nunique")).to_dict())
fv2.assert_folds_disjoint(tr.features, folds)
cfgs = [fv2.CandidateConfig("persistence","persistence"), fv2.CandidateConfig("linear_extrapolation","linear_extrapolation"),
        fv2.CandidateConfig("xgb_v1_replica","xgboost",objective="reg:squarederror",feature_set="v1_all"),
        fv2.CandidateConfig("xgb_abs_resid_aux","xgboost",objective="reg:absoluteerror",target="residual_over_persistence",feature_set="leakage_plus_aux")]
t=time.time()
res, oof = fv2.run_cross_validation(tr, cfgs, folds, n_jobs=4)
print("cv done", round(time.time()-t,1), "s")
print(fv2.comparison_table(res)[["config","mae_norm_pooled","mae_norm_fold_mean","mae_norm_fold_std","mae_ua_pooled","healthy_mae_norm","nonhealthy_mae_norm","crossing_recall","crossing_fpr","crossing_tp","crossing_fp"]].to_string())
print(oof.head(3).to_string()); print(len(oof))
# final candidate smoke
cand = fv2.fit_final_candidate(tr, cfgs[3], n_jobs=4)
out = fv2.save_forecast_candidate(cand, "outputs/claude_forecast_v2/scratch/smoke_candidate")
c2 = fv2.load_forecast_candidate(out)
early = fv2.read_identity_csv("data/train_early.csv")
sub = early[early.batch_id.isin(["MLCC_B003"])]
p1 = c2.predict(sub); p2 = c2.predict(sub.sample(frac=1, random_state=1).reset_index(drop=True))
print(p1.head(3).to_string()); print("order invariant:", p1.equals(p2), "n", len(p1), p1.status.value_counts().to_dict())
