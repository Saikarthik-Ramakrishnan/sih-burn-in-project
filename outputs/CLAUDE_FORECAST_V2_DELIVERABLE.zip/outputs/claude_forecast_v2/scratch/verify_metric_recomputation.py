"""Independent recomputation of the summary artifacts from oof_predictions.csv.

Does NOT import sih26170.forecast_v2. Every metric is re-implemented here.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path("/Users/saikarthik26/Documents/Codex/2026-09-03/claude_forecast_v2_pack")
OUT = ROOT / "outputs" / "claude_forecast_v2"
ID = ["component_id", "batch_id", "component_family", "measurement_name"]
AS_OF = 24.0

issues: list[str] = []
checks: list[str] = []


def flag(msg: str) -> None:
    issues.append(msg)
    print("MISMATCH:", msg)


def ok(msg: str) -> None:
    checks.append(msg)
    print("OK:", msg)


def close(a, b, tol=1e-9) -> bool:
    if a is None or b is None or (isinstance(a, float) and np.isnan(a)) or (isinstance(b, float) and np.isnan(b)):
        return (a is None or (isinstance(a, float) and np.isnan(a))) and (b is None or (isinstance(b, float) and np.isnan(b)))
    return abs(float(a) - float(b)) <= tol * max(1.0, abs(float(a)), abs(float(b)))


# ------------------------------------------------------------------ load
oof = pd.read_csv(OUT / "oof_predictions.csv", dtype={c: str for c in ID + ["profile_id", "config"]})
labels = pd.read_csv(ROOT / "data" / "train_labels.csv", dtype={c: str for c in ID + ["profile_id", "scenario"]})
early = pd.read_csv(ROOT / "data" / "train_early.csv", dtype={c: str for c in ID})
folds = pd.read_csv(OUT / "fold_assignment.csv", dtype=str)
table = pd.read_csv(OUT / "comparison_table.csv")
prof = pd.read_csv(OUT / "comparison_by_profile.csv")
strat = pd.read_csv(OUT / "comparison_by_stratum.csv")
cv = json.load(open(OUT / "cv_results.json"))
pre = json.load(open(OUT / "PREDECLARED_COMPARISON.json"))
md = (OUT / "COMPARISON.md").read_text()

configs = sorted(oof["config"].unique())
print("configs:", len(configs), configs)
print("oof rows:", len(oof), "labels rows:", len(labels))

# uniqueness / completeness of the join keys
if labels.duplicated(ID).any():
    flag("train_labels.csv has duplicate identity rows")
else:
    ok("train_labels identity rows unique (7200)")
per_cfg = oof.groupby("config").size()
if (per_cfg != len(labels)).any():
    flag(f"per-config oof row counts differ from labels: {per_cfg.to_dict()}")
else:
    ok(f"every config has exactly {len(labels)} oof rows")
if oof.duplicated(["config"] + ID).any():
    flag("duplicate (config, identity) rows in oof_predictions.csv")
else:
    ok("no duplicate (config, identity) rows in oof")

for c in ("is_healthy", "is_defect", "is_tester_fault", "is_future_failure", "is_observed_final_exceedance"):
    labels[c] = labels[c].astype(str).str.lower().map({"true": True, "false": False})
    assert labels[c].notna().all(), c
labels["final_value"] = labels["final_value"].astype(float)
labels["upper_limit_lab"] = labels["upper_limit"].astype(float)
labels = labels.drop(columns=["upper_limit"])
labels["anomaly_onset_hour"] = pd.to_numeric(labels["anomaly_onset_hour"], errors="coerce")
labels["tester_fault_onset_hour"] = pd.to_numeric(labels["tester_fault_onset_hour"], errors="coerce")

# 24h limit fraction directly from train_early
e24 = early[early["hours"].astype(float) == 24.0].copy()
e24["lf_from_early"] = e24["measurement_value"].astype(float) / e24["upper_limit"].astype(float)
e24 = e24[ID + ["lf_from_early", "tester_channel", "prior_storage_humidity_pct"]]

df = oof.merge(labels, on=ID, how="left", validate="many_to_one", suffixes=("", "_lab"))
assert df["final_value"].notna().all(), "unjoined oof rows"
df = df.merge(e24, on=ID, how="left", validate="many_to_one")
assert df["lf_from_early"].notna().all()
df = df.merge(folds[["batch_id", "fold"]].rename(columns={"fold": "fold_assigned"}), on="batch_id", how="left")
ok("all oof rows joined to labels + early on 4 identity columns")

# ------------------------------------------------------------------ column-consistency checks
pn, ul = df["predicted_normalized"].to_numpy(float), df["upper_limit"].to_numpy(float)
d1 = np.abs(df["predicted_final_value_ua"].to_numpy(float) - pn * ul)
d2 = np.abs(df["y_normalized"].to_numpy(float) - df["final_value_ua"].to_numpy(float) / ul)
d3 = np.abs(df["final_value_ua"].to_numpy(float) - df["final_value"].to_numpy(float))
d4 = np.abs(ul - df["upper_limit_lab"].to_numpy(float))
d5 = np.abs(df["limit_fraction"].to_numpy(float) - df["lf_from_early"].to_numpy(float))
print(f"max|pred_ua - pn*ul| = {d1.max():.3e}; max|y_norm - fv/ul| = {d2.max():.3e}; max|final_value_ua - labels.final_value| = {d3.max():.3e}; max|ul - labels.ul| = {d4.max():.3e}; max|limit_fraction - early24/ul| = {d5.max():.3e}")
(ok if d1.max() < 1e-12 else flag)(f"predicted_final_value_ua == predicted_normalized*upper_limit (max abs diff {d1.max():.2e})")
(ok if d2.max() < 1e-12 else flag)(f"y_normalized == final_value_ua/upper_limit (max abs diff {d2.max():.2e})")
(ok if d3.max() < 1e-12 else flag)(f"final_value_ua == train_labels.final_value (max abs diff {d3.max():.2e})")
(ok if d4.max() == 0 else flag)(f"oof upper_limit == train_labels.upper_limit (max abs diff {d4.max():.2e})")
(ok if d5.max() < 1e-12 else flag)(f"oof limit_fraction == 24h measurement_value/upper_limit from train_early (max abs diff {d5.max():.2e})")
neg = (pn < 0).sum()
(ok if neg == 0 else flag)(f"negative predictions: {neg}")
if df["profile_id"].ne(df["profile_id_lab"]).any():
    flag("profile_id in oof differs from labels")
else:
    ok("profile_id consistent with labels")
if df["fold"].astype(int).ne(df["fold_assigned"].astype(int)).any():
    flag("oof fold column disagrees with fold_assignment.csv")
else:
    ok("oof fold column matches fold_assignment.csv for every row")
pers = df[df["config"] == "persistence"]
exact = (pers["predicted_normalized"].to_numpy(float) == pers["limit_fraction"].to_numpy(float))
(ok if exact.all() else flag)(f"persistence predicted_normalized == limit_fraction exactly: {exact.sum()}/{len(exact)} rows equal; max diff {np.abs(pers['predicted_normalized'] - pers['limit_fraction']).max():.3e}")

# ------------------------------------------------------------------ strata
def strata(lab: pd.DataFrame) -> np.ndarray:
    out = np.full(len(lab), "healthy", dtype=object)
    d, t = lab["is_defect"].to_numpy(bool), lab["is_tester_fault"].to_numpy(bool)
    on, ton = lab["anomaly_onset_hour"].to_numpy(float), lab["tester_fault_onset_hour"].to_numpy(float)
    out[d & (on <= AS_OF)] = "defect_onset_le24"
    out[d & (on > AS_OF)] = "defect_onset_gt24"
    out[t & (ton <= AS_OF)] = "tester_fault_onset_0_12"
    out[t & (ton > AS_OF)] = "tester_fault_onset_72"
    return out


df["stratum"] = strata(df)
# sanity on the labels: is_healthy exactly == neither defect nor tester?
lab_str = strata(labels)
print("label strata counts:", pd.Series(lab_str).value_counts().to_dict())
h_mis = (labels["is_healthy"] != (~labels["is_defect"] & ~labels["is_tester_fault"])).sum()
print("is_healthy vs (not defect & not tester) mismatches:", h_mis)
defect_and_tester = (labels["is_defect"] & labels["is_tester_fault"]).sum()
print("parts both defect and tester fault:", defect_and_tester)
miss_onset = (labels["is_defect"] & labels["anomaly_onset_hour"].isna()).sum()
print("defect parts with NaN onset (would silently fall to 'healthy' stratum):", miss_onset)


def conf(truth: np.ndarray, flagv: np.ndarray) -> dict:
    tp = int((truth & flagv).sum()); fn = int((truth & ~flagv).sum()); fp = int((~truth & flagv).sum()); tn = int((~truth & ~flagv).sum())
    return {"tp": tp, "fn": fn, "fp": fp, "tn": tn, "recall": tp / (tp + fn) if tp + fn else None, "fpr": fp / (fp + tn) if fp + tn else None, "precision": tp / (tp + fp) if tp + fp else None}


# ------------------------------------------------------------------ recompute per config
rec: dict[str, dict] = {}
per_batch: dict[str, pd.Series] = {}
per_fold: dict[str, pd.Series] = {}
for cfg in configs:
    g = df[df["config"] == cfg].copy()
    p, y, lim = g["predicted_normalized"].to_numpy(float), g["y_normalized"].to_numpy(float), g["upper_limit"].to_numpy(float)
    err = p - y
    ae = np.abs(err)
    r = {"mae": ae.mean(), "mae_ua": np.abs(p * lim - g["final_value"].to_numpy(float)).mean(), "rmse": np.sqrt((err ** 2).mean()), "mse_signed": err.mean()}
    fold_mae = pd.Series(ae).groupby(g["fold"].astype(int).to_numpy()).mean().sort_index()
    per_fold[cfg] = fold_mae
    r["fold_mean"], r["fold_std"] = fold_mae.mean(), fold_mae.std(ddof=1)
    obs = y >= 1.0
    r["cross"] = conf(obs, p >= 1.0)
    new = g["limit_fraction"].to_numpy(float) < 1.0
    r["new"] = conf(obs[new], (p >= 1.0)[new])
    clean = ~g["is_tester_fault"].to_numpy(bool)
    r["latent"] = conf(g["is_future_failure"].to_numpy(bool)[clean], (p >= 1.0)[clean])
    hl = g["is_healthy"].to_numpy(bool)
    r["healthy_mae"], r["nonhealthy_mae"] = ae[hl].mean(), ae[~hl].mean()
    r["clipped0"] = (p <= 0).mean()
    r["profile"] = {}
    for pid, gg in g.groupby("profile_id"):
        pp, yy, ll = gg["predicted_normalized"].to_numpy(float), gg["y_normalized"].to_numpy(float), gg["upper_limit"].to_numpy(float)
        c = conf(yy >= 1, pp >= 1)
        r["profile"][pid] = {"n": len(gg), "mae": np.abs(pp - yy).mean(), "mae_ua": np.abs(pp * ll - gg["final_value"].to_numpy(float)).mean(), "recall": c["recall"], "fpr": c["fpr"]}
    r["stratum"] = {}
    for s in ("healthy", "defect_onset_le24", "defect_onset_gt24", "tester_fault_onset_0_12", "tester_fault_onset_72"):
        m = (g["stratum"] == s).to_numpy()
        c = conf(obs[m], (p >= 1.0)[m])
        r["stratum"][s] = {"n": int(m.sum()), "mae": ae[m].mean(), "mse": err[m].mean(), "recall": c["recall"], "fp": c["fp"]}
    r["scenario"] = {s: ae[(g["scenario"] == s).to_numpy()].mean() for s in sorted(g["scenario"].unique())}
    per_batch[cfg] = pd.Series(ae).groupby(g["batch_id"].to_numpy()).mean().sort_index()
    rec[cfg] = r

pb_pers = per_batch["persistence"]
for cfg in configs:
    delta = (per_batch[cfg] - pb_pers.reindex(per_batch[cfg].index)).to_numpy(float)
    rec[cfg]["batches_beat"] = int((delta < 0).sum())
    rec[cfg]["batches_total"] = len(delta)
    rec[cfg]["delta_mean"] = delta.mean()
    rec[cfg]["delta_se"] = delta.std(ddof=1) / np.sqrt(len(delta))
    rec[cfg]["folds_beat"] = int((per_fold[cfg].to_numpy() < per_fold["persistence"].to_numpy()).sum())

# ------------------------------------------------------------------ compare to comparison_table.csv
TOL = 1e-9
tab = table.set_index("config")
if set(tab.index) != set(configs):
    flag(f"comparison_table configs {sorted(tab.index)} != oof configs {configs}")
colmap = {
    "mae_norm_pooled": lambda r: r["mae"], "mae_norm_fold_mean": lambda r: r["fold_mean"], "mae_norm_fold_std": lambda r: r["fold_std"],
    "folds_beating_persistence": lambda r: r["folds_beat"], "batches_beating_persistence": lambda r: r["batches_beat"], "batches_total": lambda r: r["batches_total"],
    "paired_batch_delta_mean": lambda r: r["delta_mean"], "paired_batch_delta_se": lambda r: r["delta_se"],
    "share_clipped_at_zero": lambda r: r["clipped0"], "mae_ua_pooled": lambda r: r["mae_ua"], "rmse_norm_pooled": lambda r: r["rmse"], "mean_signed_error": lambda r: r["mse_signed"],
    "healthy_mae_norm": lambda r: r["healthy_mae"], "nonhealthy_mae_norm": lambda r: r["nonhealthy_mae"],
    "crossing_recall": lambda r: r["cross"]["recall"], "crossing_fpr": lambda r: r["cross"]["fpr"], "crossing_precision": lambda r: r["cross"]["precision"],
    "crossing_tp": lambda r: r["cross"]["tp"], "crossing_fn": lambda r: r["cross"]["fn"], "crossing_fp": lambda r: r["cross"]["fp"], "crossing_tn": lambda r: r["cross"]["tn"],
    "latent_recall_no_tester": lambda r: r["latent"]["recall"], "latent_fpr_no_tester": lambda r: r["latent"]["fpr"],
    "new_crossing_recall": lambda r: r["new"]["recall"], "new_crossing_fpr": lambda r: r["new"]["fpr"], "new_crossing_tp": lambda r: r["new"]["tp"], "new_crossing_fp": lambda r: r["new"]["fp"],
}
n_ok = 0
for cfg in configs:
    for col, fn in colmap.items():
        mine, theirs = fn(rec[cfg]), tab.loc[cfg, col]
        if isinstance(theirs, float) and np.isnan(theirs):
            theirs = None
        if not close(mine, theirs, TOL):
            flag(f"comparison_table.csv[{cfg},{col}] = {theirs} vs recomputed {mine}")
        else:
            n_ok += 1
ok(f"comparison_table.csv: {n_ok} of {len(configs) * len(colmap)} cells match to rel 1e-9")
# train_mae cannot be recomputed from oof (needs train preds) -> note
print("NOTE: train_mae_norm_fold_mean is not recomputable from oof_predictions.csv (needs in-sample predictions); cross-checked only against cv_results.json below.")
# ordering
if list(table["config"]) != list(table.sort_values("mae_norm_pooled")["config"]):
    flag("comparison_table.csv not sorted by mae_norm_pooled")
else:
    ok("comparison_table.csv sorted ascending by mae_norm_pooled")

# ------------------------------------------------------------------ compare to comparison_by_profile.csv
n_ok = 0; n_tot = 0
for _, row in prof.iterrows():
    r = rec[row["config"]]["profile"][row["profile_id"]]
    for col, key in (("components", "n"), ("mae_normalized", "mae"), ("mae_ua", "mae_ua"), ("crossing_recall", "recall"), ("crossing_fpr", "fpr")):
        n_tot += 1
        if not close(r[key], row[col], TOL):
            flag(f"comparison_by_profile.csv[{row['config']},{row['profile_id']},{col}] = {row[col]} vs recomputed {r[key]}")
        else:
            n_ok += 1
ok(f"comparison_by_profile.csv: {n_ok}/{n_tot} cells match ({len(prof)} rows; expected {len(configs)*4})")
if len(prof) != len(configs) * 4:
    flag(f"comparison_by_profile.csv has {len(prof)} rows, expected {len(configs)*4}")

# ------------------------------------------------------------------ compare to comparison_by_stratum.csv
n_ok = 0; n_tot = 0
for _, row in strat.iterrows():
    r = rec[row["config"]]["stratum"][row["stratum"]]
    for col, key in (("components", "n"), ("mae_normalized", "mae"), ("mean_signed_error", "mse"), ("crossing_recall", "recall"), ("crossing_fp", "fp")):
        n_tot += 1
        theirs = row[col]
        if isinstance(theirs, float) and np.isnan(theirs):
            theirs = None
        if not close(r[key], theirs, TOL):
            flag(f"comparison_by_stratum.csv[{row['config']},{row['stratum']},{col}] = {theirs} vs recomputed {r[key]}")
        else:
            n_ok += 1
ok(f"comparison_by_stratum.csv: {n_ok}/{n_tot} cells match ({len(strat)} rows; expected {len(configs)*5})")

# ------------------------------------------------------------------ compare to cv_results.json
n_ok = 0; n_tot = 0
for cfg in configs:
    e = cv["configs"][cfg]
    pooled = e["pooled"]
    pairs = [
        ("pooled.mae_normalized", pooled["mae_normalized"], rec[cfg]["mae"]),
        ("pooled.mae_ua", pooled["mae_ua"], rec[cfg]["mae_ua"]),
        ("pooled.rmse_normalized", pooled["rmse_normalized"], rec[cfg]["rmse"]),
        ("pooled.mean_signed_error_normalized", pooled["mean_signed_error_normalized"], rec[cfg]["mse_signed"]),
        ("pooled.healthy_mae_normalized", pooled["healthy_mae_normalized"], rec[cfg]["healthy_mae"]),
        ("pooled.components", pooled["components"], len(labels)),
        ("pooled.batches", pooled["batches"], 36),
        ("fold_summary.mae_normalized.mean", e["fold_summary"]["mae_normalized"]["mean"], rec[cfg]["fold_mean"]),
        ("fold_summary.mae_normalized.std", e["fold_summary"]["mae_normalized"]["std"], rec[cfg]["fold_std"]),
        ("batches_beating_persistence", e["batches_beating_persistence"], rec[cfg]["batches_beat"]),
        ("folds_beating_persistence", e["folds_beating_persistence"], rec[cfg]["folds_beat"]),
        ("paired.mean", e["paired_batch_delta_vs_persistence"]["mean"], rec[cfg]["delta_mean"]),
        ("paired.se", e["paired_batch_delta_vs_persistence"]["se"], rec[cfg]["delta_se"]),
    ]
    for k in ("tp", "fn", "fp", "tn"):
        pairs.append((f"pooled.observed_final_crossing.{k}", pooled["observed_final_crossing"][k], rec[cfg]["cross"][k]))
        pairs.append((f"pooled.new_observed_crossing.{k}", pooled["new_observed_crossing_below_limit_at_24h"][k], rec[cfg]["new"][k]))
        pairs.append((f"pooled.latent.{k}", pooled["latent_crossing_excluding_tester_faults"][k], rec[cfg]["latent"][k]))
    for i, v in enumerate(e["fold_summary"]["mae_normalized"]["per_fold"]):
        pairs.append((f"per_fold[{i}].mae", v, per_fold[cfg].loc[i]))
        pairs.append((f"per_fold[{i}].mae(dup)", e["per_fold"][i]["mae_normalized"], per_fold[cfg].loc[i]))
        pairs.append((f"per_fold[{i}].fold", e["per_fold"][i]["fold"], i))
    for b, v in e["per_batch_mae_normalized"].items():
        pairs.append((f"per_batch[{b}]", v, per_batch[cfg].loc[b]))
    for s, m in pooled["by_stratum"].items():
        pairs.append((f"by_stratum[{s}].n", m["components"], rec[cfg]["stratum"][s]["n"]))
        pairs.append((f"by_stratum[{s}].mae", m["mae_normalized"], rec[cfg]["stratum"][s]["mae"]))
    for s, m in pooled["by_scenario_mae_normalized"].items():
        pairs.append((f"by_scenario[{s}].mae", m["mae_normalized"], rec[cfg]["scenario"][s]))
    for pid, m in pooled["by_profile"].items():
        pairs.append((f"by_profile[{pid}].mae_ua", m["mae_ua"], rec[cfg]["profile"][pid]["mae_ua"]))
    for name, theirs, mine in pairs:
        n_tot += 1
        if not close(mine, theirs, TOL):
            flag(f"cv_results.json[{cfg}].{name} = {theirs} vs recomputed {mine}")
        else:
            n_ok += 1
    # validation batches per fold match fold_assignment
    for i, m in enumerate(e["per_fold"]):
        exp = sorted(folds.loc[folds["fold"].astype(int) == i, "batch_id"])
        if m["validation_batches"] != exp:
            flag(f"cv_results.json[{cfg}].per_fold[{i}].validation_batches != fold_assignment.csv")
    # comparison_table.train_mae column vs cv_results
    if not close(tab.loc[cfg, "train_mae_norm_fold_mean"], e["train_mae_normalized_fold_mean"], TOL):
        flag(f"comparison_table train_mae[{cfg}] != cv_results train_mae_normalized_fold_mean")
    if not close(tab.loc[cfg, "train_mae_norm_fold_mean"], np.mean([m["train_mae_normalized"] for m in e["per_fold"]]), TOL):
        flag(f"cv_results train_mae_normalized_fold_mean[{cfg}] != mean of per_fold train_mae_normalized")
ok(f"cv_results.json: {n_ok}/{n_tot} scalar cells match to rel 1e-9")
if cv["selection_rule"] != pre["selection_rule"]:
    flag("cv_results.selection_rule differs from PREDECLARED_COMPARISON.json selection_rule")
else:
    ok("cv_results.selection_rule == PREDECLARED selection_rule")
if cv.get("predeclaration", {}).get("config_digest", cv.get("predeclaration")) not in (pre["config_digest"], None) and pre["config_digest"] not in json.dumps(cv["predeclaration"]):
    flag("cv_results predeclaration digest does not reference PREDECLARED config_digest")
else:
    ok(f"cv_results predeclaration references digest {pre['config_digest'][:16]}")

# ------------------------------------------------------------------ COMPARISON.md rounded tables
def md_table(md: str, header_start: str) -> dict[str, list[str]]:
    lines = md.splitlines()
    start = next(i for i, l in enumerate(lines) if l.startswith(header_start))
    rows = {}
    for l in lines[start + 2:]:
        if not l.startswith("|"):
            break
        cells = [c.strip() for c in l.strip("|").split("|")]
        rows[cells[0].strip("`")] = cells[1:]
    return rows


def rnd(x, nd):
    return f"{x:.{nd}f}"


main_md = md_table(md, "| config | MAE norm (pooled)")
n_ok = 0; n_tot = 0
for cfg, cells in main_md.items():
    r = rec[cfg]
    exp = [rnd(r["mae"], 4), f"{rnd(r['fold_mean'],4)} ± {rnd(r['fold_std'],4)}", f"{r['folds_beat']}/5", f"{r['batches_beat']}/36",
           f"{r['delta_mean']:+.4f} ({rnd(r['delta_se'],4)})", None, rnd(r["mae_ua"], 4), rnd(r["healthy_mae"], 4), rnd(r["nonhealthy_mae"], 4), f"{r['mse_signed']:+.4f}",
           rnd(r["cross"]["recall"], 3), rnd(r["cross"]["fpr"], 4), f"{r['cross']['tp']}/{r['cross']['fn']}/{r['cross']['fp']}/{r['cross']['tn']}",
           f"{rnd(r['new']['recall'],3)} ({r['new']['tp']}/{r['new']['fp']})", None, rnd(r["clipped0"], 4)]
    for j, (e_, c_) in enumerate(zip(exp, cells)):
        if e_ is None:
            continue
        n_tot += 1
        if j == 14:
            continue
        if e_ != c_:
            # allow -0.0000 vs +0.0000 style differences? report them anyway
            flag(f"COMPARISON.md main table [{cfg}] col {j}: '{c_}' vs recomputed '{e_}'")
        else:
            n_ok += 1
    # latent column: md prints with %.3g-ish; check numerically
    n_tot += 1
    try:
        if abs(float(cells[14]) - r["latent"]["recall"]) > 0.0006:
            flag(f"COMPARISON.md main table [{cfg}] latent recall '{cells[14]}' vs recomputed {r['latent']['recall']:.4f}")
        else:
            n_ok += 1
    except ValueError:
        flag(f"COMPARISON.md latent cell unparsable: {cells[14]}")
ok(f"COMPARISON.md main table: {n_ok}/{n_tot} rendered cells match recomputation after rounding")
if list(main_md) != list(table["config"]):
    flag("COMPARISON.md main table row order differs from comparison_table.csv")

fold_md = md_table(md, "| config | fold 0")
n_ok = 0; n_tot = 0
for cfg, cells in fold_md.items():
    for i, c in enumerate(cells):
        n_tot += 1
        if rnd(per_fold[cfg].loc[i], 4) != c:
            flag(f"COMPARISON.md per-fold [{cfg}] fold {i}: '{c}' vs recomputed {per_fold[cfg].loc[i]:.6f}")
        else:
            n_ok += 1
ok(f"COMPARISON.md per-fold table: {n_ok}/{n_tot} cells match")

prof_md = md_table(md, "| config | SIM_X7R_100N_50V")
hdr = [c.strip() for c in md.splitlines()[next(i for i, l in enumerate(md.splitlines()) if l.startswith("| config | SIM_X7R_100N_50V"))].strip("|").split("|")][1:]
n_ok = 0; n_tot = 0
for cfg, cells in prof_md.items():
    for pid, c in zip(hdr, cells):
        n_tot += 1
        if rnd(rec[cfg]["profile"][pid]["mae_ua"], 4) != c:
            flag(f"COMPARISON.md profile uA [{cfg},{pid}]: '{c}' vs recomputed {rec[cfg]['profile'][pid]['mae_ua']:.6f}")
        else:
            n_ok += 1
ok(f"COMPARISON.md profile-uA table: {n_ok}/{n_tot} cells match")

strat_md = md_table(md, "| config | healthy | defect_onset_le24")
n_ok = 0; n_tot = 0
for cfg, cells in strat_md.items():
    for s, c in zip(("healthy", "defect_onset_le24", "defect_onset_gt24", "tester_fault_onset_0_12", "tester_fault_onset_72"), cells):
        n_tot += 1
        e_ = f"{rec[cfg]['stratum'][s]['mae']:.4f} ({rec[cfg]['stratum'][s]['mse']:+.3f})"
        if e_ != c:
            flag(f"COMPARISON.md stratum [{cfg},{s}]: '{c}' vs recomputed '{e_}'")
        else:
            n_ok += 1
ok(f"COMPARISON.md stratum table: {n_ok}/{n_tot} cells match")
m = re.search(r"Counts: healthy = (\d+), defect_onset_le24 = (\d+), defect_onset_gt24 = (\d+), tester_fault_onset_0_12 = (\d+), tester_fault_onset_72 = (\d+)", md)
cnts = pd.Series(lab_str).value_counts()
exp_counts = tuple(str(cnts[s]) for s in ("healthy", "defect_onset_le24", "defect_onset_gt24", "tester_fault_onset_0_12", "tester_fault_onset_72"))
(ok if m and m.groups() == exp_counts else flag)(f"COMPARISON.md stratum counts line {m.groups() if m else None} vs recomputed {exp_counts}")

scen_md = md_table(md, "| config | accelerating_drift")
shdr = [c.strip() for c in md.splitlines()[next(i for i, l in enumerate(md.splitlines()) if l.startswith("| config | accelerating_drift"))].strip("|").split("|")][1:]
n_ok = 0; n_tot = 0
for cfg, cells in scen_md.items():
    for s, c in zip(shdr, cells):
        n_tot += 1
        if rnd(rec[cfg]["scenario"][s], 4) != c:
            flag(f"COMPARISON.md scenario [{cfg},{s}]: '{c}' vs recomputed {rec[cfg]['scenario'][s]:.6f}")
        else:
            n_ok += 1
ok(f"COMPARISON.md scenario table: {n_ok}/{n_tot} cells match")

# ------------------------------------------------------------------ headline cross-check
print("\n=== headline numbers ===")
for cfg in ("persistence", "xgb_abs_resid_leak", "xgb_v1_replica", "xgb_abs_resid_aux", "xgb_abs_resid_peer"):
    r = rec[cfg]
    print(f"{cfg:22s} MAE {r['mae']:.5f}  folds_beat {r['folds_beat']}  batches_beat {r['batches_beat']}/36  healthy {r['healthy_mae']:.4f}  cross recall {r['cross']['recall']:.3f} tp {r['cross']['tp']} fp {r['cross']['fp']}  new tp/fp {r['new']['tp']}/{r['new']['fp']} latent {r['latent']['recall']:.3f}")

# ------------------------------------------------------------------ selection rule by the letter
print("\n=== selection rule ===")
pers_mae, pers_folds = rec["persistence"]["mae"], per_fold["persistence"].to_numpy()
batch_const_cols = {"temperature_c", "measurement_temperature_c", "voltage_stress_ratio", "measurement_voltage_v", "applied_voltage_v", "prior_storage_humidity_pct"}
elig = {}
for c in pre["configs"]:
    cfg = c["name"]; r = rec[cfg]
    a = r["mae"] < pers_mae and r["folds_beat"] >= 4
    b = r["healthy_mae"] <= 0.02
    cc = not (set(c["feature_columns"]) & batch_const_cols)
    elig[cfg] = a and b and cc and c["model"] != "persistence"
    print(f"{cfg:24s} mae {r['mae']:.5f} fold_mean {r['fold_mean']:.5f} (a){a} (b){b} healthy={r['healthy_mae']:.4f} (c){cc} -> eligible {elig[cfg]}")
eligible = [k for k, v in elig.items() if v]
winner = sorted(eligible, key=lambda k: (rec[k]["mae"], rec[k]["fold_mean"]))[0] if eligible else "persistence"
print("winner by the letter:", winner, " eligible:", eligible)

# batch-constancy check of the extra feature inputs in train_early
for col in ("prior_storage_humidity_pct", "capacitance_nf", "dissipation_factor_pct", "measurement_temperature_c", "voltage_stress_ratio"):
    nun = early.groupby("batch_id")[col].nunique()
    print(f"  distinct {col} per batch: min {nun.min()} max {nun.max()}")

# paired comparisons among the top three
print("\n=== paired deltas among top three (per-batch, n=36; per-fold, n=5) ===")
from itertools import combinations
top = ["xgb_abs_resid_aux", "xgb_abs_resid_peer", "xgb_abs_resid_leak"]
for a_, b_ in combinations(top, 2):
    d = (per_batch[a_] - per_batch[b_].reindex(per_batch[a_].index)).to_numpy(float)
    se = d.std(ddof=1) / np.sqrt(len(d))
    wins = int((d < 0).sum())
    df_ = (per_fold[a_] - per_fold[b_]).to_numpy(float)
    sef = df_.std(ddof=1) / np.sqrt(len(df_))
    # exact sign test p-value (two-sided)
    from math import comb
    n = len(d); k = min(wins, n - wins)
    p_sign = sum(comb(n, i) for i in range(0, k + 1)) * 2 / 2 ** n
    print(f"{a_} - {b_}: batch delta mean {d.mean():+.5f} SE {se:.5f} t={d.mean()/se:+.2f}  {a_} better in {wins}/{n} batches (sign p={p_sign:.3f}); fold delta mean {df_.mean():+.5f} SE {sef:.5f} t={df_.mean()/sef:+.2f}, better in {int((df_<0).sum())}/5 folds")
# component-level paired (n=7200) too
for a_, b_ in combinations(top, 2):
    ga = df[df["config"] == a_].set_index(ID); gb = df[df["config"] == b_].set_index(ID).reindex(ga.index)
    d = (np.abs(ga["predicted_normalized"] - ga["y_normalized"]) - np.abs(gb["predicted_normalized"] - gb["y_normalized"])).to_numpy(float)
    print(f"  component-level {a_} - {b_}: mean {d.mean():+.5f} naive SE {d.std(ddof=1)/np.sqrt(len(d)):.5f} (ignores batch clustering)")
print("pooled MAE gaps: aux-leak", rec["xgb_abs_resid_aux"]["mae"] - rec["xgb_abs_resid_leak"]["mae"], " aux-peer", rec["xgb_abs_resid_aux"]["mae"] - rec["xgb_abs_resid_peer"]["mae"])
sc = json.load(open(OUT / "seed_check__xgb_abs_resid_leak.json"))
print("seed_check keys:", list(sc.keys()))
print(json.dumps({k: v for k, v in sc.items() if k not in ("per_seed",)}, indent=1)[:1500])

print("\n=== SUMMARY ===")
print(f"{len(issues)} mismatches; {len(checks)} check groups OK")
for i in issues:
    print(" -", i)
