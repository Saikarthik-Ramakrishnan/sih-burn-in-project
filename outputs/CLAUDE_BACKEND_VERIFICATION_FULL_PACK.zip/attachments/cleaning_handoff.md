# Handoff — CSV/Data Analysis → XGBoost + Isolation Forest

## Scope
My task: CSV extraction, cleaning, validation and early-data analysis. No XGBoost/Isolation Forest tuning done here.

## Input
`train_early.csv` = early measurements only (0h, 24h).
- 7,200 components
- 14,400 early rows
- 36 batches
- Component family: MLCC_X7R
- Main measurement: leakage current (µA)

## Data checks owned by me
- Read/write CSV with Pandas
- Missing-value check
- Duplicate detection + removal
- Deleted duplicates saved separately
- Invalid/impossible value checks
- Sort by `component_id`, then `hours`
- Verify 0h/24h availability

## Derived early features
- `leakage_0h_ua`
- `leakage_24h_ua`
- `change_0h_to_24h_ua`
- `percent_change`
- `slope_ua_per_hour`
- `fraction_of_limit`
- batch median/MAD
- `robust_z_score`

## Baseline screening
- `ABOVE LIMIT`: 24h leakage > supplied upper limit
- `CHECK / MONITOR`: batch-relative robust z-score > 3.5
- `NORMAL`: neither condition

This is only an interpretable Pandas baseline, NOT the final ML prediction.

## Known baseline counts
- NORMAL: 6,899 (95.82%)
- CHECK / MONITOR: 185 (2.57%)
- ABOVE LIMIT: 116 (1.61%)

## Important
Do NOT treat `ABOVE LIMIT` as the same as confirmed future failure.
Use early features only for model inputs. Do not use future 168h values/outcomes as features.

## Coordination
Use `06_component_analysis_technical.csv` as the clean early-feature reference.
Use `07_component_readable_report.csv` for human-readable screening.
`02_deleted_duplicate_values.csv` records rows removed.
`01_cleaned_sorted_train_early.csv` is the cleaned/sorted early dataset.

For the ML pipeline, keep train/calibration/test separation by complete batches and avoid leakage from later measurements.
